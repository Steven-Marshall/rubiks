# RubiksCube v1.0 - Archived Implementation

This directory contains the original face-based implementation of RubiksCube.

## What We Learned

### Strengths of v1:
- Excellent CLI interface design
- Comprehensive test suite structure  
- Good separation of concerns (Core, CLI, Tests)
- Unix-style piping philosophy
- JSON-based cube state representation
- Algorithm parsing and notation support

### Architecture Issues Discovered:
- Face-based representation doesn't reflect physical reality
- Complex orientation tracking system prone to bugs
- Rotation display issues (R z' example exposed fundamental problems)
- Fragile piece-to-position mapping
- Difficult to validate physical constraints

### Critical Bug Fixes Made:
- L, D, F move counter-clockwise implementations (were identical to clockwise)
- Y rotation direction (was backwards)
- Color scheme corrections (Red=Left, Orange=Right)

### Test Results at Archive:
- 480/518 tests passing (92.7% success rate)
- All basic moves working correctly
- Orientation tracking functional but complex
- Rotation display issues identified but not fully resolved

## Key Files for Reference:
- `src/RubiksCube.Core/Models/Cube.cs` - Core cube logic
- `src/RubiksCube.Core/Models/CubeOrientation.cs` - Orientation tracking
- `src/RubiksCube.CLI/Program.cs` - CLI interface (reuse design)
- `src/RubiksCube.Tests/` - Test patterns and infrastructure

## Replacement:
v2.0 implements piece-based coordinate system that better reflects physical cube behavior.