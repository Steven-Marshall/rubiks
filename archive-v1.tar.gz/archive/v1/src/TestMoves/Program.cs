using RubiksCube.Core.Models;

var cube = new Cube();

Console.WriteLine("=== Testing F Move ===");
Console.WriteLine("Initial colors: Left=Red, Front=Green, Right=Orange, Back=Blue, Up=Yellow, Down=White");

Console.WriteLine("\nBefore F move:");
Console.WriteLine($"Up bottom row: {cube.GetSticker(CubeFace.Up, 6)}, {cube.GetSticker(CubeFace.Up, 7)}, {cube.GetSticker(CubeFace.Up, 8)}");
Console.WriteLine($"Right left column: {cube.GetSticker(CubeFace.Right, 0)}, {cube.GetSticker(CubeFace.Right, 3)}, {cube.GetSticker(CubeFace.Right, 6)}");
Console.WriteLine($"Down top row: {cube.GetSticker(CubeFace.Down, 0)}, {cube.GetSticker(CubeFace.Down, 1)}, {cube.GetSticker(CubeFace.Down, 2)}");
Console.WriteLine($"Left right column: {cube.GetSticker(CubeFace.Left, 2)}, {cube.GetSticker(CubeFace.Left, 5)}, {cube.GetSticker(CubeFace.Left, 8)}");

cube.ApplyMove(new Move(CubeFace.Front, MoveType.Clockwise));

Console.WriteLine("\nAfter F move (clockwise when looking at green/front face):");
Console.WriteLine($"Up bottom row: {cube.GetSticker(CubeFace.Up, 6)}, {cube.GetSticker(CubeFace.Up, 7)}, {cube.GetSticker(CubeFace.Up, 8)}");
Console.WriteLine($"Right left column: {cube.GetSticker(CubeFace.Right, 0)}, {cube.GetSticker(CubeFace.Right, 3)}, {cube.GetSticker(CubeFace.Right, 6)}");
Console.WriteLine($"Down top row: {cube.GetSticker(CubeFace.Down, 0)}, {cube.GetSticker(CubeFace.Down, 1)}, {cube.GetSticker(CubeFace.Down, 2)}");
Console.WriteLine($"Left right column: {cube.GetSticker(CubeFace.Left, 2)}, {cube.GetSticker(CubeFace.Left, 5)}, {cube.GetSticker(CubeFace.Left, 8)}");

Console.WriteLine("\nExpected pattern for clockwise F:");
Console.WriteLine("Up bottom row -> Right left column");
Console.WriteLine("Right left column -> Down top row (reversed)");
Console.WriteLine("Down top row -> Left right column");
Console.WriteLine("Left right column -> Up bottom row (reversed)");