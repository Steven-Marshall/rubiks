using System.Text.Json;
using CSharpFunctionalExtensions;

namespace RubiksCube.Core.Configuration;

public class ConfigurationManager
{
    private static readonly string ConfigFileName = "config.json";
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
    };

    public static string GetConfigDirectory()
    {
        var appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        
        return Environment.OSVersion.Platform switch
        {
            PlatformID.Win32NT => Path.Combine(appDataPath, "RubiksCube"),
            PlatformID.Unix => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), ".config", "rubiks"),
            _ => Path.Combine(appDataPath, "RubiksCube")
        };
    }

    public static string GetConfigFilePath()
    {
        return Path.Combine(GetConfigDirectory(), ConfigFileName);
    }

    public static Result<DisplayConfig> LoadDisplayConfig()
    {
        try
        {
            var configPath = GetConfigFilePath();
            
            if (!File.Exists(configPath))
            {
                // Return default config if file doesn't exist
                return Result.Success(new DisplayConfig());
            }

            var json = File.ReadAllText(configPath);
            var config = JsonSerializer.Deserialize<DisplayConfig>(json, JsonOptions);
            
            return config != null 
                ? Result.Success(config)
                : Result.Failure<DisplayConfig>("Invalid configuration file format");
        }
        catch (Exception ex)
        {
            return Result.Failure<DisplayConfig>($"Failed to load configuration: {ex.Message}");
        }
    }

    public static Result SaveDisplayConfig(DisplayConfig config)
    {
        if (config == null)
            return Result.Failure("Configuration cannot be null");

        try
        {
            var configDir = GetConfigDirectory();
            Directory.CreateDirectory(configDir);

            var configPath = GetConfigFilePath();
            var json = JsonSerializer.Serialize(config, JsonOptions);
            
            File.WriteAllText(configPath, json);
            return Result.Success();
        }
        catch (Exception ex)
        {
            return Result.Failure($"Failed to save configuration: {ex.Message}");
        }
    }

    public static bool ConfigExists()
    {
        return File.Exists(GetConfigFilePath());
    }

    public static Result DeleteConfig()
    {
        try
        {
            var configPath = GetConfigFilePath();
            if (File.Exists(configPath))
            {
                File.Delete(configPath);
            }
            return Result.Success();
        }
        catch (Exception ex)
        {
            return Result.Failure($"Failed to delete configuration: {ex.Message}");
        }
    }
}