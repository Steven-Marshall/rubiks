using RubiksCube.Core.Models;

namespace RubiksCube.Core.Display;

/// <summary>
/// Defines all physical pieces on a Rubik's cube by their color combinations.
/// Each piece is identified by the colors of its adjacent center faces.
/// </summary>
public static class PieceIdentification
{
    /// <summary>
    /// All 8 corner pieces defined by their 3 adjacent center colors.
    /// </summary>
    public static readonly Dictionary<HashSet<CubeColor>, CornerPiece> CornerPieces = 
        new Dictionary<HashSet<CubeColor>, CornerPiece>(new HashSetEqualityComparer<CubeColor>())
        {
            // Top layer corners (Yellow center involved)
            [new HashSet<CubeColor> { CubeColor.Yellow, CubeColor.Green, CubeColor.Red }] = 
                new CornerPiece(CubeColor.Yellow, CubeColor.Green, CubeColor.Red),
            [new HashSet<CubeColor> { CubeColor.Yellow, CubeColor.Green, CubeColor.Orange }] = 
                new CornerPiece(CubeColor.Yellow, CubeColor.Green, CubeColor.Orange),
            [new HashSet<CubeColor> { CubeColor.Yellow, CubeColor.Blue, CubeColor.Orange }] = 
                new CornerPiece(CubeColor.Yellow, CubeColor.Blue, CubeColor.Orange),
            [new HashSet<CubeColor> { CubeColor.Yellow, CubeColor.Blue, CubeColor.Red }] = 
                new CornerPiece(CubeColor.Yellow, CubeColor.Blue, CubeColor.Red),

            // Bottom layer corners (White center involved)
            [new HashSet<CubeColor> { CubeColor.White, CubeColor.Green, CubeColor.Red }] = 
                new CornerPiece(CubeColor.White, CubeColor.Green, CubeColor.Red),
            [new HashSet<CubeColor> { CubeColor.White, CubeColor.Green, CubeColor.Orange }] = 
                new CornerPiece(CubeColor.White, CubeColor.Green, CubeColor.Orange),
            [new HashSet<CubeColor> { CubeColor.White, CubeColor.Blue, CubeColor.Orange }] = 
                new CornerPiece(CubeColor.White, CubeColor.Blue, CubeColor.Orange),
            [new HashSet<CubeColor> { CubeColor.White, CubeColor.Blue, CubeColor.Red }] = 
                new CornerPiece(CubeColor.White, CubeColor.Blue, CubeColor.Red),
        };

    /// <summary>
    /// All 12 edge pieces defined by their 2 adjacent center colors.
    /// </summary>
    public static readonly Dictionary<HashSet<CubeColor>, EdgePiece> EdgePieces = 
        new Dictionary<HashSet<CubeColor>, EdgePiece>(new HashSetEqualityComparer<CubeColor>())
        {
            // Top layer edges (Yellow involved)
            [new HashSet<CubeColor> { CubeColor.Yellow, CubeColor.Green }] = 
                new EdgePiece(CubeColor.Yellow, CubeColor.Green),
            [new HashSet<CubeColor> { CubeColor.Yellow, CubeColor.Orange }] = 
                new EdgePiece(CubeColor.Yellow, CubeColor.Orange),
            [new HashSet<CubeColor> { CubeColor.Yellow, CubeColor.Blue }] = 
                new EdgePiece(CubeColor.Yellow, CubeColor.Blue),
            [new HashSet<CubeColor> { CubeColor.Yellow, CubeColor.Red }] = 
                new EdgePiece(CubeColor.Yellow, CubeColor.Red),

            // Middle layer edges (no Yellow or White)
            [new HashSet<CubeColor> { CubeColor.Green, CubeColor.Orange }] = 
                new EdgePiece(CubeColor.Green, CubeColor.Orange),
            [new HashSet<CubeColor> { CubeColor.Orange, CubeColor.Blue }] = 
                new EdgePiece(CubeColor.Orange, CubeColor.Blue),
            [new HashSet<CubeColor> { CubeColor.Blue, CubeColor.Red }] = 
                new EdgePiece(CubeColor.Blue, CubeColor.Red),
            [new HashSet<CubeColor> { CubeColor.Red, CubeColor.Green }] = 
                new EdgePiece(CubeColor.Red, CubeColor.Green),

            // Bottom layer edges (White involved)
            [new HashSet<CubeColor> { CubeColor.White, CubeColor.Green }] = 
                new EdgePiece(CubeColor.White, CubeColor.Green),
            [new HashSet<CubeColor> { CubeColor.White, CubeColor.Orange }] = 
                new EdgePiece(CubeColor.White, CubeColor.Orange),
            [new HashSet<CubeColor> { CubeColor.White, CubeColor.Blue }] = 
                new EdgePiece(CubeColor.White, CubeColor.Blue),
            [new HashSet<CubeColor> { CubeColor.White, CubeColor.Red }] = 
                new EdgePiece(CubeColor.White, CubeColor.Red),
        };

    /// <summary>
    /// Finds a corner piece by its adjacent center colors.
    /// </summary>
    public static CornerPiece? FindCornerPiece(CubeColor center1, CubeColor center2, CubeColor center3)
    {
        var colorSet = new HashSet<CubeColor> { center1, center2, center3 };
        return CornerPieces.TryGetValue(colorSet, out var piece) ? piece : null;
    }

    /// <summary>
    /// Finds an edge piece by its adjacent center colors.
    /// </summary>
    public static EdgePiece? FindEdgePiece(CubeColor center1, CubeColor center2)
    {
        var colorSet = new HashSet<CubeColor> { center1, center2 };
        return EdgePieces.TryGetValue(colorSet, out var piece) ? piece : null;
    }
}

/// <summary>
/// Represents a corner piece with 3 colored stickers.
/// </summary>
public class CornerPiece
{
    public CubeColor Color1 { get; }
    public CubeColor Color2 { get; }
    public CubeColor Color3 { get; }

    public CornerPiece(CubeColor color1, CubeColor color2, CubeColor color3)
    {
        Color1 = color1;
        Color2 = color2;
        Color3 = color3;
    }

    /// <summary>
    /// Gets the color that should be visible when viewing from the direction of the specified center.
    /// </summary>
    public CubeColor GetColorForCenter(CubeColor centerColor)
    {
        if (Color1 == centerColor) return Color1;
        if (Color2 == centerColor) return Color2;
        if (Color3 == centerColor) return Color3;
        throw new ArgumentException($"Corner piece does not have color {centerColor}");
    }

    /// <summary>
    /// Checks if this corner piece contains the specified color.
    /// </summary>
    public bool HasColor(CubeColor color)
    {
        return Color1 == color || Color2 == color || Color3 == color;
    }
}

/// <summary>
/// Represents an edge piece with 2 colored stickers.
/// </summary>
public class EdgePiece
{
    public CubeColor Color1 { get; }
    public CubeColor Color2 { get; }

    public EdgePiece(CubeColor color1, CubeColor color2)
    {
        Color1 = color1;
        Color2 = color2;
    }

    /// <summary>
    /// Gets the color that should be visible when viewing from the direction of the specified center.
    /// </summary>
    public CubeColor GetColorForCenter(CubeColor centerColor)
    {
        if (Color1 == centerColor) return Color1;
        if (Color2 == centerColor) return Color2;
        throw new ArgumentException($"Edge piece does not have color {centerColor}");
    }

    /// <summary>
    /// Checks if this edge piece contains the specified color.
    /// </summary>
    public bool HasColor(CubeColor color)
    {
        return Color1 == color || Color2 == color;
    }
}

/// <summary>
/// Equality comparer for HashSet to enable dictionary lookups.
/// </summary>
public class HashSetEqualityComparer<T> : IEqualityComparer<HashSet<T>>
{
    public bool Equals(HashSet<T>? x, HashSet<T>? y)
    {
        if (x == null && y == null) return true;
        if (x == null || y == null) return false;
        return x.SetEquals(y);
    }

    public int GetHashCode(HashSet<T> obj)
    {
        int hash = 0;
        foreach (T item in obj)
        {
            hash ^= item?.GetHashCode() ?? 0;
        }
        return hash;
    }
}