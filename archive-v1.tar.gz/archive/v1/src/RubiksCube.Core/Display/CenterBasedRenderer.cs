using RubiksCube.Core.Models;
using RubiksCube.Core.Configuration;
using CSharpFunctionalExtensions;
using System.Text;

namespace RubiksCube.Core.Display;

/// <summary>
/// Renders cubes using center-based piece lookup instead of orientation-based face mapping.
/// This approach correctly handles piece orientation within faces after rotations.
/// </summary>
public class CenterBasedRenderer
{
    private readonly DisplayConfig _config;

    public CenterBasedRenderer(DisplayConfig config)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
    }

    public Result<string> Render(Cube cube)
    {
        if (cube == null)
            return Result.Failure<string>("Cube cannot be null");

        try
        {
            return _config.Format switch
            {
                DisplayFormat.Unicode => RenderUnicode(cube),
                DisplayFormat.ASCII => RenderAscii(cube),
                _ => Result.Failure<string>($"Unsupported display format: {_config.Format}")
            };
        }
        catch (Exception ex)
        {
            return Result.Failure<string>($"Rendering failed: {ex.Message}");
        }
    }

    private Result<string> RenderUnicode(Cube cube)
    {
        var sb = new StringBuilder();
        var symbols = GetColorSymbols();
        var centerBasedOrientation = cube.GetCenterBasedOrientation();

        // Render top face (Up) - aligned with front
        for (int row = 0; row < 3; row++)
        {
            sb.Append("    "); // 4 spaces to align with front face (3 left squares + 1 space)
            for (int col = 0; col < 3; col++)
            {
                var color = GetPieceColorAt(cube, centerBasedOrientation, CubeFace.Up, row, col);
                sb.Append(symbols[color]);
            }
            sb.AppendLine();
        }

        // Render middle row (Left, Front, Right, Back)
        for (int row = 0; row < 3; row++)
        {
            // Left face
            for (int col = 0; col < 3; col++)
            {
                var color = GetPieceColorAt(cube, centerBasedOrientation, CubeFace.Left, row, col);
                sb.Append(symbols[color]);
            }
            sb.Append(' ');

            // Front face  
            for (int col = 0; col < 3; col++)
            {
                var color = GetPieceColorAt(cube, centerBasedOrientation, CubeFace.Front, row, col);
                sb.Append(symbols[color]);
            }
            sb.Append(' ');

            // Right face
            for (int col = 0; col < 3; col++)
            {
                var color = GetPieceColorAt(cube, centerBasedOrientation, CubeFace.Right, row, col);
                sb.Append(symbols[color]);
            }
            sb.Append(' ');

            // Back face
            for (int col = 0; col < 3; col++)
            {
                var color = GetPieceColorAt(cube, centerBasedOrientation, CubeFace.Back, row, col);
                sb.Append(symbols[color]);
            }
            sb.AppendLine();
        }

        // Render bottom face (Down) - aligned with front
        for (int row = 0; row < 3; row++)
        {
            sb.Append("    "); // 4 spaces to align with front face (3 left squares + 1 space)
            for (int col = 0; col < 3; col++)
            {
                var color = GetPieceColorAt(cube, centerBasedOrientation, CubeFace.Down, row, col);
                sb.Append(symbols[color]);
            }
            sb.AppendLine();
        }

        return Result.Success(sb.ToString());
    }

    private Result<string> RenderAscii(Cube cube)
    {
        var sb = new StringBuilder();
        var symbols = GetColorSymbols();
        var centerBasedOrientation = cube.GetCenterBasedOrientation();

        // Render top face (Up)
        for (int row = 0; row < 3; row++)
        {
            sb.Append("       "); // 7 spaces to align with front face (5 left chars + 2 spaces)
            for (int col = 0; col < 3; col++)
            {
                var color = GetPieceColorAt(cube, centerBasedOrientation, CubeFace.Up, row, col);
                sb.Append(symbols[color]);
                if (col < 2) sb.Append(' '); // Space between letters
            }
            sb.AppendLine();
        }

        // Render middle row
        for (int row = 0; row < 3; row++)
        {
            // Left face
            for (int col = 0; col < 3; col++)
            {
                var color = GetPieceColorAt(cube, centerBasedOrientation, CubeFace.Left, row, col);
                sb.Append(symbols[color]);
                if (col < 2) sb.Append(' ');
            }
            sb.Append("  "); // Double space between faces

            // Front face
            for (int col = 0; col < 3; col++)
            {
                var color = GetPieceColorAt(cube, centerBasedOrientation, CubeFace.Front, row, col);
                sb.Append(symbols[color]);
                if (col < 2) sb.Append(' ');
            }
            sb.Append("  "); // Double space between faces

            // Right face
            for (int col = 0; col < 3; col++)
            {
                var color = GetPieceColorAt(cube, centerBasedOrientation, CubeFace.Right, row, col);
                sb.Append(symbols[color]);
                if (col < 2) sb.Append(' ');
            }
            sb.Append("  "); // Double space between faces

            // Back face
            for (int col = 0; col < 3; col++)
            {
                var color = GetPieceColorAt(cube, centerBasedOrientation, CubeFace.Back, row, col);
                sb.Append(symbols[color]);
                if (col < 2) sb.Append(' ');
            }
            sb.AppendLine();
        }

        // Render bottom face (Down)
        for (int row = 0; row < 3; row++)
        {
            sb.Append("       "); // 7 spaces to align with front face (5 left chars + 2 spaces)
            for (int col = 0; col < 3; col++)
            {
                var color = GetPieceColorAt(cube, centerBasedOrientation, CubeFace.Down, row, col);
                sb.Append(symbols[color]);
                if (col < 2) sb.Append(' ');
            }
            sb.AppendLine();
        }

        return Result.Success(sb.ToString());
    }

    /// <summary>
    /// Gets the color of a piece at a specific display position using center-based piece lookup.
    /// This properly handles rotations by identifying pieces based on adjacent center colors.
    /// </summary>
    private CubeColor GetPieceColorAt(Cube cube, CenterBasedOrientation centerBasedOrientation, 
                                    CubeFace displayPosition, int row, int col)
    {
        return CubePieceLookup.GetPieceColorAt(cube, centerBasedOrientation, displayPosition, row, col);
    }


    private Dictionary<CubeColor, string> GetColorSymbols()
    {
        return _config.Format switch
        {
            DisplayFormat.Unicode => new Dictionary<CubeColor, string>
            {
                [CubeColor.White] = _config.Squares.White,
                [CubeColor.Red] = _config.Squares.Red,
                [CubeColor.Blue] = _config.Squares.Blue,
                [CubeColor.Orange] = _config.Squares.Orange,
                [CubeColor.Green] = _config.Squares.Green,
                [CubeColor.Yellow] = _config.Squares.Yellow
            },
            DisplayFormat.ASCII => new Dictionary<CubeColor, string>
            {
                [CubeColor.White] = _config.Letters.White,
                [CubeColor.Red] = _config.Letters.Red,
                [CubeColor.Blue] = _config.Letters.Blue,
                [CubeColor.Orange] = _config.Letters.Orange,
                [CubeColor.Green] = _config.Letters.Green,
                [CubeColor.Yellow] = _config.Letters.Yellow
            },
            _ => throw new InvalidOperationException($"Unsupported display format: {_config.Format}")
        };
    }
}