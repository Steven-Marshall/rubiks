using RubiksCube.Core.Models;

namespace RubiksCube.Core.Display;

/// <summary>
/// Provides piece lookup functionality for finding actual pieces in the cube state
/// and determining which colors should be visible from specific viewing directions.
/// </summary>
public static class CubePieceLookup
{
    /// <summary>
    /// Gets the color that should be displayed at a specific position using piece-based lookup.
    /// This properly handles rotations by identifying pieces based on adjacent center colors.
    /// </summary>
    public static CubeColor GetPieceColorAt(Cube cube, CenterBasedOrientation orientation, 
                                          CubeFace displayFace, int row, int col)
    {
        // Handle center positions - always show the center color for this display position
        if (DisplayPositionMapping.IsCenterPosition(row, col))
        {
            return orientation.GetCenterAt(displayFace);
        }

        // Handle corner positions
        if (DisplayPositionMapping.IsCornerPosition(row, col))
        {
            return GetCornerPieceColor(cube, orientation, displayFace, row, col);
        }

        // Handle edge positions
        if (DisplayPositionMapping.IsEdgePosition(row, col))
        {
            return GetEdgePieceColor(cube, orientation, displayFace, row, col);
        }

        throw new ArgumentException($"Invalid position: {displayFace}[{row},{col}]");
    }

    /// <summary>
    /// Gets the color for a corner piece at the specified display position.
    /// </summary>
    private static CubeColor GetCornerPieceColor(Cube cube, CenterBasedOrientation orientation,
                                               CubeFace displayFace, int row, int col)
    {
        // Get the 3 center colors that meet at this corner in the current orientation
        var (center1Face, center2Face, center3Face) = DisplayPositionMapping.GetAdjacentCentersForCorner(displayFace, row, col);
        var center1Color = orientation.GetCenterAt(center1Face);
        var center2Color = orientation.GetCenterAt(center2Face);
        var center3Color = orientation.GetCenterAt(center3Face);

        // Find the physical corner location where these 3 centers meet
        var physicalCornerLocation = FindPhysicalCornerLocation(center1Color, center2Color, center3Color);
        
        // Get the corner piece colors at that physical location
        var cornerColors = GetCornerColorsAtPosition(cube, physicalCornerLocation.face, physicalCornerLocation.position);
        
        // Determine which color from this corner should be visible from the display direction
        var primaryCenterColor = orientation.GetCenterAt(displayFace);
        return GetCornerColorForDirection(cornerColors, physicalCornerLocation, primaryCenterColor);
    }

    /// <summary>
    /// Gets the color for an edge piece at the specified display position.
    /// </summary>
    private static CubeColor GetEdgePieceColor(Cube cube, CenterBasedOrientation orientation,
                                             CubeFace displayFace, int row, int col)
    {
        // Get the 2 center colors that meet at this edge in the current orientation
        var (center1Face, center2Face) = DisplayPositionMapping.GetAdjacentCentersForEdge(displayFace, row, col);
        var center1Color = orientation.GetCenterAt(center1Face);
        var center2Color = orientation.GetCenterAt(center2Face);

        // Find the physical edge location where these 2 centers meet
        var physicalEdgeLocation = FindPhysicalEdgeLocation(center1Color, center2Color);
        
        // Get the edge piece colors at that physical location
        var edgeColors = GetEdgeColorsAtPosition(cube, physicalEdgeLocation.face, physicalEdgeLocation.position);
        
        // Determine which color from this edge should be visible from the display direction
        var primaryCenterColor = orientation.GetCenterAt(displayFace);
        return GetEdgeColorForDirection(edgeColors, physicalEdgeLocation, primaryCenterColor);
    }

    /// <summary>
    /// Finds the physical corner location where the specified 3 center colors meet.
    /// </summary>
    private static (CubeFace face, int position) FindPhysicalCornerLocation(CubeColor center1, CubeColor center2, CubeColor center3)
    {
        // Map center colors back to their original physical faces
        var face1 = GetPhysicalFaceForColor(center1);
        var face2 = GetPhysicalFaceForColor(center2);
        var face3 = GetPhysicalFaceForColor(center3);
        
        // Find the corner where these 3 physical faces meet
        return FindCornerWherePhysicalFacesMeet(face1, face2, face3);
    }

    /// <summary>
    /// Finds the physical edge location where the specified 2 center colors meet.
    /// </summary>
    private static (CubeFace face, int position) FindPhysicalEdgeLocation(CubeColor center1, CubeColor center2)
    {
        // Map center colors back to their original physical faces
        var face1 = GetPhysicalFaceForColor(center1);
        var face2 = GetPhysicalFaceForColor(center2);
        
        // Find the edge where these 2 physical faces meet
        return FindEdgeWherePhysicalFacesMeet(face1, face2);
    }

    /// <summary>
    /// Maps center colors back to their original physical faces.
    /// </summary>
    private static CubeFace GetPhysicalFaceForColor(CubeColor centerColor)
    {
        return centerColor switch
        {
            CubeColor.Green => CubeFace.Front,
            CubeColor.Orange => CubeFace.Right,
            CubeColor.Blue => CubeFace.Back,
            CubeColor.Red => CubeFace.Left,
            CubeColor.Yellow => CubeFace.Up,
            CubeColor.White => CubeFace.Down,
            _ => throw new ArgumentException($"Unknown center color: {centerColor}")
        };
    }

    /// <summary>
    /// Gets the color that should be visible from a corner piece in a specific direction.
    /// </summary>
    private static CubeColor GetCornerColorForDirection(HashSet<CubeColor> cornerColors, 
                                                       (CubeFace face, int position) cornerLocation, 
                                                       CubeColor viewingDirection)
    {
        // For corners, we need to determine which of the 3 colors corresponds to the viewing direction
        // This is a simplified approach - get the color from the face that matches the viewing direction
        var physicalFaceForDirection = GetPhysicalFaceForColor(viewingDirection);
        
        // If the corner is on the viewing face, return that face's color
        if (cornerLocation.face == physicalFaceForDirection)
        {
            // Return the color that's on the viewing face at this corner position
            // This is one of the 3 colors in the corner
            return cornerColors.First(c => GetPhysicalFaceForColor(c) == physicalFaceForDirection);
        }
        
        // Otherwise, find the color that corresponds to the viewing direction
        return cornerColors.First(c => GetPhysicalFaceForColor(c) == physicalFaceForDirection);
    }

    /// <summary>
    /// Gets the color that should be visible from an edge piece in a specific direction.
    /// </summary>
    private static CubeColor GetEdgeColorForDirection(HashSet<CubeColor> edgeColors, 
                                                     (CubeFace face, int position) edgeLocation, 
                                                     CubeColor viewingDirection)
    {
        // For edges, determine which of the 2 colors corresponds to the viewing direction
        var physicalFaceForDirection = GetPhysicalFaceForColor(viewingDirection);
        
        // Return the color that corresponds to the viewing direction
        return edgeColors.First(c => GetPhysicalFaceForColor(c) == physicalFaceForDirection);
    }

    /// <summary>
    /// Finds the corner position where 3 physical faces meet.
    /// </summary>
    private static (CubeFace face, int position) FindCornerWherePhysicalFacesMeet(CubeFace face1, CubeFace face2, CubeFace face3)
    {
        var faces = new HashSet<CubeFace> { face1, face2, face3 };
        
        // Check all possible corner combinations
        var cornerMappings = new Dictionary<HashSet<CubeFace>, (CubeFace, int)>(new HashSetEqualityComparer<CubeFace>())
        {
            // Front face corners
            [new HashSet<CubeFace> { CubeFace.Front, CubeFace.Up, CubeFace.Left }] = (CubeFace.Front, 0),
            [new HashSet<CubeFace> { CubeFace.Front, CubeFace.Up, CubeFace.Right }] = (CubeFace.Front, 2),
            [new HashSet<CubeFace> { CubeFace.Front, CubeFace.Down, CubeFace.Left }] = (CubeFace.Front, 6),
            [new HashSet<CubeFace> { CubeFace.Front, CubeFace.Down, CubeFace.Right }] = (CubeFace.Front, 8),
            
            // Back face corners (additional representations)
            [new HashSet<CubeFace> { CubeFace.Back, CubeFace.Up, CubeFace.Right }] = (CubeFace.Back, 0),
            [new HashSet<CubeFace> { CubeFace.Back, CubeFace.Up, CubeFace.Left }] = (CubeFace.Back, 2),
            [new HashSet<CubeFace> { CubeFace.Back, CubeFace.Down, CubeFace.Right }] = (CubeFace.Back, 6),
            [new HashSet<CubeFace> { CubeFace.Back, CubeFace.Down, CubeFace.Left }] = (CubeFace.Back, 8),
        };
        
        if (cornerMappings.TryGetValue(faces, out var corner))
        {
            return corner;
        }
        
        throw new ArgumentException($"No corner found where faces {face1}, {face2}, {face3} meet");
    }

    /// <summary>
    /// Finds the edge position where 2 physical faces meet.
    /// </summary>
    private static (CubeFace face, int position) FindEdgeWherePhysicalFacesMeet(CubeFace face1, CubeFace face2)
    {
        var faces = new HashSet<CubeFace> { face1, face2 };
        
        // Check all possible edge combinations
        var edgeMappings = new Dictionary<HashSet<CubeFace>, (CubeFace, int)>(new HashSetEqualityComparer<CubeFace>())
        {
            // Front face edges
            [new HashSet<CubeFace> { CubeFace.Front, CubeFace.Up }] = (CubeFace.Front, 1),
            [new HashSet<CubeFace> { CubeFace.Front, CubeFace.Right }] = (CubeFace.Front, 5),
            [new HashSet<CubeFace> { CubeFace.Front, CubeFace.Down }] = (CubeFace.Front, 7),
            [new HashSet<CubeFace> { CubeFace.Front, CubeFace.Left }] = (CubeFace.Front, 3),
            
            // Additional edge representations
            [new HashSet<CubeFace> { CubeFace.Right, CubeFace.Up }] = (CubeFace.Right, 1),
            [new HashSet<CubeFace> { CubeFace.Right, CubeFace.Back }] = (CubeFace.Right, 5),
            [new HashSet<CubeFace> { CubeFace.Right, CubeFace.Down }] = (CubeFace.Right, 7),
            
            [new HashSet<CubeFace> { CubeFace.Back, CubeFace.Up }] = (CubeFace.Back, 1),
            [new HashSet<CubeFace> { CubeFace.Back, CubeFace.Left }] = (CubeFace.Back, 5),
            [new HashSet<CubeFace> { CubeFace.Back, CubeFace.Down }] = (CubeFace.Back, 7),
            
            [new HashSet<CubeFace> { CubeFace.Left, CubeFace.Up }] = (CubeFace.Left, 1),
            [new HashSet<CubeFace> { CubeFace.Left, CubeFace.Down }] = (CubeFace.Left, 7),
        };
        
        if (edgeMappings.TryGetValue(faces, out var edge))
        {
            return edge;
        }
        
        throw new ArgumentException($"No edge found where faces {face1}, {face2} meet");
    }

    /// <summary>
    /// Gets the 3 colors that make up a corner at the specified position.
    /// This extracts colors from the 3 adjacent faces that meet at this corner.
    /// </summary>
    private static HashSet<CubeColor> GetCornerColorsAtPosition(Cube cube, CubeFace face, int position)
    {
        var colors = new HashSet<CubeColor>();
        
        // Add the color from the primary face
        colors.Add(cube.GetSticker(face, position));
        
        // Map corner positions to their adjacent face positions
        var adjacentPositions = GetAdjacentCornerPositions(face, position);
        
        foreach (var (adjacentFace, adjacentPosition) in adjacentPositions)
        {
            colors.Add(cube.GetSticker(adjacentFace, adjacentPosition));
        }
        
        return colors;
    }

    /// <summary>
    /// Maps a corner position to its adjacent corner positions on other faces.
    /// Each corner touches exactly 3 faces, so this returns 2 additional positions.
    /// </summary>
    private static List<(CubeFace face, int position)> GetAdjacentCornerPositions(CubeFace face, int position)
    {
        return (face, position) switch
        {
            // Front face corners
            (CubeFace.Front, 0) => [(CubeFace.Up, 6), (CubeFace.Left, 2)],     // Front top-left
            (CubeFace.Front, 2) => [(CubeFace.Up, 8), (CubeFace.Right, 0)],   // Front top-right
            (CubeFace.Front, 6) => [(CubeFace.Down, 0), (CubeFace.Left, 8)],  // Front bottom-left
            (CubeFace.Front, 8) => [(CubeFace.Down, 2), (CubeFace.Right, 6)], // Front bottom-right

            // Right face corners
            (CubeFace.Right, 0) => [(CubeFace.Up, 8), (CubeFace.Front, 2)],   // Right top-front
            (CubeFace.Right, 2) => [(CubeFace.Up, 2), (CubeFace.Back, 0)],    // Right top-back
            (CubeFace.Right, 6) => [(CubeFace.Down, 2), (CubeFace.Front, 8)], // Right bottom-front
            (CubeFace.Right, 8) => [(CubeFace.Down, 8), (CubeFace.Back, 6)],  // Right bottom-back

            // Back face corners
            (CubeFace.Back, 0) => [(CubeFace.Up, 2), (CubeFace.Right, 2)],    // Back top-right
            (CubeFace.Back, 2) => [(CubeFace.Up, 0), (CubeFace.Left, 0)],     // Back top-left
            (CubeFace.Back, 6) => [(CubeFace.Down, 8), (CubeFace.Right, 8)],  // Back bottom-right
            (CubeFace.Back, 8) => [(CubeFace.Down, 6), (CubeFace.Left, 6)],   // Back bottom-left

            // Left face corners
            (CubeFace.Left, 0) => [(CubeFace.Up, 0), (CubeFace.Back, 2)],     // Left top-back
            (CubeFace.Left, 2) => [(CubeFace.Up, 6), (CubeFace.Front, 0)],    // Left top-front
            (CubeFace.Left, 6) => [(CubeFace.Down, 6), (CubeFace.Back, 8)],   // Left bottom-back
            (CubeFace.Left, 8) => [(CubeFace.Down, 0), (CubeFace.Front, 6)],  // Left bottom-front

            // Up face corners
            (CubeFace.Up, 0) => [(CubeFace.Back, 2), (CubeFace.Left, 0)],     // Up back-left
            (CubeFace.Up, 2) => [(CubeFace.Back, 0), (CubeFace.Right, 2)],    // Up back-right
            (CubeFace.Up, 6) => [(CubeFace.Front, 0), (CubeFace.Left, 2)],    // Up front-left
            (CubeFace.Up, 8) => [(CubeFace.Front, 2), (CubeFace.Right, 0)],   // Up front-right

            // Down face corners
            (CubeFace.Down, 0) => [(CubeFace.Front, 6), (CubeFace.Left, 8)],  // Down front-left
            (CubeFace.Down, 2) => [(CubeFace.Front, 8), (CubeFace.Right, 6)], // Down front-right
            (CubeFace.Down, 6) => [(CubeFace.Back, 8), (CubeFace.Left, 6)],   // Down back-left
            (CubeFace.Down, 8) => [(CubeFace.Back, 6), (CubeFace.Right, 8)],  // Down back-right

            _ => throw new ArgumentException($"Invalid corner position: {face}[{position}]")
        };
    }

    /// <summary>
    /// Gets the 2 colors that make up an edge at the specified position.
    /// This extracts colors from the 2 adjacent faces that meet at this edge.
    /// </summary>
    private static HashSet<CubeColor> GetEdgeColorsAtPosition(Cube cube, CubeFace face, int position)
    {
        var colors = new HashSet<CubeColor>();
        
        // Add the color from the primary face
        colors.Add(cube.GetSticker(face, position));
        
        // Get the adjacent edge position
        var (adjacentFace, adjacentPosition) = GetAdjacentEdgePosition(face, position);
        colors.Add(cube.GetSticker(adjacentFace, adjacentPosition));
        
        return colors;
    }

    /// <summary>
    /// Maps an edge position to its adjacent edge position on another face.
    /// Each edge touches exactly 2 faces, so this returns 1 additional position.
    /// </summary>
    private static (CubeFace face, int position) GetAdjacentEdgePosition(CubeFace face, int position)
    {
        return (face, position) switch
        {
            // Front face edges
            (CubeFace.Front, 1) => (CubeFace.Up, 7),    // Front top edge
            (CubeFace.Front, 3) => (CubeFace.Left, 5),  // Front left edge
            (CubeFace.Front, 5) => (CubeFace.Right, 3), // Front right edge
            (CubeFace.Front, 7) => (CubeFace.Down, 1),  // Front bottom edge

            // Right face edges
            (CubeFace.Right, 1) => (CubeFace.Up, 5),    // Right top edge
            (CubeFace.Right, 3) => (CubeFace.Front, 5), // Right front edge
            (CubeFace.Right, 5) => (CubeFace.Back, 3),  // Right back edge
            (CubeFace.Right, 7) => (CubeFace.Down, 5),  // Right bottom edge

            // Back face edges
            (CubeFace.Back, 1) => (CubeFace.Up, 1),     // Back top edge
            (CubeFace.Back, 3) => (CubeFace.Right, 5),  // Back right edge
            (CubeFace.Back, 5) => (CubeFace.Left, 3),   // Back left edge
            (CubeFace.Back, 7) => (CubeFace.Down, 7),   // Back bottom edge

            // Left face edges
            (CubeFace.Left, 1) => (CubeFace.Up, 3),     // Left top edge
            (CubeFace.Left, 3) => (CubeFace.Back, 5),   // Left back edge
            (CubeFace.Left, 5) => (CubeFace.Front, 3),  // Left front edge
            (CubeFace.Left, 7) => (CubeFace.Down, 3),   // Left bottom edge

            // Up face edges
            (CubeFace.Up, 1) => (CubeFace.Back, 1),     // Up back edge
            (CubeFace.Up, 3) => (CubeFace.Left, 1),     // Up left edge
            (CubeFace.Up, 5) => (CubeFace.Right, 1),    // Up right edge
            (CubeFace.Up, 7) => (CubeFace.Front, 1),    // Up front edge

            // Down face edges
            (CubeFace.Down, 1) => (CubeFace.Front, 7),  // Down front edge
            (CubeFace.Down, 3) => (CubeFace.Left, 7),   // Down left edge
            (CubeFace.Down, 5) => (CubeFace.Right, 7),  // Down right edge
            (CubeFace.Down, 7) => (CubeFace.Back, 7),   // Down back edge

            _ => throw new ArgumentException($"Invalid edge position: {face}[{position}]")
        };
    }
}