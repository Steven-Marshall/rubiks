using RubiksCube.Core.Models;
using RubiksCube.Core.Configuration;
using CSharpFunctionalExtensions;
using System.Text;

namespace RubiksCube.Core.Display;

public class CubeRenderer
{
    private readonly DisplayConfig _config;

    public CubeRenderer(DisplayConfig config)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
    }

    public Result<string> Render(Cube cube)
    {
        if (cube == null)
            return Result.Failure<string>("Cube cannot be null");

        try
        {
            return _config.Format switch
            {
                DisplayFormat.Unicode => RenderUnicode(cube),
                DisplayFormat.ASCII => RenderAscii(cube),
                _ => Result.Failure<string>($"Unsupported display format: {_config.Format}")
            };
        }
        catch (Exception ex)
        {
            return Result.Failure<string>($"Rendering failed: {ex.Message}");
        }
    }

    private Result<string> RenderUnicode(Cube cube)
    {
        var sb = new StringBuilder();
        
        // Get the symbol for each color
        var symbols = GetColorSymbols();
        
        // Get face data based on current orientation
        var up = cube.GetFaceFromCurrentOrientation(CubeFace.Up);
        var left = cube.GetFaceFromCurrentOrientation(CubeFace.Left);
        var front = cube.GetFaceFromCurrentOrientation(CubeFace.Front);
        var right = cube.GetFaceFromCurrentOrientation(CubeFace.Right);
        var back = cube.GetFaceFromCurrentOrientation(CubeFace.Back);
        var down = cube.GetFaceFromCurrentOrientation(CubeFace.Down);

        // Render top face (Up) - aligned with front
        for (int row = 0; row < 3; row++)
        {
            sb.Append("    "); // 4 spaces to align with front face (3 left squares + 1 space)
            for (int col = 0; col < 3; col++)
            {
                var position = row * 3 + col;
                sb.Append(symbols[up[position]]);
            }
            sb.AppendLine();
        }

        // Render middle row (Left, Front, Right, Back)
        for (int row = 0; row < 3; row++)
        {
            // Left face
            for (int col = 0; col < 3; col++)
            {
                var position = row * 3 + col;
                sb.Append(symbols[left[position]]);
            }
            sb.Append(' ');

            // Front face  
            for (int col = 0; col < 3; col++)
            {
                var position = row * 3 + col;
                sb.Append(symbols[front[position]]);
            }
            sb.Append(' ');

            // Right face
            for (int col = 0; col < 3; col++)
            {
                var position = row * 3 + col;
                sb.Append(symbols[right[position]]);
            }
            sb.Append(' ');

            // Back face
            for (int col = 0; col < 3; col++)
            {
                var position = row * 3 + col;
                sb.Append(symbols[back[position]]);
            }
            sb.AppendLine();
        }

        // Render bottom face (Down) - aligned with front
        for (int row = 0; row < 3; row++)
        {
            sb.Append("    "); // 4 spaces to align with front face (3 left squares + 1 space)
            for (int col = 0; col < 3; col++)
            {
                var position = row * 3 + col;
                sb.Append(symbols[down[position]]);
            }
            sb.AppendLine();
        }

        return Result.Success(sb.ToString());
    }

    private Result<string> RenderAscii(Cube cube)
    {
        var sb = new StringBuilder();
        
        // Get the symbol for each color  
        var symbols = GetColorSymbols();
        
        // Same layout as Unicode but with ASCII characters
        var up = cube.GetFaceFromCurrentOrientation(CubeFace.Up);
        var left = cube.GetFaceFromCurrentOrientation(CubeFace.Left);
        var front = cube.GetFaceFromCurrentOrientation(CubeFace.Front);
        var right = cube.GetFaceFromCurrentOrientation(CubeFace.Right);
        var back = cube.GetFaceFromCurrentOrientation(CubeFace.Back);
        var down = cube.GetFaceFromCurrentOrientation(CubeFace.Down);

        // Render top face (Up)
        for (int row = 0; row < 3; row++)
        {
            sb.Append("       "); // 7 spaces to align with front face (5 left chars + 2 spaces)
            for (int col = 0; col < 3; col++)
            {
                var position = row * 3 + col;
                sb.Append(symbols[up[position]]);
                if (col < 2) sb.Append(' '); // Space between letters
            }
            sb.AppendLine();
        }

        // Render middle row
        for (int row = 0; row < 3; row++)
        {
            // Left face
            for (int col = 0; col < 3; col++)
            {
                var position = row * 3 + col;
                sb.Append(symbols[left[position]]);
                if (col < 2) sb.Append(' ');
            }
            sb.Append("  "); // Double space between faces

            // Front face
            for (int col = 0; col < 3; col++)
            {
                var position = row * 3 + col;
                sb.Append(symbols[front[position]]);
                if (col < 2) sb.Append(' ');
            }
            sb.Append("  "); // Double space between faces

            // Right face
            for (int col = 0; col < 3; col++)
            {
                var position = row * 3 + col;
                sb.Append(symbols[right[position]]);
                if (col < 2) sb.Append(' ');
            }
            sb.Append("  "); // Double space between faces

            // Back face
            for (int col = 0; col < 3; col++)
            {
                var position = row * 3 + col;
                sb.Append(symbols[back[position]]);
                if (col < 2) sb.Append(' ');
            }
            sb.AppendLine();
        }

        // Render bottom face (Down)
        for (int row = 0; row < 3; row++)
        {
            sb.Append("       "); // 7 spaces to align with front face (5 left chars + 2 spaces)
            for (int col = 0; col < 3; col++)
            {
                var position = row * 3 + col;
                sb.Append(symbols[down[position]]);
                if (col < 2) sb.Append(' ');
            }
            sb.AppendLine();
        }

        return Result.Success(sb.ToString());
    }

    private Dictionary<CubeColor, string> GetColorSymbols()
    {
        return _config.Format switch
        {
            DisplayFormat.Unicode => new Dictionary<CubeColor, string>
            {
                [CubeColor.White] = _config.Squares.White,
                [CubeColor.Red] = _config.Squares.Red,
                [CubeColor.Blue] = _config.Squares.Blue,
                [CubeColor.Orange] = _config.Squares.Orange,
                [CubeColor.Green] = _config.Squares.Green,
                [CubeColor.Yellow] = _config.Squares.Yellow
            },
            DisplayFormat.ASCII => new Dictionary<CubeColor, string>
            {
                [CubeColor.White] = _config.Letters.White,
                [CubeColor.Red] = _config.Letters.Red,
                [CubeColor.Blue] = _config.Letters.Blue,
                [CubeColor.Orange] = _config.Letters.Orange,
                [CubeColor.Green] = _config.Letters.Green,
                [CubeColor.Yellow] = _config.Letters.Yellow
            },
            _ => throw new InvalidOperationException($"Unsupported display format: {_config.Format}")
        };
    }
}