using RubiksCube.Core.Models;

namespace RubiksCube.Core.Display;

/// <summary>
/// Maps display positions to their adjacent center faces for piece identification.
/// </summary>
public static class DisplayPositionMapping
{
    /// <summary>
    /// Gets the adjacent center faces for a corner position on the display.
    /// Returns the 3 center faces that meet at this corner.
    /// </summary>
    public static (CubeFace, CubeFace, CubeFace) GetAdjacentCentersForCorner(CubeFace displayFace, int row, int col)
    {
        return (displayFace, row, col) switch
        {
            // Front face corners
            (CubeFace.Front, 0, 0) => (CubeFace.Front, CubeFace.Up, CubeFace.Left),      // Front-Top-Left
            (CubeFace.Front, 0, 2) => (CubeFace.Front, CubeFace.Up, CubeFace.Right),    // Front-Top-Right
            (CubeFace.Front, 2, 0) => (CubeFace.Front, CubeFace.Down, CubeFace.Left),   // Front-Bottom-Left
            (CubeFace.Front, 2, 2) => (CubeFace.Front, CubeFace.Down, CubeFace.Right),  // Front-Bottom-Right

            // Right face corners
            (CubeFace.Right, 0, 0) => (CubeFace.Right, CubeFace.Up, CubeFace.Front),    // Right-Top-Front
            (CubeFace.Right, 0, 2) => (CubeFace.Right, CubeFace.Up, CubeFace.Back),     // Right-Top-Back
            (CubeFace.Right, 2, 0) => (CubeFace.Right, CubeFace.Down, CubeFace.Front),  // Right-Bottom-Front
            (CubeFace.Right, 2, 2) => (CubeFace.Right, CubeFace.Down, CubeFace.Back),   // Right-Bottom-Back

            // Back face corners
            (CubeFace.Back, 0, 0) => (CubeFace.Back, CubeFace.Up, CubeFace.Right),      // Back-Top-Right
            (CubeFace.Back, 0, 2) => (CubeFace.Back, CubeFace.Up, CubeFace.Left),       // Back-Top-Left
            (CubeFace.Back, 2, 0) => (CubeFace.Back, CubeFace.Down, CubeFace.Right),    // Back-Bottom-Right
            (CubeFace.Back, 2, 2) => (CubeFace.Back, CubeFace.Down, CubeFace.Left),     // Back-Bottom-Left

            // Left face corners
            (CubeFace.Left, 0, 0) => (CubeFace.Left, CubeFace.Up, CubeFace.Back),       // Left-Top-Back
            (CubeFace.Left, 0, 2) => (CubeFace.Left, CubeFace.Up, CubeFace.Front),      // Left-Top-Front
            (CubeFace.Left, 2, 0) => (CubeFace.Left, CubeFace.Down, CubeFace.Back),     // Left-Bottom-Back
            (CubeFace.Left, 2, 2) => (CubeFace.Left, CubeFace.Down, CubeFace.Front),    // Left-Bottom-Front

            // Up face corners
            (CubeFace.Up, 0, 0) => (CubeFace.Up, CubeFace.Back, CubeFace.Left),         // Up-Back-Left
            (CubeFace.Up, 0, 2) => (CubeFace.Up, CubeFace.Back, CubeFace.Right),        // Up-Back-Right
            (CubeFace.Up, 2, 0) => (CubeFace.Up, CubeFace.Front, CubeFace.Left),        // Up-Front-Left
            (CubeFace.Up, 2, 2) => (CubeFace.Up, CubeFace.Front, CubeFace.Right),       // Up-Front-Right

            // Down face corners
            (CubeFace.Down, 0, 0) => (CubeFace.Down, CubeFace.Front, CubeFace.Left),    // Down-Front-Left
            (CubeFace.Down, 0, 2) => (CubeFace.Down, CubeFace.Front, CubeFace.Right),   // Down-Front-Right
            (CubeFace.Down, 2, 0) => (CubeFace.Down, CubeFace.Back, CubeFace.Left),     // Down-Back-Left
            (CubeFace.Down, 2, 2) => (CubeFace.Down, CubeFace.Back, CubeFace.Right),    // Down-Back-Right

            _ => throw new ArgumentException($"Invalid corner position: {displayFace}[{row},{col}]")
        };
    }

    /// <summary>
    /// Gets the adjacent center faces for an edge position on the display.
    /// Returns the 2 center faces that meet at this edge.
    /// </summary>
    public static (CubeFace, CubeFace) GetAdjacentCentersForEdge(CubeFace displayFace, int row, int col)
    {
        return (displayFace, row, col) switch
        {
            // Front face edges
            (CubeFace.Front, 0, 1) => (CubeFace.Front, CubeFace.Up),    // Front-Top
            (CubeFace.Front, 1, 2) => (CubeFace.Front, CubeFace.Right), // Front-Right
            (CubeFace.Front, 2, 1) => (CubeFace.Front, CubeFace.Down),  // Front-Bottom
            (CubeFace.Front, 1, 0) => (CubeFace.Front, CubeFace.Left),  // Front-Left

            // Right face edges
            (CubeFace.Right, 0, 1) => (CubeFace.Right, CubeFace.Up),    // Right-Top
            (CubeFace.Right, 1, 2) => (CubeFace.Right, CubeFace.Back),  // Right-Back
            (CubeFace.Right, 2, 1) => (CubeFace.Right, CubeFace.Down),  // Right-Bottom
            (CubeFace.Right, 1, 0) => (CubeFace.Right, CubeFace.Front), // Right-Front

            // Back face edges
            (CubeFace.Back, 0, 1) => (CubeFace.Back, CubeFace.Up),      // Back-Top
            (CubeFace.Back, 1, 2) => (CubeFace.Back, CubeFace.Left),    // Back-Left
            (CubeFace.Back, 2, 1) => (CubeFace.Back, CubeFace.Down),    // Back-Bottom
            (CubeFace.Back, 1, 0) => (CubeFace.Back, CubeFace.Right),   // Back-Right

            // Left face edges
            (CubeFace.Left, 0, 1) => (CubeFace.Left, CubeFace.Up),      // Left-Top
            (CubeFace.Left, 1, 2) => (CubeFace.Left, CubeFace.Front),   // Left-Front
            (CubeFace.Left, 2, 1) => (CubeFace.Left, CubeFace.Down),    // Left-Bottom
            (CubeFace.Left, 1, 0) => (CubeFace.Left, CubeFace.Back),    // Left-Back

            // Up face edges
            (CubeFace.Up, 0, 1) => (CubeFace.Up, CubeFace.Back),        // Up-Back
            (CubeFace.Up, 1, 2) => (CubeFace.Up, CubeFace.Right),       // Up-Right
            (CubeFace.Up, 2, 1) => (CubeFace.Up, CubeFace.Front),       // Up-Front
            (CubeFace.Up, 1, 0) => (CubeFace.Up, CubeFace.Left),        // Up-Left

            // Down face edges
            (CubeFace.Down, 0, 1) => (CubeFace.Down, CubeFace.Front),   // Down-Front
            (CubeFace.Down, 1, 2) => (CubeFace.Down, CubeFace.Right),   // Down-Right
            (CubeFace.Down, 2, 1) => (CubeFace.Down, CubeFace.Back),    // Down-Back
            (CubeFace.Down, 1, 0) => (CubeFace.Down, CubeFace.Left),    // Down-Left

            _ => throw new ArgumentException($"Invalid edge position: {displayFace}[{row},{col}]")
        };
    }

    /// <summary>
    /// Checks if a position is a corner (row and col are both 0 or 2).
    /// </summary>
    public static bool IsCornerPosition(int row, int col)
    {
        return (row == 0 || row == 2) && (col == 0 || col == 2);
    }

    /// <summary>
    /// Checks if a position is an edge (exactly one of row or col is 1, the other is 0 or 2).
    /// </summary>
    public static bool IsEdgePosition(int row, int col)
    {
        return (row == 1 && (col == 0 || col == 2)) || 
               (col == 1 && (row == 0 || row == 2));
    }

    /// <summary>
    /// Checks if a position is the center (row and col are both 1).
    /// </summary>
    public static bool IsCenterPosition(int row, int col)
    {
        return row == 1 && col == 1;
    }
}