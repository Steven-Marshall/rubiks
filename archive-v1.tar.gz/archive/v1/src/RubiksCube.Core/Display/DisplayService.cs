using RubiksCube.Core.Models;
using RubiksCube.Core.Configuration;
using CSharpFunctionalExtensions;

namespace RubiksCube.Core.Display;

public class DisplayService
{
    public static Result<string> DisplayCube(Cube cube)
    {
        return ConfigurationManager.LoadDisplayConfig()
            .Bind(config => DisplayCubeWithConfig(cube, config));
    }

    public static Result<string> DisplayCubeWithConfig(Cube cube, DisplayConfig config, bool useCenterBasedRenderer = false)
    {
        if (cube == null)
            return Result.Failure<string>("Cube cannot be null");
        
        if (config == null)
            return Result.Failure<string>("Display configuration cannot be null");

        if (useCenterBasedRenderer)
        {
            var centerBasedRenderer = new CenterBasedRenderer(config);
            return centerBasedRenderer.Render(cube);
        }
        else
        {
            var renderer = new CubeRenderer(config);
            return renderer.Render(cube);
        }
    }

    public static Result<string> DisplayCubeJson(string cubeJson)
    {
        if (string.IsNullOrWhiteSpace(cubeJson))
            return Result.Failure<string>("Cube JSON cannot be empty");

        try
        {
            var cube = Cube.FromJson(cubeJson);
            return DisplayCube(cube);
        }
        catch (Exception ex)
        {
            return Result.Failure<string>($"Invalid cube JSON: {ex.Message}");
        }
    }

    public static Result<DisplayConfig> GetDefaultConfig()
    {
        return Result.Success(new DisplayConfig());
    }

    public static Result<string> GetConfigInfo()
    {
        var configPath = ConfigurationManager.GetConfigFilePath();
        var exists = ConfigurationManager.ConfigExists();
        
        return ConfigurationManager.LoadDisplayConfig()
            .Map(config => $"Configuration: {(exists ? "Loaded" : "Default")}\n" +
                          $"Path: {configPath}\n" +
                          $"Format: {config.Format}\n" +
                          $"Color Mode: {config.ColorMode}\n" +
                          $"Unicode Squares: {config.Squares.White}{config.Squares.Red}{config.Squares.Blue}{config.Squares.Orange}{config.Squares.Green}{config.Squares.Yellow}");
    }

    public static Result SaveConfig(DisplayConfig config)
    {
        return ConfigurationManager.SaveDisplayConfig(config);
    }

    public static Result ResetConfig()
    {
        return ConfigurationManager.DeleteConfig();
    }
}