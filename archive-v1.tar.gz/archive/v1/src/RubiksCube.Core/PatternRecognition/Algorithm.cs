using RubiksCube.Core.Models;

namespace RubiksCube.Core.PatternRecognition;

/// <summary>
/// Represents a sequence of moves that can be applied to solve a cube or perform a specific operation
/// </summary>
public class Algorithm
{
    public IReadOnlyList<Move> Moves { get; }
    
    public Algorithm(IEnumerable<Move> moves)
    {
        Moves = moves?.ToList() ?? throw new ArgumentNullException(nameof(moves));
    }
    
    public Algorithm(params Move[] moves) : this((IEnumerable<Move>)moves)
    {
    }
    
    /// <summary>
    /// Creates an empty algorithm (no moves)
    /// </summary>
    public static Algorithm Empty => new(Array.Empty<Move>());
    
    /// <summary>
    /// Returns the algorithm as a space-separated string in Singmaster notation
    /// </summary>
    public override string ToString()
    {
        return string.Join(" ", Moves.Select(m => m.ToString()));
    }
    
    /// <summary>
    /// Gets the total number of moves in this algorithm
    /// </summary>
    public int MoveCount => Moves.Count;
    
    /// <summary>
    /// Checks if this algorithm is empty (contains no moves)
    /// </summary>
    public bool IsEmpty => Moves.Count == 0;
    
    /// <summary>
    /// Combines this algorithm with another algorithm
    /// </summary>
    public Algorithm Combine(Algorithm other)
    {
        if (other == null) throw new ArgumentNullException(nameof(other));
        return new Algorithm(Moves.Concat(other.Moves));
    }
    
    /// <summary>
    /// Creates the inverse of this algorithm (all moves in reverse order with inverse moves)
    /// </summary>
    public Algorithm GetInverse()
    {
        return new Algorithm(Moves.Reverse().Select(m => m.GetInverse()));
    }
    
    public override bool Equals(object? obj)
    {
        if (obj is not Algorithm other) return false;
        return Moves.SequenceEqual(other.Moves);
    }
    
    public override int GetHashCode()
    {
        return Moves.Aggregate(0, (hash, move) => hash ^ move.GetHashCode());
    }
}