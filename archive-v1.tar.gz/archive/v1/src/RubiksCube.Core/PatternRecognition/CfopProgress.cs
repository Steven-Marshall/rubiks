namespace RubiksCube.Core.PatternRecognition;

/// <summary>
/// Represents the overall progress through the CFOP solving method
/// </summary>
public class CfopProgress
{
    /// <summary>
    /// Current overall CFOP state
    /// </summary>
    public CfopState CurrentState { get; }
    
    /// <summary>
    /// Progress through each CFOP step
    /// </summary>
    public Dictionary<CfopStep, StepAnalysisResult> StepProgress { get; }
    
    /// <summary>
    /// Overall completion percentage (0-100)
    /// </summary>
    public int CompletionPercentage { get; }
    
    /// <summary>
    /// Next recommended step to work on
    /// </summary>
    public CfopStep? NextStep { get; }
    
    /// <summary>
    /// Human-readable summary of current progress
    /// </summary>
    public string Summary { get; }
    
    public CfopProgress(CfopState currentState, Dictionary<CfopStep, StepAnalysisResult> stepProgress, 
                       int completionPercentage, CfopStep? nextStep, string summary)
    {
        CurrentState = currentState;
        StepProgress = stepProgress;
        CompletionPercentage = completionPercentage;
        NextStep = nextStep;
        Summary = summary;
    }
    
    /// <summary>
    /// Gets the analysis result for a specific step
    /// </summary>
    public StepAnalysisResult? GetStepResult(CfopStep step)
        => StepProgress.TryGetValue(step, out var result) ? result : null;
    
    /// <summary>
    /// Checks if a specific step is complete
    /// </summary>
    public bool IsStepComplete(CfopStep step)
        => GetStepResult(step)?.IsComplete ?? false;
        
    public override string ToString()
        => $"{CurrentState} ({CompletionPercentage}%) - {Summary}";
}