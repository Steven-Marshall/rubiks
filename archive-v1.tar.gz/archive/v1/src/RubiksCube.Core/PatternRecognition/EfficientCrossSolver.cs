using CSharpFunctionalExtensions;
using RubiksCube.Core.Models;

namespace RubiksCube.Core.PatternRecognition;

/// <summary>
/// Efficient cross solver that uses heuristics and patterns for good performance.
/// Balances speed and move count for practical solving.
/// </summary>
public class EfficientCrossSolver : CrossSolverBase
{
    public EfficientCrossSolver(CrossAnalyzer analyzer) : base(analyzer)
    {
    }

    public override Result<Algorithm> Solve(Cube cube)
    {
        try
        {
            // For now, use the intuitive solver as the efficient approach
            // In future iterations, this can be enhanced with better heuristics
            var intuitiveSolver = new IntuitiveCrossSolver(_analyzer);
            var result = intuitiveSolver.Solve(cube);
            
            if (result.IsFailure)
                return result;

            // Apply some basic optimizations
            var optimized = OptimizeAlgorithm(result.Value);
            return Result.Success(optimized);
        }
        catch (Exception ex)
        {
            return Result.Failure<Algorithm>($"Error in efficient cross solving: {ex.Message}");
        }
    }

    /// <summary>
    /// Applies basic optimizations to reduce move count
    /// </summary>
    private Algorithm OptimizeAlgorithm(Algorithm algorithm)
    {
        var moves = algorithm.Moves.ToList();
        
        // Remove redundant moves (e.g., F F' = nothing, F F F = F')
        var optimized = new List<Move>();
        
        for (int i = 0; i < moves.Count; i++)
        {
            var currentMove = moves[i];
            
            // Look ahead to see if we can combine moves
            var combinedMove = currentMove;
            int skipCount = 0;
            
            // Combine consecutive moves on the same face
            for (int j = i + 1; j < moves.Count && j < i + 4; j++)
            {
                if (moves[j].Face != currentMove.Face)
                    break;
                    
                // Combine the moves
                var totalRotation = (int)combinedMove.Type + (int)moves[j].Type;
                
                // Normalize rotation (mod 4, since 4 quarter turns = identity)
                totalRotation = ((totalRotation % 4) + 4) % 4;
                
                if (totalRotation == 0)
                {
                    // Moves cancel out completely
                    combinedMove = null;
                    skipCount = j - i;
                    break;
                }
                
                // Convert back to MoveType
                combinedMove = totalRotation switch
                {
                    1 => new Move(currentMove.Face, MoveType.Clockwise),
                    2 => new Move(currentMove.Face, MoveType.Double),
                    3 => new Move(currentMove.Face, MoveType.CounterClockwise),
                    _ => currentMove
                };
                
                skipCount = j - i;
            }
            
            if (combinedMove != null)
            {
                optimized.Add(combinedMove);
            }
            
            i += skipCount;
        }
        
        return new Algorithm(optimized);
    }
}