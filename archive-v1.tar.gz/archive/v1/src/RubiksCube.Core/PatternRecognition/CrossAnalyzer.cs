using CSharpFunctionalExtensions;
using RubiksCube.Core.Models;

namespace RubiksCube.Core.PatternRecognition;

/// <summary>
/// Dedicated analyzer for cross detection and partial completion tracking.
/// Provides detailed analysis of cross state including which edges are complete.
/// </summary>
public class CrossAnalyzer
{
    /// <summary>
    /// Analyzes the current cross state and returns detailed information.
    /// </summary>
    public CrossAnalysisResult AnalyzeCross(Cube cube)
    {
        var edgeResults = new List<CrossEdgeResult>();
        var sideFaces = new[] { CubeFace.Front, CubeFace.Right, CubeFace.Back, CubeFace.Left };
        var crossEdgeNames = new[] { "Front", "Right", "Back", "Left" };
        
        for (int i = 0; i < sideFaces.Length; i++)
        {
            var edgeResult = AnalyzeCrossEdge(cube, sideFaces[i], crossEdgeNames[i]);
            edgeResults.Add(edgeResult);
        }
        
        var completedEdges = edgeResults.Count(e => e.IsComplete);
        var isComplete = completedEdges == 4;
        
        return new CrossAnalysisResult(
            isComplete, 
            completedEdges, 
            edgeResults, 
            GenerateCrossDescription(completedEdges, edgeResults)
        );
    }
    
    /// <summary>
    /// Analyzes a specific cross edge to determine if it's in the correct position.
    /// </summary>
    public CrossEdgeResult AnalyzeCrossEdge(Cube cube, CubeFace sideFace, string edgeName)
    {
        var bottomFace = cube.GetFaceFromCurrentOrientation(CubeFace.Down);
        var bottomCenter = bottomFace[4];
        var sideFaceColors = cube.GetFaceFromCurrentOrientation(sideFace);
        var sideCenter = sideFaceColors[4];
        
        // Get the cross edge positions
        var (bottomPosition, sidePosition) = GetCrossEdgePositions(sideFace);
        var bottomEdgeColor = bottomFace[bottomPosition];
        var sideEdgeColor = sideFaceColors[sidePosition];
        
        // Check if edge is correctly placed
        var isBottomCorrect = bottomEdgeColor == bottomCenter;
        var isSideCorrect = sideEdgeColor == sideCenter;
        var isComplete = isBottomCorrect && isSideCorrect;
        
        // Determine edge status
        var status = DetermineEdgeStatus(isBottomCorrect, isSideCorrect, bottomEdgeColor, sideEdgeColor, bottomCenter, sideCenter);
        
        return new CrossEdgeResult(
            edgeName,
            sideFace,
            isComplete,
            status,
            bottomEdgeColor,
            sideEdgeColor,
            bottomCenter,
            sideCenter
        );
    }
    
    /// <summary>
    /// Finds cross edges that are currently in the wrong position but could be moved to complete the cross.
    /// </summary>
    public Result<List<CrossEdgeLocation>> FindMisplacedCrossEdges(Cube cube)
    {
        var misplacedEdges = new List<CrossEdgeLocation>();
        var targetColors = GetCrossTargetColors(cube);
        
        // Check all positions on the cube for cross pieces that belong in the cross
        var locations = GetAllEdgeLocations();
        
        foreach (var location in locations)
        {
            var edgeColors = GetEdgeColorsAtLocation(cube, location);
            if (IsTargetCrossEdge(edgeColors, targetColors))
            {
                var targetPosition = DetermineTargetCrossPosition(edgeColors, targetColors);
                if (targetPosition != location)
                {
                    misplacedEdges.Add(new CrossEdgeLocation(
                        location,
                        targetPosition,
                        edgeColors.Item1,
                        edgeColors.Item2
                    ));
                }
            }
        }
        
        return Result.Success(misplacedEdges);
    }
    
    private (int bottomPosition, int sidePosition) GetCrossEdgePositions(CubeFace sideFace)
    {
        return sideFace switch
        {
            CubeFace.Front => (1, 7), // Bottom face position 1, Front face position 7
            CubeFace.Right => (3, 5), // Bottom face position 3, Right face position 5  
            CubeFace.Back => (5, 1),  // Bottom face position 5, Back face position 1
            CubeFace.Left => (7, 3),  // Bottom face position 7, Left face position 3
            _ => throw new ArgumentException($"Invalid side face for cross: {sideFace}")
        };
    }
    
    private string DetermineEdgeStatus(bool isBottomCorrect, bool isSideCorrect, 
        CubeColor bottomColor, CubeColor sideColor, CubeColor bottomCenter, CubeColor sideCenter)
    {
        if (isBottomCorrect && isSideCorrect)
            return "Complete";
        
        if (isBottomCorrect && !isSideCorrect)
            return "Correct bottom, wrong side orientation";
        
        if (!isBottomCorrect && isSideCorrect)
            return "Correct side, wrong bottom position";
        
        // Check if colors are flipped (edge is there but flipped)
        if (bottomColor == sideCenter && sideColor == bottomCenter)
            return "Flipped - needs orientation";
        
        return "Misplaced - wrong position";
    }
    
    private Dictionary<CubeFace, CubeColor> GetCrossTargetColors(Cube cube)
    {
        var targetColors = new Dictionary<CubeFace, CubeColor>();
        var faces = new[] { CubeFace.Down, CubeFace.Front, CubeFace.Right, CubeFace.Back, CubeFace.Left };
        
        foreach (var face in faces)
        {
            var faceColors = cube.GetFaceFromCurrentOrientation(face);
            targetColors[face] = faceColors[4]; // Center color
        }
        
        return targetColors;
    }
    
    private List<EdgeLocation> GetAllEdgeLocations()
    {
        var locations = new List<EdgeLocation>();
        
        // Add all edge positions for each face
        var faces = Enum.GetValues<CubeFace>();
        var edgePositions = new[] { 1, 3, 5, 7 }; // Edge positions in the 0-8 layout
        
        foreach (var face in faces)
        {
            foreach (var position in edgePositions)
            {
                locations.Add(new EdgeLocation(face, position));
            }
        }
        
        return locations;
    }
    
    private (CubeColor, CubeColor) GetEdgeColorsAtLocation(Cube cube, EdgeLocation location)
    {
        var faceColors = cube.GetFaceFromCurrentOrientation(location.Face);
        var primaryColor = faceColors[location.Position];
        
        // Get the adjacent face and position for this edge
        var adjacentInfo = GetAdjacentFaceInfo(location.Face, location.Position);
        var adjacentColors = cube.GetFaceFromCurrentOrientation(adjacentInfo.face);
        var secondaryColor = adjacentColors[adjacentInfo.position];
        
        return (primaryColor, secondaryColor);
    }
    
    private (CubeFace face, int position) GetAdjacentFaceInfo(CubeFace face, int edgePosition)
    {
        // Complete mapping of all edge positions to their adjacent faces
        // Using standard cube layout: 0-8 positions where edges are at 1, 3, 5, 7
        return face switch
        {
            // Down face edges
            CubeFace.Down when edgePosition == 1 => (CubeFace.Front, 7),
            CubeFace.Down when edgePosition == 3 => (CubeFace.Right, 5),
            CubeFace.Down when edgePosition == 5 => (CubeFace.Back, 1),
            CubeFace.Down when edgePosition == 7 => (CubeFace.Left, 3),
            
            // Up face edges
            CubeFace.Up when edgePosition == 1 => (CubeFace.Back, 5),
            CubeFace.Up when edgePosition == 3 => (CubeFace.Right, 1),
            CubeFace.Up when edgePosition == 5 => (CubeFace.Front, 1),
            CubeFace.Up when edgePosition == 7 => (CubeFace.Left, 1),
            
            // Front face edges
            CubeFace.Front when edgePosition == 1 => (CubeFace.Up, 5),
            CubeFace.Front when edgePosition == 3 => (CubeFace.Right, 7),
            CubeFace.Front when edgePosition == 5 => (CubeFace.Down, 1),
            CubeFace.Front when edgePosition == 7 => (CubeFace.Left, 5),
            
            // Back face edges  
            CubeFace.Back when edgePosition == 1 => (CubeFace.Down, 5),
            CubeFace.Back when edgePosition == 3 => (CubeFace.Left, 7),
            CubeFace.Back when edgePosition == 5 => (CubeFace.Up, 1),
            CubeFace.Back when edgePosition == 7 => (CubeFace.Right, 3),
            
            // Right face edges
            CubeFace.Right when edgePosition == 1 => (CubeFace.Up, 3),
            CubeFace.Right when edgePosition == 3 => (CubeFace.Back, 7),
            CubeFace.Right when edgePosition == 5 => (CubeFace.Down, 3),
            CubeFace.Right when edgePosition == 7 => (CubeFace.Front, 3),
            
            // Left face edges
            CubeFace.Left when edgePosition == 1 => (CubeFace.Up, 7),
            CubeFace.Left when edgePosition == 3 => (CubeFace.Front, 7),
            CubeFace.Left when edgePosition == 5 => (CubeFace.Down, 7),
            CubeFace.Left when edgePosition == 7 => (CubeFace.Back, 3),
            
            _ => throw new ArgumentException($"No adjacent mapping for {face} position {edgePosition}")
        };
    }
    
    private bool IsTargetCrossEdge((CubeColor, CubeColor) edgeColors, Dictionary<CubeFace, CubeColor> targetColors)
    {
        var (color1, color2) = edgeColors;
        var downColor = targetColors[CubeFace.Down];
        
        // One color must be the bottom/down color, and the other must be a side color
        if (color1 == downColor)
            return targetColors.Values.Contains(color2);
        if (color2 == downColor)
            return targetColors.Values.Contains(color1);
            
        return false;
    }
    
    private EdgeLocation DetermineTargetCrossPosition((CubeColor, CubeColor) edgeColors, Dictionary<CubeFace, CubeColor> targetColors)
    {
        var (color1, color2) = edgeColors;
        var downColor = targetColors[CubeFace.Down];
        
        // Determine which side face this edge belongs to
        CubeFace targetSideFace;
        if (color1 == downColor)
        {
            targetSideFace = targetColors.First(kvp => kvp.Value == color2).Key;
        }
        else if (color2 == downColor)
        {
            targetSideFace = targetColors.First(kvp => kvp.Value == color1).Key;
        }
        else
        {
            throw new ArgumentException("Edge does not contain bottom color");
        }
        
        // Return the cross position for this side face
        var (bottomPos, _) = GetCrossEdgePositions(targetSideFace);
        return new EdgeLocation(CubeFace.Down, bottomPos);
    }
    
    private string GenerateCrossDescription(int completedEdges, List<CrossEdgeResult> edgeResults)
    {
        if (completedEdges == 4)
            return "Cross is complete - all edges in place";
        
        if (completedEdges == 0)
            return "No cross edges in place";
        
        var completedNames = edgeResults.Where(e => e.IsComplete).Select(e => e.EdgeName);
        var incompleteNames = edgeResults.Where(e => !e.IsComplete).Select(e => e.EdgeName);
        
        return $"{completedEdges}/4 edges complete. " +
               $"Complete: [{string.Join(", ", completedNames)}]. " +
               $"Remaining: [{string.Join(", ", incompleteNames)}].";
    }
}

/// <summary>
/// Result of cross analysis containing completion status and detailed edge information.
/// </summary>
public record CrossAnalysisResult(
    bool IsComplete,
    int CompletedEdges,
    List<CrossEdgeResult> EdgeResults,
    string Description
);

/// <summary>
/// Result of analyzing a specific cross edge.
/// </summary>
public record CrossEdgeResult(
    string EdgeName,
    CubeFace SideFace,
    bool IsComplete,
    string Status,
    CubeColor BottomColor,
    CubeColor SideColor,
    CubeColor ExpectedBottomColor,
    CubeColor ExpectedSideColor
);

/// <summary>
/// Represents the location of an edge piece on the cube.
/// </summary>
public record EdgeLocation(CubeFace Face, int Position);

/// <summary>
/// Represents a cross edge that is currently misplaced.
/// </summary>
public record CrossEdgeLocation(
    EdgeLocation CurrentLocation,
    EdgeLocation TargetLocation,
    CubeColor Color1,
    CubeColor Color2
);