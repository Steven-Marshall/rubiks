using CSharpFunctionalExtensions;
using RubiksCube.Core.Models;

namespace RubiksCube.Core.PatternRecognition;

/// <summary>
/// Optimal cross solver that finds the shortest possible solution using breadth-first search.
/// Guarantees solutions within 8 moves but may take longer to compute.
/// </summary>
public class OptimalCrossSolver : CrossSolverBase
{
    private const int MAX_DEPTH = 8; // Cross can always be solved in 8 moves or less
    private readonly Move[] _availableMoves;

    public OptimalCrossSolver(CrossAnalyzer analyzer) : base(analyzer)
    {
        // Define all possible face moves (18 total: 6 faces × 3 move types)
        _availableMoves = new[]
        {
            new Move(CubeFace.Front, MoveType.Clockwise),
            new Move(CubeFace.Front, MoveType.CounterClockwise),
            new Move(CubeFace.Front, MoveType.Double),
            new Move(CubeFace.Right, MoveType.Clockwise),
            new Move(CubeFace.Right, MoveType.CounterClockwise),
            new Move(CubeFace.Right, MoveType.Double),
            new Move(CubeFace.Back, MoveType.Clockwise),
            new Move(CubeFace.Back, MoveType.CounterClockwise),
            new Move(CubeFace.Back, MoveType.Double),
            new Move(CubeFace.Left, MoveType.Clockwise),
            new Move(CubeFace.Left, MoveType.CounterClockwise),
            new Move(CubeFace.Left, MoveType.Double),
            new Move(CubeFace.Up, MoveType.Clockwise),
            new Move(CubeFace.Up, MoveType.CounterClockwise),
            new Move(CubeFace.Up, MoveType.Double),
            new Move(CubeFace.Down, MoveType.Clockwise),
            new Move(CubeFace.Down, MoveType.CounterClockwise),
            new Move(CubeFace.Down, MoveType.Double)
        };
    }

    public override Result<Algorithm> Solve(Cube cube)
    {
        try
        {
            // Use breadth-first search to find optimal solution
            var solution = BreadthFirstSearch(cube);
            
            if (solution == null)
                return Result.Failure<Algorithm>("No solution found within move limit");

            var algorithm = new Algorithm(solution);
            
            // Validate the solution
            var validation = ValidateSolution(cube, algorithm);
            if (validation.IsFailure)
                return Result.Failure<Algorithm>($"Solution validation failed: {validation.Error}");

            return Result.Success(algorithm);
        }
        catch (Exception ex)
        {
            return Result.Failure<Algorithm>($"Error in optimal cross solving: {ex.Message}");
        }
    }

    /// <summary>
    /// Performs breadth-first search to find the shortest solution
    /// </summary>
    private List<Move>? BreadthFirstSearch(Cube initialCube)
    {
        // BFS queue: each item contains (cube state, moves to reach this state)
        var queue = new Queue<(Cube cube, List<Move> moves)>();
        var visited = new HashSet<string>(); // Use cube state hash to avoid revisiting

        // Start with the initial cube
        queue.Enqueue((initialCube.Clone(), new List<Move>()));
        visited.Add(GetCubeStateHash(initialCube));

        while (queue.Count > 0)
        {
            var (currentCube, currentMoves) = queue.Dequeue();

            // Check if cross is solved
            var analysis = _analyzer.AnalyzeCross(currentCube);
            if (analysis.IsComplete)
                return currentMoves;

            // Don't search beyond maximum depth
            if (currentMoves.Count >= MAX_DEPTH)
                continue;

            // Try all possible moves
            foreach (var move in _availableMoves)
            {
                // Create new state
                var newCube = currentCube.Clone();
                var result = newCube.ApplyMove(move);
                
                if (result.IsFailure)
                    continue; // Skip invalid moves

                var stateHash = GetCubeStateHash(newCube);
                
                // Skip if we've seen this state before
                if (visited.Contains(stateHash))
                    continue;

                visited.Add(stateHash);
                
                var newMoves = new List<Move>(currentMoves) { move };
                queue.Enqueue((newCube, newMoves));
            }
        }

        // No solution found
        return null;
    }

    /// <summary>
    /// Generates a hash string representing the cube's state for duplicate detection
    /// </summary>
    private string GetCubeStateHash(Cube cube)
    {
        // Simple approach: concatenate all sticker colors
        // This could be optimized for better performance but works for our purposes
        var hash = "";
        
        foreach (var face in Enum.GetValues<CubeFace>())
        {
            var faceColors = cube.GetFaceFromCurrentOrientation(face);
            for (int i = 0; i < 9; i++)
            {
                hash += ((int)faceColors[i]).ToString();
            }
        }
        
        return hash;
    }
}