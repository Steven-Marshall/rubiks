namespace RubiksCube.Core.PatternRecognition;

/// <summary>
/// Represents a pattern match with confidence score and additional metadata
/// </summary>
/// <typeparam name="TPattern">The type of pattern matched</typeparam>
public class PatternMatch<TPattern>
{
    /// <summary>
    /// The matched pattern
    /// </summary>
    public TPattern Pattern { get; }
    
    /// <summary>
    /// Confidence score from 0.0 (no match) to 1.0 (perfect match)
    /// </summary>
    public double Confidence { get; }
    
    /// <summary>
    /// Optional description of the pattern match
    /// </summary>
    public string? Description { get; }
    
    /// <summary>
    /// Additional metadata about the match
    /// </summary>
    public Dictionary<string, object> Metadata { get; }
    
    public PatternMatch(TPattern pattern, double confidence, string? description = null)
    {
        Pattern = pattern;
        Confidence = confidence;
        Description = description;
        Metadata = new Dictionary<string, object>();
    }
    
    /// <summary>
    /// Creates a perfect match (confidence = 1.0)
    /// </summary>
    public static PatternMatch<TPattern> Perfect(TPattern pattern, string? description = null)
        => new(pattern, 1.0, description);
    
    /// <summary>
    /// Creates a partial match with specified confidence
    /// </summary>
    public static PatternMatch<TPattern> Partial(TPattern pattern, double confidence, string? description = null)
        => new(pattern, confidence, description);
        
    public override string ToString()
        => $"{Pattern} (confidence: {Confidence:F2})";
}