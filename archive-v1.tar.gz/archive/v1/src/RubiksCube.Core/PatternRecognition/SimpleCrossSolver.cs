using CSharpFunctionalExtensions;
using RubiksCube.Core.Models;

namespace RubiksCube.Core.PatternRecognition;

/// <summary>
/// Very simple cross solver for testing and basic functionality
/// Uses the reverse of the move that broke the cross
/// </summary>
public class SimpleCrossSolver : CrossSolverBase
{
    public SimpleCrossSolver(CrossAnalyzer analyzer) : base(analyzer)
    {
    }

    public override Result<Algorithm> Solve(Cube cube)
    {
        try
        {
            // Simple strategy: try common moves until cross is solved
            var commonMoves = new[]
            {
                new Move(CubeFace.Front, MoveType.CounterClockwise), // F'
                new Move(CubeFace.Front, MoveType.Clockwise),        // F
                new Move(CubeFace.Front, MoveType.Double),           // F2
                new Move(CubeFace.Right, MoveType.CounterClockwise), // R'
                new Move(CubeFace.Right, MoveType.Clockwise),        // R
                new Move(CubeFace.Right, MoveType.Double),           // R2
                new Move(CubeFace.Up, MoveType.Clockwise),           // U
                new Move(CubeFace.Up, MoveType.CounterClockwise),    // U'
                new Move(CubeFace.Up, MoveType.Double),              // U2
            };

            return FindSolutionWithBruteForce(cube, commonMoves, 4); // Try up to 4 moves
        }
        catch (Exception ex)
        {
            return Result.Failure<Algorithm>($"Error in simple cross solving: {ex.Message}");
        }
    }

    private Result<Algorithm> FindSolutionWithBruteForce(Cube cube, Move[] moves, int maxDepth)
    {
        // Try single moves first
        foreach (var move in moves)
        {
            var testCube = cube.Clone();
            testCube.ApplyMove(move);
            
            var analysis = _analyzer.AnalyzeCross(testCube);
            if (analysis.IsComplete)
            {
                return Result.Success(new Algorithm(move));
            }
        }

        // Try 2-move combinations
        if (maxDepth >= 2)
        {
            foreach (var move1 in moves)
            {
                foreach (var move2 in moves)
                {
                    var testCube = cube.Clone();
                    testCube.ApplyMove(move1);
                    testCube.ApplyMove(move2);
                    
                    var analysis = _analyzer.AnalyzeCross(testCube);
                    if (analysis.IsComplete)
                    {
                        return Result.Success(new Algorithm(move1, move2));
                    }
                }
            }
        }

        // Try 3-move combinations
        if (maxDepth >= 3)
        {
            foreach (var move1 in moves)
            {
                foreach (var move2 in moves)
                {
                    foreach (var move3 in moves)
                    {
                        var testCube = cube.Clone();
                        testCube.ApplyMove(move1);
                        testCube.ApplyMove(move2);
                        testCube.ApplyMove(move3);
                        
                        var analysis = _analyzer.AnalyzeCross(testCube);
                        if (analysis.IsComplete)
                        {
                            return Result.Success(new Algorithm(move1, move2, move3));
                        }
                    }
                }
            }
        }

        // Try 4-move combinations
        if (maxDepth >= 4)
        {
            foreach (var move1 in moves)
            {
                foreach (var move2 in moves)
                {
                    foreach (var move3 in moves)
                    {
                        foreach (var move4 in moves)
                        {
                            var testCube = cube.Clone();
                            testCube.ApplyMove(move1);
                            testCube.ApplyMove(move2);
                            testCube.ApplyMove(move3);
                            testCube.ApplyMove(move4);
                            
                            var analysis = _analyzer.AnalyzeCross(testCube);
                            if (analysis.IsComplete)
                            {
                                return Result.Success(new Algorithm(move1, move2, move3, move4));
                            }
                        }
                    }
                }
            }
        }

        return Result.Failure<Algorithm>("No solution found within move limit");
    }
}