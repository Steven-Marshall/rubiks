namespace RubiksCube.Core.PatternRecognition;

/// <summary>
/// Detailed analysis result for a specific CFOP step
/// </summary>
public class StepAnalysisResult
{
    /// <summary>
    /// The CFOP step that was analyzed
    /// </summary>
    public CfopStep Step { get; }
    
    /// <summary>
    /// Whether this step is complete
    /// </summary>
    public bool IsComplete { get; }
    
    /// <summary>
    /// Progress within this step (e.g., 2/4 for cross edges)
    /// </summary>
    public string Progress { get; }
    
    /// <summary>
    /// Detailed description of the current state
    /// </summary>
    public string Description { get; }
    
    /// <summary>
    /// Additional step-specific information
    /// </summary>
    public Dictionary<string, object> StepData { get; }
    
    public StepAnalysisResult(CfopStep step, bool isComplete, string progress, string description)
    {
        Step = step;
        IsComplete = isComplete;
        Progress = progress;
        Description = description;
        StepData = new Dictionary<string, object>();
    }
    
    /// <summary>
    /// Creates a completed step result
    /// </summary>
    public static StepAnalysisResult Completed(CfopStep step, string description = "")
        => new(step, true, "Complete", description);
    
    /// <summary>
    /// Creates an incomplete step result with progress information
    /// </summary>
    public static StepAnalysisResult InProgress(CfopStep step, string progress, string description = "")
        => new(step, false, progress, description);
    
    /// <summary>
    /// Creates a not started step result
    /// </summary>
    public static StepAnalysisResult NotStarted(CfopStep step, string description = "")
        => new(step, false, "Not started", description);
        
    public override string ToString()
        => $"{Step}: {Progress}";
}