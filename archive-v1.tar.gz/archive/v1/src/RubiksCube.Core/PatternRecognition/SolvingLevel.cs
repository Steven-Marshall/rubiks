namespace RubiksCube.Core.PatternRecognition;

/// <summary>
/// Represents different solving approaches with trade-offs between speed and optimality
/// </summary>
public enum SolvingLevel
{
    /// <summary>
    /// Beginner-friendly solving with clear, understandable steps.
    /// May use more moves but follows intuitive patterns.
    /// </summary>
    Beginner,
    
    /// <summary>
    /// Efficient solving that balances speed and move count.
    /// Uses heuristics and patterns for good performance.
    /// </summary>
    Efficient,
    
    /// <summary>
    /// Optimal solving that finds shortest possible solution.
    /// May take longer to compute but guarantees minimal moves.
    /// </summary>
    Optimal
}