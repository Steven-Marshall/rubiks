using CSharpFunctionalExtensions;
using RubiksCube.Core.Models;

namespace RubiksCube.Core.PatternRecognition;

/// <summary>
/// Simplified implementation of CFOP state analysis for basic state recognition
/// </summary>
public class SimpleCfopStateAnalyzer : ICubeStateAnalyzer
{
    public CfopState AnalyzeState(Cube cube)
    {
        if (IsSolved(cube))
            return CfopState.Solved;
            
        if (IsPllComplete(cube))
            return CfopState.PLL;
            
        if (IsOllComplete(cube))
            return CfopState.OLL;
            
        if (IsF2lComplete(cube))
            return CfopState.F2L;
            
        if (IsCrossComplete(cube))
            return CfopState.Cross;
            
        return CfopState.Scrambled;
    }

    public Result<StepAnalysisResult> AnalyzeStep(Cube cube, CfopStep step)
    {
        try
        {
            return step switch
            {
                CfopStep.Cross => AnalyzeCrossStep(cube),
                CfopStep.F2L => AnalyzeF2lStep(cube),
                CfopStep.OLL => AnalyzeOllStep(cube),
                CfopStep.PLL => AnalyzePllStep(cube),
                _ => Result.Failure<StepAnalysisResult>($"Unknown CFOP step: {step}")
            };
        }
        catch (Exception ex)
        {
            return Result.Failure<StepAnalysisResult>($"Error analyzing {step}: {ex.Message}");
        }
    }

    public CfopProgress GetProgress(Cube cube)
    {
        var currentState = AnalyzeState(cube);
        var stepProgress = new Dictionary<CfopStep, StepAnalysisResult>();
        
        // Analyze each step
        foreach (CfopStep step in Enum.GetValues<CfopStep>())
        {
            var stepResult = AnalyzeStep(cube, step);
            if (stepResult.IsSuccess)
            {
                stepProgress[step] = stepResult.Value;
            }
        }
        
        // Calculate completion percentage and next step
        var (completionPercentage, nextStep) = CalculateProgress(currentState);
        var summary = GenerateProgressSummary(currentState);
        
        return new CfopProgress(currentState, stepProgress, completionPercentage, nextStep, summary);
    }

    private bool IsSolved(Cube cube)
    {
        // Check if all faces have uniform colors
        foreach (var face in Enum.GetValues<CubeFace>())
        {
            var faceColors = cube.GetFaceFromCurrentOrientation(face);
            var centerColor = faceColors[4]; // Center piece at position 4
            
            for (int i = 0; i < 9; i++)
            {
                if (faceColors[i] != centerColor)
                    return false;
            }
        }
        return true;
    }

    private bool IsPllComplete(Cube cube)
    {
        // Last layer oriented (all top face same color) and correctly positioned
        if (!IsOllComplete(cube))
            return false;
            
        // Simplified check: verify all faces have uniform colors
        return IsSolved(cube);
    }

    private bool IsOllComplete(Cube cube)
    {
        // All top face pieces should have the same color as the top center
        var topFace = cube.GetFaceFromCurrentOrientation(CubeFace.Up);
        var topCenter = topFace[4]; // Center position
        
        // Check all positions on top face
        for (int i = 0; i < 9; i++)
        {
            if (topFace[i] != topCenter)
                return false;
        }
        return true;
    }

    private bool IsF2lComplete(Cube cube)
    {
        // Simplified: check if cross is complete and first two layers look reasonable
        if (!IsCrossComplete(cube))
            return false;
            
        // Basic check: corners and edges in bottom two layers should match centers
        return AreFirstTwoLayersComplete(cube);
    }

    private bool IsCrossComplete(Cube cube)
    {
        // Check if bottom cross is formed properly
        var bottomFace = cube.GetFaceFromCurrentOrientation(CubeFace.Down);
        var bottomCenter = bottomFace[4]; // Center position
        
        // Check bottom cross edges (positions 1, 3, 5, 7 in 0-8 layout)
        var crossPositions = new[] { 1, 3, 5, 7 };
        
        // First check: bottom cross edges must match bottom center
        foreach (var position in crossPositions)
        {
            if (bottomFace[position] != bottomCenter)
                return false;
        }
        
        // Second check: each cross edge must align with its side face center
        var sideFaces = new[] { CubeFace.Front, CubeFace.Right, CubeFace.Back, CubeFace.Left };
        var bottomEdgePositions = new[] { 7, 5, 1, 3 }; // Bottom edges on Front, Right, Back, Left faces
        
        for (int i = 0; i < sideFaces.Length; i++)
        {
            var sideFace = cube.GetFaceFromCurrentOrientation(sideFaces[i]);
            var sideCenter = sideFace[4];
            var bottomEdgeOnSide = sideFace[bottomEdgePositions[i]];
            
            // The side color of the cross edge must match the side face center
            if (bottomEdgeOnSide != sideCenter)
                return false;
        }
        
        return true;
    }

    private bool AreFirstTwoLayersComplete(Cube cube)
    {
        // Simplified check: bottom face complete and middle layer edges correct
        var bottomFace = cube.GetFaceFromCurrentOrientation(CubeFace.Down);
        var bottomCenter = bottomFace[4];
        
        // Check entire bottom face
        for (int i = 0; i < 9; i++)
        {
            if (bottomFace[i] != bottomCenter)
                return false;
        }
        
        // Check middle layer edges on side faces
        var sideFaces = new[] { CubeFace.Front, CubeFace.Right, CubeFace.Back, CubeFace.Left };
        foreach (var face in sideFaces)
        {
            var faceColors = cube.GetFaceFromCurrentOrientation(face);
            var centerColor = faceColors[4];
            
            // Check middle edge positions (3 and 5)
            if (faceColors[3] != centerColor || faceColors[5] != centerColor)
                return false;
        }
        
        return true;
    }

    private StepAnalysisResult AnalyzeCrossStep(Cube cube)
    {
        if (IsCrossComplete(cube))
            return StepAnalysisResult.Completed(CfopStep.Cross);
            
        var edgesCorrect = CountCorrectCrossEdges(cube);
        var progress = $"{edgesCorrect}/4";
        var description = edgesCorrect switch
        {
            0 => "No cross edges in place",
            1 => "One cross edge complete",
            2 => "Two cross edges complete", 
            3 => "Three cross edges complete",
            _ => "Cross analysis error"
        };
        
        return edgesCorrect > 0 
            ? StepAnalysisResult.InProgress(CfopStep.Cross, progress, description)
            : StepAnalysisResult.NotStarted(CfopStep.Cross, "Cross not started");
    }

    private StepAnalysisResult AnalyzeF2lStep(Cube cube)
    {
        if (!IsCrossComplete(cube))
            return StepAnalysisResult.NotStarted(CfopStep.F2L, "Cross must be completed first");
            
        if (IsF2lComplete(cube))
            return StepAnalysisResult.Completed(CfopStep.F2L);
            
        return StepAnalysisResult.InProgress(CfopStep.F2L, "In progress", "Working on F2L pairs");
    }

    private StepAnalysisResult AnalyzeOllStep(Cube cube)
    {
        if (!IsF2lComplete(cube))
            return StepAnalysisResult.NotStarted(CfopStep.OLL, "F2L must be completed first");
            
        if (IsOllComplete(cube))
            return StepAnalysisResult.Completed(CfopStep.OLL);
            
        var orientedPieces = CountOrientedLastLayerPieces(cube);
        var description = AnalyzeOllPattern(cube);
        
        return StepAnalysisResult.InProgress(CfopStep.OLL, $"{orientedPieces}/9", description);
    }

    private StepAnalysisResult AnalyzePllStep(Cube cube)
    {
        if (!IsOllComplete(cube))
            return StepAnalysisResult.NotStarted(CfopStep.PLL, "OLL must be completed first");
            
        if (IsPllComplete(cube))
            return StepAnalysisResult.Completed(CfopStep.PLL);
            
        return StepAnalysisResult.InProgress(CfopStep.PLL, "In progress", "Working on permutation");
    }

    private int CountCorrectCrossEdges(Cube cube)
    {
        var bottomFace = cube.GetFaceFromCurrentOrientation(CubeFace.Down);
        var bottomCenter = bottomFace[4];
        var count = 0;
        
        // Check each cross edge properly (both bottom and side alignment)
        var sideFaces = new[] { CubeFace.Front, CubeFace.Right, CubeFace.Back, CubeFace.Left };
        var bottomCrossPositions = new[] { 1, 3, 5, 7 }; // Bottom cross positions
        var bottomEdgePositions = new[] { 7, 5, 1, 3 }; // Corresponding positions on side faces
        
        for (int i = 0; i < sideFaces.Length; i++)
        {
            var bottomEdgeColor = bottomFace[bottomCrossPositions[i]];
            var sideFace = cube.GetFaceFromCurrentOrientation(sideFaces[i]);
            var sideCenter = sideFace[4];
            var sideEdgeColor = sideFace[bottomEdgePositions[i]];
            
            // Cross edge is correct if both colors match their respective centers
            if (bottomEdgeColor == bottomCenter && sideEdgeColor == sideCenter)
                count++;
        }
        
        return count;
    }

    private int CountOrientedLastLayerPieces(Cube cube)
    {
        var topFace = cube.GetFaceFromCurrentOrientation(CubeFace.Up);
        var topCenter = topFace[4];
        var orientedCount = 0;
        
        // Count all top face pieces that match the center
        for (int i = 0; i < 9; i++)
        {
            if (topFace[i] == topCenter)
                orientedCount++;
        }
        
        return orientedCount;
    }

    private string AnalyzeOllPattern(Cube cube)
    {
        var orientedCount = CountOrientedLastLayerPieces(cube);
        
        return orientedCount switch
        {
            1 => "Dot case - only center oriented",
            3 => "Line or L-shape case",
            5 => "Cross case - edges oriented",
            9 => "All pieces oriented",
            _ => $"{orientedCount} pieces oriented"
        };
    }

    private (int completionPercentage, CfopStep? nextStep) CalculateProgress(CfopState currentState)
    {
        var percentage = currentState switch
        {
            CfopState.Scrambled => 0,
            CfopState.Cross => 25,
            CfopState.F2L => 50, 
            CfopState.OLL => 75,
            CfopState.PLL => 90,
            CfopState.Solved => 100,
            _ => 0
        };
        
        CfopStep? nextStep = currentState switch
        {
            CfopState.Scrambled => CfopStep.Cross,
            CfopState.Cross => CfopStep.F2L,
            CfopState.F2L => CfopStep.OLL,
            CfopState.OLL => CfopStep.PLL,
            CfopState.PLL => null,
            CfopState.Solved => null,
            _ => CfopStep.Cross
        };
        
        return (percentage, nextStep);
    }

    private string GenerateProgressSummary(CfopState currentState)
    {
        return currentState switch
        {
            CfopState.Solved => "Cube is completely solved!",
            CfopState.PLL => "Last layer oriented, working on permutation",
            CfopState.OLL => "First two layers complete, working on orientation", 
            CfopState.F2L => "Cross complete, working on F2L pairs",
            CfopState.Cross => "Cross complete, ready for F2L",
            CfopState.Scrambled => "Cube is scrambled, start with cross",
            _ => "Unknown state"
        };
    }
}