using CSharpFunctionalExtensions;
using RubiksCube.Core.Models;

namespace RubiksCube.Core.PatternRecognition;

/// <summary>
/// Solves the cross step in CFOP method using different solving approaches
/// </summary>
public class CrossSolver : ICrossSolver
{
    private readonly CrossAnalyzer _analyzer;
    private readonly IntuitiveCrossSolver _intuitiveSolver;
    private readonly EfficientCrossSolver _efficientSolver;
    private readonly OptimalCrossSolver _optimalSolver;

    public CrossSolver()
    {
        _analyzer = new CrossAnalyzer();
        _intuitiveSolver = new IntuitiveCrossSolver(_analyzer);
        _efficientSolver = new EfficientCrossSolver(_analyzer);
        _optimalSolver = new OptimalCrossSolver(_analyzer);
    }

    public CrossSolver(CrossAnalyzer analyzer)
    {
        _analyzer = analyzer ?? throw new ArgumentNullException(nameof(analyzer));
        _intuitiveSolver = new IntuitiveCrossSolver(_analyzer);
        _efficientSolver = new EfficientCrossSolver(_analyzer);
        _optimalSolver = new OptimalCrossSolver(_analyzer);
    }

    public Result<Algorithm> Solve(Cube cube, SolvingLevel level = SolvingLevel.Efficient)
    {
        if (cube == null)
            throw new ArgumentNullException(nameof(cube));

        try
        {
            // Check if cross is already solved
            var analysis = _analyzer.AnalyzeCross(cube);
            if (analysis.IsComplete)
                return Result.Success(Algorithm.Empty);

            return level switch
            {
                SolvingLevel.Beginner => _intuitiveSolver.Solve(cube),
                SolvingLevel.Efficient => _efficientSolver.Solve(cube),
                SolvingLevel.Optimal => _optimalSolver.Solve(cube),
                _ => Result.Failure<Algorithm>($"Unknown solving level: {level}")
            };
        }
        catch (Exception ex)
        {
            return Result.Failure<Algorithm>($"Error solving cross: {ex.Message}");
        }
    }
}

/// <summary>
/// Base class for cross solving implementations
/// </summary>
public abstract class CrossSolverBase
{
    protected readonly CrossAnalyzer _analyzer;

    protected CrossSolverBase(CrossAnalyzer analyzer)
    {
        _analyzer = analyzer ?? throw new ArgumentNullException(nameof(analyzer));
    }

    public abstract Result<Algorithm> Solve(Cube cube);

    /// <summary>
    /// Validates that the provided solution actually solves the cross
    /// </summary>
    protected Result ValidateSolution(Cube originalCube, Algorithm solution)
    {
        try
        {
            // Clone cube and apply solution
            var testCube = originalCube.Clone();
            foreach (var move in solution.Moves)
            {
                var result = testCube.ApplyMove(move);
                if (result.IsFailure)
                    return Result.Failure($"Failed to apply move {move}: {result.Error}");
            }

            // Check if cross is solved
            var analysis = _analyzer.AnalyzeCross(testCube);
            if (!analysis.IsComplete)
                return Result.Failure("Solution does not solve the cross");

            return Result.Success();
        }
        catch (Exception ex)
        {
            return Result.Failure($"Error validating solution: {ex.Message}");
        }
    }

    /// <summary>
    /// Finds a specific cross edge piece on the cube
    /// </summary>
    protected (CubeFace face, int position) FindCrossEdge(Cube cube, CubeColor bottomColor, CubeColor sideColor)
    {
        // Check all edge positions on all faces
        var faces = Enum.GetValues<CubeFace>();
        var edgePositions = new[] { 1, 3, 5, 7 }; // Edge positions in 0-8 layout

        foreach (var face in faces)
        {
            var faceColors = cube.GetFaceFromCurrentOrientation(face);
            
            foreach (var position in edgePositions)
            {
                var primaryColor = faceColors[position];
                
                // Get adjacent face and position for this edge
                var (adjFace, adjPosition) = GetAdjacentFaceInfo(face, position);
                var adjColors = cube.GetFaceFromCurrentOrientation(adjFace);
                var secondaryColor = adjColors[adjPosition];

                // Check if this edge matches our target colors (in either orientation)
                if ((primaryColor == bottomColor && secondaryColor == sideColor) ||
                    (primaryColor == sideColor && secondaryColor == bottomColor))
                {
                    return (face, position);
                }
            }
        }

        throw new InvalidOperationException($"Could not find cross edge with colors {bottomColor}/{sideColor}");
    }

    /// <summary>
    /// Gets the adjacent face and position for an edge
    /// </summary>
    private (CubeFace face, int position) GetAdjacentFaceInfo(CubeFace face, int edgePosition)
    {
        // Complete mapping of all edge positions to their adjacent faces
        return face switch
        {
            // Down face edges
            CubeFace.Down when edgePosition == 1 => (CubeFace.Front, 7),
            CubeFace.Down when edgePosition == 3 => (CubeFace.Right, 5),
            CubeFace.Down when edgePosition == 5 => (CubeFace.Back, 1),
            CubeFace.Down when edgePosition == 7 => (CubeFace.Left, 3),
            
            // Up face edges
            CubeFace.Up when edgePosition == 1 => (CubeFace.Back, 5),
            CubeFace.Up when edgePosition == 3 => (CubeFace.Right, 1),
            CubeFace.Up when edgePosition == 5 => (CubeFace.Front, 1),
            CubeFace.Up when edgePosition == 7 => (CubeFace.Left, 1),
            
            // Front face edges
            CubeFace.Front when edgePosition == 1 => (CubeFace.Up, 5),
            CubeFace.Front when edgePosition == 3 => (CubeFace.Right, 7),
            CubeFace.Front when edgePosition == 5 => (CubeFace.Down, 1),
            CubeFace.Front when edgePosition == 7 => (CubeFace.Left, 5),
            
            // Back face edges  
            CubeFace.Back when edgePosition == 1 => (CubeFace.Down, 5),
            CubeFace.Back when edgePosition == 3 => (CubeFace.Left, 7),
            CubeFace.Back when edgePosition == 5 => (CubeFace.Up, 1),
            CubeFace.Back when edgePosition == 7 => (CubeFace.Right, 3),
            
            // Right face edges
            CubeFace.Right when edgePosition == 1 => (CubeFace.Up, 3),
            CubeFace.Right when edgePosition == 3 => (CubeFace.Back, 7),
            CubeFace.Right when edgePosition == 5 => (CubeFace.Down, 3),
            CubeFace.Right when edgePosition == 7 => (CubeFace.Front, 3),
            
            // Left face edges
            CubeFace.Left when edgePosition == 1 => (CubeFace.Up, 7),
            CubeFace.Left when edgePosition == 3 => (CubeFace.Front, 7),
            CubeFace.Left when edgePosition == 5 => (CubeFace.Down, 7),
            CubeFace.Left when edgePosition == 7 => (CubeFace.Back, 3),
            
            _ => throw new ArgumentException($"No adjacent mapping for {face} position {edgePosition}")
        };
    }

    /// <summary>
    /// Gets the target colors for cross edges based on cube's current orientation
    /// </summary>
    protected Dictionary<CubeFace, (CubeColor bottomColor, CubeColor sideColor)> GetCrossTargetColors(Cube cube)
    {
        var bottomFace = cube.GetFaceFromCurrentOrientation(CubeFace.Down);
        var bottomColor = bottomFace[4]; // Center color

        var sideFaces = new[] { CubeFace.Front, CubeFace.Right, CubeFace.Back, CubeFace.Left };
        var result = new Dictionary<CubeFace, (CubeColor, CubeColor)>();

        foreach (var sideFace in sideFaces)
        {
            var sideColors = cube.GetFaceFromCurrentOrientation(sideFace);
            var sideColor = sideColors[4]; // Center color
            result[sideFace] = (bottomColor, sideColor);
        }

        return result;
    }
}