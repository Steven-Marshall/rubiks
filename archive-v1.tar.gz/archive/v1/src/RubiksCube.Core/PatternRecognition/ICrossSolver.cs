using CSharpFunctionalExtensions;
using RubiksCube.Core.Models;

namespace RubiksCube.Core.PatternRecognition;

/// <summary>
/// Interface for solving the cross step in CFOP method
/// </summary>
public interface ICrossSolver
{
    /// <summary>
    /// Solves the cross on the bottom face of the cube
    /// </summary>
    /// <param name="cube">The cube to solve the cross for</param>
    /// <param name="level">The solving approach to use</param>
    /// <returns>An algorithm that solves the cross, or an error if solving fails</returns>
    Result<Algorithm> Solve(Cube cube, SolvingLevel level = SolvingLevel.Efficient);
}