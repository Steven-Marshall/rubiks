using RubiksCube.Core.Models;
using CSharpFunctionalExtensions;

namespace RubiksCube.Core.PatternRecognition;

/// <summary>
/// Interface for analyzing the current state of a cube in the CFOP solving method
/// </summary>
public interface ICubeStateAnalyzer
{
    /// <summary>
    /// Analyzes the current CFOP state of the cube
    /// </summary>
    /// <param name="cube">The cube to analyze</param>
    /// <returns>The current CFOP state</returns>
    CfopState AnalyzeState(Cube cube);
    
    /// <summary>
    /// Analyzes a specific step of the CFOP method
    /// </summary>
    /// <param name="cube">The cube to analyze</param>
    /// <param name="step">The specific CFOP step to analyze</param>
    /// <returns>Detailed analysis result for the step</returns>
    Result<StepAnalysisResult> AnalyzeStep(Cube cube, CfopStep step);
    
    /// <summary>
    /// Gets the overall progress through the CFOP method
    /// </summary>
    /// <param name="cube">The cube to analyze</param>
    /// <returns>Progress information</returns>
    CfopProgress GetProgress(Cube cube);
}