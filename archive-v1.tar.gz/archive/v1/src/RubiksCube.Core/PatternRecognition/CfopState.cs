namespace RubiksCube.Core.PatternRecognition;

/// <summary>
/// Represents the current state in the CFOP solving method
/// </summary>
public enum CfopState
{
    /// <summary>
    /// Cube is in a scrambled state, no CFOP progress detected
    /// </summary>
    Scrambled,
    
    /// <summary>
    /// Cross is in progress or complete
    /// </summary>
    Cross,
    
    /// <summary>
    /// First Two Layers (F2L) in progress or complete
    /// </summary>
    F2L,
    
    /// <summary>
    /// Orient Last Layer (OLL) in progress or complete
    /// </summary>
    OLL,
    
    /// <summary>
    /// Permute Last Layer (PLL) in progress or complete
    /// </summary>
    PLL,
    
    /// <summary>
    /// Cube is completely solved
    /// </summary>
    Solved
}

/// <summary>
/// Specific steps in the CFOP method for focused analysis
/// </summary>
public enum CfopStep
{
    Cross,
    F2L,
    OLL,
    PLL
}