using CSharpFunctionalExtensions;
using RubiksCube.Core.Models;

namespace RubiksCube.Core.PatternRecognition;

/// <summary>
/// Intuitive cross solver that mimics human solving approach.
/// Uses clear, understandable patterns that beginners can follow.
/// </summary>
public class IntuitiveCrossSolver : CrossSolverBase
{
    public IntuitiveCrossSolver(CrossAnalyzer analyzer) : base(analyzer)
    {
    }

    public override Result<Algorithm> Solve(Cube cube)
    {
        try
        {
            // For testing, let's just solve the front edge
            var frontEdgeMoves = SolveSingleWhiteEdge(cube, CubeFace.Front);
            if (frontEdgeMoves.IsFailure)
                return Result.Failure<Algorithm>($"Failed to solve front white edge: {frontEdgeMoves.Error}");
            
            return Result.Success(new Algorithm(frontEdgeMoves.Value));
        }
        catch (Exception ex)
        {
            return Result.Failure<Algorithm>($"Error in intuitive cross solving: {ex.Message}");
        }
    }
    
    /// <summary>
    /// Solves one white edge for a specific face (e.g., white-green edge for front face)
    /// </summary>
    private Result<List<Move>> SolveSingleWhiteEdge(Cube cube, CubeFace targetFace)
    {
        var moves = new List<Move>();
        var targetColor = GetCenterColor(cube, targetFace);
        
        // Find where the white-targetColor edge is located
        var edgeLocation = FindWhiteEdgeLocation(cube, targetColor);
        if (edgeLocation == null)
            return Result.Failure<List<Move>>($"Could not find white-{targetColor} edge");
        
        // Case 1: Already in correct position
        if (edgeLocation.Face == CubeFace.Down && edgeLocation.Position == GetBottomEdgePositionForFace(targetFace))
        {
            if (edgeLocation.WhiteOnBottom)
                return Result.Success(moves); // Already solved
            else
                return SolveCase5_FlippedOnBottom(cube, targetFace); // Case 5: flipped
        }
        
        // Case 2: On target face but not bottom row
        if (edgeLocation.Face == targetFace && edgeLocation.Position != 7)
        {
            return SolveCase2_OnFaceNotBottom(cube, targetFace, edgeLocation.Position);
        }
        
        // Case 3: On top face
        if (edgeLocation.Face == CubeFace.Up)
        {
            return SolveCase3_OnTop(cube, targetFace, edgeLocation);
        }
        
        // Case 4: On wrong edge (middle layer or wrong bottom position)
        return SolveCase4_OnWrongEdge(cube, targetFace, edgeLocation);
    }
    
    private EdgeLocation? FindWhiteEdgeLocation(Cube cube, CubeColor targetColor)
    {
        // Check all edge positions to find the white-targetColor edge
        var edgePositions = new[]
        {
            // Down face edges
            new { Face = CubeFace.Down, Position = 1, Adjacent = CubeFace.Front },
            new { Face = CubeFace.Down, Position = 3, Adjacent = CubeFace.Right },
            new { Face = CubeFace.Down, Position = 5, Adjacent = CubeFace.Back },
            new { Face = CubeFace.Down, Position = 7, Adjacent = CubeFace.Left },
            
            // Up face edges
            new { Face = CubeFace.Up, Position = 1, Adjacent = CubeFace.Back },
            new { Face = CubeFace.Up, Position = 3, Adjacent = CubeFace.Left },
            new { Face = CubeFace.Up, Position = 5, Adjacent = CubeFace.Right },
            new { Face = CubeFace.Up, Position = 7, Adjacent = CubeFace.Front },
            
            // Middle layer edges
            new { Face = CubeFace.Front, Position = 3, Adjacent = CubeFace.Left },
            new { Face = CubeFace.Front, Position = 5, Adjacent = CubeFace.Right },
            new { Face = CubeFace.Right, Position = 3, Adjacent = CubeFace.Front },
            new { Face = CubeFace.Right, Position = 5, Adjacent = CubeFace.Back },
            new { Face = CubeFace.Back, Position = 3, Adjacent = CubeFace.Right },
            new { Face = CubeFace.Back, Position = 5, Adjacent = CubeFace.Left },
            new { Face = CubeFace.Left, Position = 3, Adjacent = CubeFace.Back },
            new { Face = CubeFace.Left, Position = 5, Adjacent = CubeFace.Front }
        };
        
        foreach (var pos in edgePositions)
        {
            var faceColors = cube.GetFaceFromCurrentOrientation(pos.Face);
            var adjacentColors = cube.GetFaceFromCurrentOrientation(pos.Adjacent);
            
            var primaryColor = faceColors[pos.Position];
            var secondaryColor = GetAdjacentColor(cube, pos.Face, pos.Position);
            
            // Check if this edge contains white and targetColor
            if ((primaryColor == CubeColor.White && secondaryColor == targetColor) ||
                (primaryColor == targetColor && secondaryColor == CubeColor.White))
            {
                return new EdgeLocation
                {
                    Face = pos.Face,
                    Position = pos.Position,
                    WhiteOnBottom = (pos.Face == CubeFace.Down && primaryColor == CubeColor.White) ||
                                   (pos.Face != CubeFace.Down && primaryColor == CubeColor.White)
                };
            }
        }
        
        return null;
    }
    
    private Result<List<Move>> SolveCase2_OnFaceNotBottom(Cube cube, CubeFace targetFace, int position)
    {
        var moves = new List<Move>();
        
        // Simple: rotate the face to bring edge to bottom
        if (position == 1) // Top edge of face
        {
            moves.Add(new Move(targetFace, MoveType.Double)); // F2 brings top edge to bottom
        }
        else if (position == 3) // Left edge of face  
        {
            moves.Add(new Move(targetFace, MoveType.CounterClockwise)); // F' brings left edge to bottom
        }
        else if (position == 5) // Right edge of face
        {
            moves.Add(new Move(targetFace, MoveType.Clockwise)); // F brings right edge to bottom
        }
        
        return Result.Success(moves);
    }
    
    private Result<List<Move>> SolveCase3_OnTop(Cube cube, CubeFace targetFace, EdgeLocation edgeLocation)
    {
        var moves = new List<Move>();
        
        // First, align the edge with the target face using U moves
        var currentTopPosition = edgeLocation.Position;
        var targetTopPosition = GetTopEdgePositionForFace(targetFace);
        
        var uMoves = CalculateUMovesToAlign(currentTopPosition, targetTopPosition);
        moves.AddRange(uMoves);
        
        // Then bring it down with F2
        moves.Add(new Move(targetFace, MoveType.Double));
        
        return Result.Success(moves);
    }
    
    private Result<List<Move>> SolveCase4_OnWrongEdge(Cube cube, CubeFace targetFace, EdgeLocation edgeLocation)
    {
        var moves = new List<Move>();
        
        // Move edge to top layer first
        if (edgeLocation.Face == CubeFace.Down)
        {
            // Wrong position on bottom - use F2 to bring to top
            var wrongFace = GetFaceForBottomPosition(edgeLocation.Position);
            moves.Add(new Move(wrongFace, MoveType.Double));
        }
        else
        {
            // Middle layer - extract to top (simple approach: use the face it's on)
            moves.Add(new Move(edgeLocation.Face, MoveType.Clockwise));
            moves.Add(new Move(CubeFace.Up, MoveType.Clockwise));
            moves.Add(new Move(edgeLocation.Face, MoveType.CounterClockwise));
        }
        
        // Now solve from top position (this is recursive but simple)
        // We know the edge is now in the top layer, so find it again and solve
        var newEdgeLocation = FindWhiteEdgeLocation(cube, GetCenterColor(cube, targetFace));
        if (newEdgeLocation?.Face == CubeFace.Up)
        {
            var topSolution = SolveCase3_OnTop(cube, targetFace, newEdgeLocation);
            if (topSolution.IsSuccess)
                moves.AddRange(topSolution.Value);
        }
        
        return Result.Success(moves);
    }
    
    private Result<List<Move>> SolveCase5_FlippedOnBottom(Cube cube, CubeFace targetFace)
    {
        var moves = new List<Move>();
        
        // Bring flipped edge to top
        moves.Add(new Move(targetFace, MoveType.Double));
        
        // Now it's in top layer with correct orientation, bring it back down
        moves.Add(new Move(targetFace, MoveType.Double));
        
        return Result.Success(moves);
    }
    
    // Helper methods
    private CubeColor GetCenterColor(Cube cube, CubeFace face)
    {
        var faceColors = cube.GetFaceFromCurrentOrientation(face);
        return faceColors[4]; // Center is always position 4
    }
    
    private CubeColor GetAdjacentColor(Cube cube, CubeFace face, int position)
    {
        var adjacentInfo = GetAdjacentFaceInfo(face, position);
        var adjacentColors = cube.GetFaceFromCurrentOrientation(adjacentInfo.face);
        return adjacentColors[adjacentInfo.position];
    }
    
    private (CubeFace face, int position) GetAdjacentFaceInfo(CubeFace face, int edgePosition)
    {
        return face switch
        {
            CubeFace.Up => edgePosition switch
            {
                1 => (CubeFace.Back, 7),
                3 => (CubeFace.Left, 1), 
                5 => (CubeFace.Right, 1),
                7 => (CubeFace.Front, 1),
                _ => throw new ArgumentException($"Invalid edge position {edgePosition}")
            },
            CubeFace.Down => edgePosition switch
            {
                1 => (CubeFace.Front, 7),
                3 => (CubeFace.Right, 7),
                5 => (CubeFace.Back, 1), 
                7 => (CubeFace.Left, 7),
                _ => throw new ArgumentException($"Invalid edge position {edgePosition}")
            },
            CubeFace.Front => edgePosition switch
            {
                3 => (CubeFace.Left, 5),
                5 => (CubeFace.Right, 3),
                _ => throw new ArgumentException($"Invalid edge position {edgePosition}")
            },
            CubeFace.Right => edgePosition switch
            {
                3 => (CubeFace.Front, 5),
                5 => (CubeFace.Back, 3),
                _ => throw new ArgumentException($"Invalid edge position {edgePosition}")
            },
            CubeFace.Back => edgePosition switch
            {
                3 => (CubeFace.Right, 5),
                5 => (CubeFace.Left, 3),
                _ => throw new ArgumentException($"Invalid edge position {edgePosition}")
            },
            CubeFace.Left => edgePosition switch
            {
                3 => (CubeFace.Back, 5),
                5 => (CubeFace.Front, 3),
                _ => throw new ArgumentException($"Invalid edge position {edgePosition}")
            },
            _ => throw new ArgumentException($"Unsupported face {face}")
        };
    }
    
    private int GetBottomEdgePositionForFace(CubeFace face)
    {
        return face switch
        {
            CubeFace.Front => 1,
            CubeFace.Right => 3,
            CubeFace.Back => 5,
            CubeFace.Left => 7,
            _ => throw new ArgumentException($"Invalid face {face}")
        };
    }
    
    private int GetTopEdgePositionForFace(CubeFace face)
    {
        return face switch
        {
            CubeFace.Front => 7,
            CubeFace.Right => 5,
            CubeFace.Back => 1,
            CubeFace.Left => 3,
            _ => throw new ArgumentException($"Invalid face {face}")
        };
    }
    
    private CubeFace GetFaceForBottomPosition(int position)
    {
        return position switch
        {
            1 => CubeFace.Front,
            3 => CubeFace.Right,
            5 => CubeFace.Back,
            7 => CubeFace.Left,
            _ => throw new ArgumentException($"Invalid bottom position {position}")
        };
    }
    
    private List<Move> CalculateUMovesToAlign(int currentPos, int targetPos)
    {
        var moves = new List<Move>();
        var diff = (targetPos - currentPos + 8) % 8; // Handle wraparound
        
        if (diff == 2) moves.Add(new Move(CubeFace.Up, MoveType.Clockwise));
        else if (diff == 4) moves.Add(new Move(CubeFace.Up, MoveType.Double));
        else if (diff == 6) moves.Add(new Move(CubeFace.Up, MoveType.CounterClockwise));
        
        return moves;
    }
    
    private class EdgeLocation
    {
        public CubeFace Face { get; set; }
        public int Position { get; set; }
        public bool WhiteOnBottom { get; set; }
    }
    
    private Result<Algorithm> FindSolutionWithBruteForce(Cube cube, Move[] moves, int maxDepth)
    {
        for (int depth = 1; depth <= maxDepth; depth++)
        {
            var result = SearchAtDepth(cube, moves, depth, new List<Move>());
            if (result.IsSuccess)
                return result;
        }
        
        return Result.Failure<Algorithm>("No solution found within move limit");
    }
    
    private Result<Algorithm> SearchAtDepth(Cube cube, Move[] availableMoves, int depth, List<Move> currentMoves)
    {
        if (depth == 0)
        {
            // Check if cross is solved
            var analysis = _analyzer.AnalyzeCross(cube);
            if (analysis.IsComplete)
                return Result.Success(new Algorithm(currentMoves));
            else
                return Result.Failure<Algorithm>("Not solved at this depth");
        }
        
        foreach (var move in availableMoves)
        {
            // Avoid redundant moves (e.g., don't do R followed by R')
            if (currentMoves.Count > 0 && AreRedundantMoves(currentMoves.Last(), move))
                continue;
                
            var testCube = cube.Clone();
            testCube.ApplyMove(move);
            
            var newMoves = new List<Move>(currentMoves) { move };
            var result = SearchAtDepth(testCube, availableMoves, depth - 1, newMoves);
            
            if (result.IsSuccess)
                return result;
        }
        
        return Result.Failure<Algorithm>("No solution at this depth");
    }
    
    private bool AreRedundantMoves(Move lastMove, Move newMove)
    {
        // Don't do opposite moves (R then R')
        if (lastMove.Face == newMove.Face)
        {
            if ((lastMove.Type == MoveType.Clockwise && newMove.Type == MoveType.CounterClockwise) ||
                (lastMove.Type == MoveType.CounterClockwise && newMove.Type == MoveType.Clockwise))
                return true;
        }
        
        return false;
    }
}
