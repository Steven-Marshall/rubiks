using RubiksCube.Core.Models;
using CSharpFunctionalExtensions;

namespace RubiksCube.Core.PatternRecognition;

/// <summary>
/// Generic interface for pattern recognition systems
/// </summary>
/// <typeparam name="TPattern">The type of pattern to recognize</typeparam>
public interface IPatternRecognizer<TPattern>
{
    /// <summary>
    /// Recognizes patterns in the given cube state
    /// </summary>
    /// <param name="cube">The cube to analyze</param>
    /// <returns>Collection of recognized patterns with confidence scores</returns>
    IEnumerable<PatternMatch<TPattern>> RecognizePatterns(Cube cube);
    
    /// <summary>
    /// Finds the best matching pattern for the cube state
    /// </summary>
    /// <param name="cube">The cube to analyze</param>
    /// <returns>The best pattern match, or failure if no patterns match</returns>
    Result<PatternMatch<TPattern>> FindBestMatch(Cube cube);
    
    /// <summary>
    /// Checks if a specific pattern matches the cube state
    /// </summary>
    /// <param name="cube">The cube to check</param>
    /// <param name="pattern">The pattern to match against</param>
    /// <returns>True if the pattern matches</returns>
    bool MatchesPattern(Cube cube, TPattern pattern);
}