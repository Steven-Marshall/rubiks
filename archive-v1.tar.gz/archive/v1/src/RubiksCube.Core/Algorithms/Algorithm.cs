using System.Text.Json.Serialization;

namespace RubiksCube.Core.Algorithms;

/// <summary>
/// Represents a single algorithm with metadata
/// </summary>
public class Algorithm
{
    /// <summary>
    /// Unique identifier for this algorithm
    /// </summary>
    [JsonPropertyName("id")]
    public string Id { get; set; } = string.Empty;
    
    /// <summary>
    /// Human-readable name for this algorithm
    /// </summary>
    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;
    
    /// <summary>
    /// Algorithm category (OLL, PLL, F2L, etc.)
    /// </summary>
    [JsonPropertyName("category")]
    public string Category { get; set; } = string.Empty;
    
    /// <summary>
    /// Algorithm subcategory (4LLL, Full CFOP, etc.)
    /// </summary>
    [JsonPropertyName("subcategory")]
    public string Subcategory { get; set; } = string.Empty;
    
    /// <summary>
    /// The algorithm sequence in standard notation
    /// </summary>
    [JsonPropertyName("algorithm")]
    public string AlgorithmSequence { get; set; } = string.Empty;
    
    /// <summary>
    /// Setup algorithm to reach this case (for testing)
    /// </summary>
    [JsonPropertyName("setup")]
    public string Setup { get; set; } = string.Empty;
    
    /// <summary>
    /// Recognition information for this algorithm
    /// </summary>
    [JsonPropertyName("recognition")]
    public AlgorithmRecognition Recognition { get; set; } = new();
    
    /// <summary>
    /// Algorithm metadata (difficulty, move count, etc.)
    /// </summary>
    [JsonPropertyName("metadata")]
    public AlgorithmMetadata Metadata { get; set; } = new();
    
    /// <summary>
    /// Alternative algorithms for the same case
    /// </summary>
    [JsonPropertyName("alternatives")]
    public List<AlgorithmAlternative> Alternatives { get; set; } = new();
    
    /// <summary>
    /// Source information
    /// </summary>
    [JsonPropertyName("source")]
    public AlgorithmSource Source { get; set; } = new();
    
    public override string ToString()
        => $"{Name}: {AlgorithmSequence}";
}

/// <summary>
/// Recognition information for an algorithm
/// </summary>
public class AlgorithmRecognition
{
    /// <summary>
    /// Human-readable description of when to use this algorithm
    /// </summary>
    [JsonPropertyName("description")]
    public string Description { get; set; } = string.Empty;
    
    /// <summary>
    /// Pattern string for algorithmic recognition
    /// </summary>
    [JsonPropertyName("pattern")]
    public string Pattern { get; set; } = string.Empty;
    
    /// <summary>
    /// Visual description for human recognition
    /// </summary>
    [JsonPropertyName("visual")]
    public string Visual { get; set; } = string.Empty;
    
    /// <summary>
    /// Additional recognition hints
    /// </summary>
    [JsonPropertyName("hints")]
    public List<string> Hints { get; set; } = new();
}

/// <summary>
/// Algorithm metadata
/// </summary>
public class AlgorithmMetadata
{
    /// <summary>
    /// Number of moves in the algorithm
    /// </summary>
    [JsonPropertyName("moveCount")]
    public int MoveCount { get; set; }
    
    /// <summary>
    /// Probability of encountering this case
    /// </summary>
    [JsonPropertyName("probability")]
    public double Probability { get; set; }
    
    /// <summary>
    /// Difficulty level (easy, medium, hard)
    /// </summary>
    [JsonPropertyName("difficulty")]
    public string Difficulty { get; set; } = "medium";
    
    /// <summary>
    /// Finger trick hints
    /// </summary>
    [JsonPropertyName("fingerTricks")]
    public string FingerTricks { get; set; } = string.Empty;
    
    /// <summary>
    /// Learning tips
    /// </summary>
    [JsonPropertyName("tips")]
    public string Tips { get; set; } = string.Empty;
    
    /// <summary>
    /// Additional metadata
    /// </summary>
    [JsonPropertyName("additionalData")]
    public Dictionary<string, object> AdditionalData { get; set; } = new();
}

/// <summary>
/// Alternative algorithm for the same case
/// </summary>
public class AlgorithmAlternative
{
    /// <summary>
    /// The alternative algorithm sequence
    /// </summary>
    [JsonPropertyName("algorithm")]
    public string AlgorithmSequence { get; set; } = string.Empty;
    
    /// <summary>
    /// Description of this alternative
    /// </summary>
    [JsonPropertyName("description")]
    public string Description { get; set; } = string.Empty;
    
    /// <summary>
    /// Difficulty of this alternative
    /// </summary>
    [JsonPropertyName("difficulty")]
    public string Difficulty { get; set; } = "medium";
    
    /// <summary>
    /// Move count for this alternative
    /// </summary>
    [JsonPropertyName("moveCount")]
    public int MoveCount { get; set; }
}

/// <summary>
/// Source information for an algorithm
/// </summary>
public class AlgorithmSource
{
    /// <summary>
    /// Author or creator of this algorithm
    /// </summary>
    [JsonPropertyName("author")]
    public string Author { get; set; } = string.Empty;
    
    /// <summary>
    /// Source URL
    /// </summary>
    [JsonPropertyName("url")]
    public string Url { get; set; } = string.Empty;
    
    /// <summary>
    /// Whether this algorithm has been verified
    /// </summary>
    [JsonPropertyName("verified")]
    public bool Verified { get; set; }
    
    /// <summary>
    /// Additional source notes
    /// </summary>
    [JsonPropertyName("notes")]
    public string Notes { get; set; } = string.Empty;
}