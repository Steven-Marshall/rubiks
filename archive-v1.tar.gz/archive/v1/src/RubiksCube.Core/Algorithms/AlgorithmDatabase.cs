using System.Text.Json;
using CSharpFunctionalExtensions;

namespace RubiksCube.Core.Algorithms;

/// <summary>
/// Implementation of algorithm database with file-based storage
/// </summary>
public class AlgorithmDatabase : IAlgorithmDatabase
{
    private readonly Dictionary<string, AlgorithmSet> _algorithmSets = new();
    private AlgorithmConfig _config = new();
    private string _configPath = string.Empty;
    
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        WriteIndented = true
    };
    
    public async Task<Result> LoadFromConfig(string configPath)
    {
        try
        {
            _configPath = configPath;
            
            if (!File.Exists(configPath))
            {
                return Result.Failure($"Configuration file not found: {configPath}");
            }
            
            var configJson = await File.ReadAllTextAsync(configPath);
            _config = JsonSerializer.Deserialize<AlgorithmConfig>(configJson, JsonOptions) 
                     ?? new AlgorithmConfig();
            
            // Clear existing algorithm sets
            _algorithmSets.Clear();
            
            // Load algorithm sets from configuration
            foreach (var (setId, setConfig) in _config.AlgorithmSets.Where(kvp => kvp.Value.Enabled))
            {
                var algorithmSet = new AlgorithmSet
                {
                    Id = setId,
                    Name = setConfig.Name,
                    Description = setConfig.Description,
                    Difficulty = setConfig.Difficulty,
                    Enabled = setConfig.Enabled,
                    Priority = setConfig.Priority,
                    Directories = setConfig.Directories.ToList()
                };
                
                // Load algorithms from each directory
                foreach (var directory in setConfig.Directories)
                {
                    var fullPath = Path.IsPathRooted(directory) 
                        ? directory 
                        : Path.Combine(Path.GetDirectoryName(configPath) ?? "", _config.BaseDirectory, directory);
                        
                    var loadResult = await LoadAlgorithmsFromDirectory(fullPath, algorithmSet);
                    if (loadResult.IsFailure)
                    {
                        return Result.Failure($"Failed to load algorithms from {directory}: {loadResult.Error}");
                    }
                }
                
                _algorithmSets[setId] = algorithmSet;
            }
            
            return Result.Success();
        }
        catch (Exception ex)
        {
            return Result.Failure($"Error loading algorithm configuration: {ex.Message}");
        }
    }
    
    public async Task<Result> LoadFromDirectory(string directoryPath, string algorithmSetId)
    {
        if (!_algorithmSets.TryGetValue(algorithmSetId, out var algorithmSet))
        {
            return Result.Failure($"Algorithm set '{algorithmSetId}' not found");
        }
        
        return await LoadAlgorithmsFromDirectory(directoryPath, algorithmSet);
    }
    
    private async Task<Result> LoadAlgorithmsFromDirectory(string directoryPath, AlgorithmSet algorithmSet)
    {
        try
        {
            if (!Directory.Exists(directoryPath))
            {
                return Result.Failure($"Directory not found: {directoryPath}");
            }
            
            // Recursively find all JSON files
            var jsonFiles = Directory.GetFiles(directoryPath, "*.json", SearchOption.AllDirectories);
            
            foreach (var jsonFile in jsonFiles)
            {
                try
                {
                    var algorithmJson = await File.ReadAllTextAsync(jsonFile);
                    var algorithm = JsonSerializer.Deserialize<Algorithm>(algorithmJson, JsonOptions);
                    
                    if (algorithm != null && !string.IsNullOrEmpty(algorithm.Id))
                    {
                        // Set subcategory from algorithm set if not specified
                        if (string.IsNullOrEmpty(algorithm.Subcategory))
                        {
                            algorithm.Subcategory = algorithmSet.Name;
                        }
                        
                        algorithmSet.Algorithms[algorithm.Id] = algorithm;
                    }
                }
                catch (JsonException ex)
                {
                    return Result.Failure($"Invalid JSON in file {jsonFile}: {ex.Message}");
                }
            }
            
            return Result.Success();
        }
        catch (Exception ex)
        {
            return Result.Failure($"Error loading algorithms from directory {directoryPath}: {ex.Message}");
        }
    }
    
    public IEnumerable<AlgorithmSet> GetAlgorithmSets()
        => _algorithmSets.Values.Where(s => s.Enabled).OrderBy(s => s.Priority);
    
    public AlgorithmSet? GetAlgorithmSet(string setId)
        => _algorithmSets.TryGetValue(setId, out var set) ? set : null;
    
    public IEnumerable<Algorithm> GetAlgorithms(string setId, string category, string? subcategory = null)
    {
        var algorithmSet = GetAlgorithmSet(setId);
        return algorithmSet?.GetAlgorithms(category, subcategory) ?? Enumerable.Empty<Algorithm>();
    }
    
    public IEnumerable<Algorithm> GetAlgorithmsFromAllSets(string category, string? subcategory = null)
    {
        return GetAlgorithmSets()
            .SelectMany(set => set.GetAlgorithms(category, subcategory))
            .OrderBy(a => a.Metadata.Difficulty)
            .ThenBy(a => a.Metadata.MoveCount);
    }
    
    public Algorithm? FindAlgorithmById(string algorithmId)
    {
        return GetAlgorithmSets()
            .Select(set => set.FindById(algorithmId))
            .FirstOrDefault(algorithm => algorithm != null);
    }
    
    public IEnumerable<Algorithm> SearchByPattern(string pattern)
    {
        return GetAlgorithmSets()
            .SelectMany(set => set.Algorithms.Values)
            .Where(algorithm => algorithm.Recognition.Pattern.Contains(pattern, StringComparison.OrdinalIgnoreCase));
    }
    
    public IEnumerable<Algorithm> SearchByText(string query)
    {
        var lowerQuery = query.ToLowerInvariant();
        
        return GetAlgorithmSets()
            .SelectMany(set => set.Algorithms.Values)
            .Where(algorithm => 
                algorithm.Name.Contains(lowerQuery, StringComparison.OrdinalIgnoreCase) ||
                algorithm.Recognition.Description.Contains(lowerQuery, StringComparison.OrdinalIgnoreCase) ||
                algorithm.Recognition.Visual.Contains(lowerQuery, StringComparison.OrdinalIgnoreCase) ||
                algorithm.AlgorithmSequence.Contains(lowerQuery, StringComparison.OrdinalIgnoreCase));
    }
    
    public Result SetAlgorithmSetEnabled(string setId, bool enabled)
    {
        if (!_algorithmSets.TryGetValue(setId, out var algorithmSet))
        {
            return Result.Failure($"Algorithm set '{setId}' not found");
        }
        
        algorithmSet.Enabled = enabled;
        
        // Update configuration
        if (_config.AlgorithmSets.TryGetValue(setId, out var setConfig))
        {
            setConfig.Enabled = enabled;
        }
        
        return Result.Success();
    }
    
    public AlgorithmConfig GetConfiguration()
        => _config;
    
    public async Task<Result> Reload()
    {
        if (string.IsNullOrEmpty(_configPath))
        {
            return Result.Failure("No configuration file loaded");
        }
        
        return await LoadFromConfig(_configPath);
    }
}