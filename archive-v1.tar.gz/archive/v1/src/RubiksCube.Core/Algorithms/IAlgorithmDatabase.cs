using CSharpFunctionalExtensions;

namespace RubiksCube.Core.Algorithms;

/// <summary>
/// Interface for algorithm database operations
/// </summary>
public interface IAlgorithmDatabase
{
    /// <summary>
    /// Loads algorithm configuration and algorithm sets
    /// </summary>
    /// <param name="configPath">Path to algorithm configuration file</param>
    /// <returns>Success result or failure with error message</returns>
    Task<Result> LoadFromConfig(string configPath);
    
    /// <summary>
    /// Loads algorithms from a specific directory
    /// </summary>
    /// <param name="directoryPath">Path to directory containing algorithm JSON files</param>
    /// <param name="algorithmSetId">ID of the algorithm set these belong to</param>
    /// <returns>Success result or failure with error message</returns>
    Task<Result> LoadFromDirectory(string directoryPath, string algorithmSetId);
    
    /// <summary>
    /// Gets all available algorithm sets
    /// </summary>
    /// <returns>Collection of algorithm sets</returns>
    IEnumerable<AlgorithmSet> GetAlgorithmSets();
    
    /// <summary>
    /// Gets a specific algorithm set by ID
    /// </summary>
    /// <param name="setId">Algorithm set identifier</param>
    /// <returns>Algorithm set if found, null otherwise</returns>
    AlgorithmSet? GetAlgorithmSet(string setId);
    
    /// <summary>
    /// Gets algorithms from a specific set and category
    /// </summary>
    /// <param name="setId">Algorithm set identifier</param>
    /// <param name="category">Algorithm category (OLL, PLL, F2L, etc.)</param>
    /// <param name="subcategory">Optional subcategory filter</param>
    /// <returns>Collection of matching algorithms</returns>
    IEnumerable<Algorithm> GetAlgorithms(string setId, string category, string? subcategory = null);
    
    /// <summary>
    /// Gets algorithms from all enabled sets for a category
    /// </summary>
    /// <param name="category">Algorithm category</param>
    /// <param name="subcategory">Optional subcategory filter</param>
    /// <returns>Collection of matching algorithms ordered by set priority</returns>
    IEnumerable<Algorithm> GetAlgorithmsFromAllSets(string category, string? subcategory = null);
    
    /// <summary>
    /// Finds a specific algorithm by ID across all sets
    /// </summary>
    /// <param name="algorithmId">Algorithm identifier</param>
    /// <returns>Algorithm if found, null otherwise</returns>
    Algorithm? FindAlgorithmById(string algorithmId);
    
    /// <summary>
    /// Searches for algorithms matching a pattern
    /// </summary>
    /// <param name="pattern">Pattern to match against</param>
    /// <returns>Collection of matching algorithms</returns>
    IEnumerable<Algorithm> SearchByPattern(string pattern);
    
    /// <summary>
    /// Searches for algorithms by name or description
    /// </summary>
    /// <param name="query">Search query</param>
    /// <returns>Collection of matching algorithms</returns>
    IEnumerable<Algorithm> SearchByText(string query);
    
    /// <summary>
    /// Enables or disables an algorithm set
    /// </summary>
    /// <param name="setId">Algorithm set identifier</param>
    /// <param name="enabled">Whether to enable or disable the set</param>
    /// <returns>Success result or failure with error message</returns>
    Result SetAlgorithmSetEnabled(string setId, bool enabled);
    
    /// <summary>
    /// Gets the current algorithm configuration
    /// </summary>
    /// <returns>Current algorithm configuration</returns>
    AlgorithmConfig GetConfiguration();
    
    /// <summary>
    /// Reloads the algorithm database from the current configuration
    /// </summary>
    /// <returns>Success result or failure with error message</returns>
    Task<Result> Reload();
}