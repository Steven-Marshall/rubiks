using System.Text.Json.Serialization;

namespace RubiksCube.Core.Algorithms;

/// <summary>
/// Represents a collection of algorithms (e.g., 4LLL, Full CFOP)
/// </summary>
public class AlgorithmSet
{
    /// <summary>
    /// Unique identifier for this algorithm set
    /// </summary>
    public string Id { get; set; } = string.Empty;
    
    /// <summary>
    /// Human-readable name for this algorithm set
    /// </summary>
    public string Name { get; set; } = string.Empty;
    
    /// <summary>
    /// Description of this algorithm set
    /// </summary>
    public string Description { get; set; } = string.Empty;
    
    /// <summary>
    /// Difficulty level of this algorithm set
    /// </summary>
    public string Difficulty { get; set; } = "medium";
    
    /// <summary>
    /// Whether this algorithm set is enabled
    /// </summary>
    public bool Enabled { get; set; } = true;
    
    /// <summary>
    /// Priority for algorithm selection (lower = higher priority)
    /// </summary>
    public int Priority { get; set; } = 100;
    
    /// <summary>
    /// Directories containing algorithms for this set
    /// </summary>
    public List<string> Directories { get; set; } = new();
    
    /// <summary>
    /// All algorithms in this set
    /// </summary>
    public Dictionary<string, Algorithm> Algorithms { get; set; } = new();
    
    /// <summary>
    /// Gets algorithms by category
    /// </summary>
    public IEnumerable<Algorithm> GetAlgorithmsByCategory(string category)
        => Algorithms.Values.Where(a => a.Category.Equals(category, StringComparison.OrdinalIgnoreCase));
    
    /// <summary>
    /// Gets algorithms by category and subcategory
    /// </summary>
    public IEnumerable<Algorithm> GetAlgorithms(string category, string? subcategory = null)
    {
        var algorithms = GetAlgorithmsByCategory(category);
        
        if (!string.IsNullOrEmpty(subcategory))
        {
            algorithms = algorithms.Where(a => a.Subcategory.Equals(subcategory, StringComparison.OrdinalIgnoreCase));
        }
        
        return algorithms;
    }
    
    /// <summary>
    /// Finds an algorithm by ID
    /// </summary>
    public Algorithm? FindById(string algorithmId)
        => Algorithms.TryGetValue(algorithmId, out var algorithm) ? algorithm : null;
    
    /// <summary>
    /// Gets the total number of algorithms in this set
    /// </summary>
    public int AlgorithmCount => Algorithms.Count;
    
    /// <summary>
    /// Gets all categories in this algorithm set
    /// </summary>
    public IEnumerable<string> Categories => Algorithms.Values.Select(a => a.Category).Distinct();
    
    public override string ToString()
        => $"{Name} ({AlgorithmCount} algorithms)";
}

/// <summary>
/// Configuration for algorithm sets
/// </summary>
public class AlgorithmConfig
{
    /// <summary>
    /// Available algorithm sets
    /// </summary>
    [JsonPropertyName("algorithmSets")]
    public Dictionary<string, AlgorithmSetConfig> AlgorithmSets { get; set; } = new();
    
    /// <summary>
    /// Default algorithm set to use
    /// </summary>
    [JsonPropertyName("defaultSet")]
    public string DefaultSet { get; set; } = "beginner";
    
    /// <summary>
    /// Base directory for algorithm files
    /// </summary>
    [JsonPropertyName("baseDirectory")]
    public string BaseDirectory { get; set; } = "algorithms";
}

/// <summary>
/// Configuration for a single algorithm set
/// </summary>
public class AlgorithmSetConfig
{
    /// <summary>
    /// Human-readable name for this algorithm set
    /// </summary>
    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;
    
    /// <summary>
    /// Description of this algorithm set
    /// </summary>
    [JsonPropertyName("description")]
    public string Description { get; set; } = string.Empty;
    
    /// <summary>
    /// Directories containing algorithms for this set
    /// </summary>
    [JsonPropertyName("directories")]
    public List<string> Directories { get; set; } = new();
    
    /// <summary>
    /// Whether this algorithm set is enabled
    /// </summary>
    [JsonPropertyName("enabled")]
    public bool Enabled { get; set; } = true;
    
    /// <summary>
    /// Priority for algorithm selection (lower = higher priority)
    /// </summary>
    [JsonPropertyName("priority")]
    public int Priority { get; set; } = 100;
    
    /// <summary>
    /// Difficulty level
    /// </summary>
    [JsonPropertyName("difficulty")]
    public string Difficulty { get; set; } = "medium";
}