using RubiksCube.Core.Models;
using CSharpFunctionalExtensions;

namespace RubiksCube.Core.Notation;

public static class NotationParser
{
    public static Result<List<IMove>> ParseAlgorithmWithRotations(string algorithm)
    {
        if (string.IsNullOrWhiteSpace(algorithm))
            return Result.Success(new List<IMove>());

        var operations = new List<IMove>();
        var cleanAlgorithm = FilterMetadata(algorithm);
        var tokens = Tokenize(cleanAlgorithm);

        foreach (var token in tokens)
        {
            if (IsValidMoveToken(token))
            {
                operations.Add(new MoveOperation(Move.Parse(token)));
            }
            else if (IsValidRotationToken(token))
            {
                operations.Add(new RotationOperation(Rotation.Parse(token)));
            }
            else if (!string.IsNullOrWhiteSpace(token))
            {
                // Check if it looks like it was meant to be a move (any uppercase letter that could be a face)
                if (token.Length > 0 && char.IsUpper(token[0]) && char.IsLetter(token[0]))
                {
                    // Valid face letters for moves
                    if ("FBLRUD".Contains(token[0]))
                    {
                        return Result.Failure<List<IMove>>($"Invalid move token: '{token}' in algorithm: '{algorithm}'");
                    }
                    // All other uppercase letters (including X, Y, Z) are likely intended as moves but invalid
                    // This maintains backward compatibility with existing tests
                    else
                    {
                        return Result.Failure<List<IMove>>($"Invalid move token: '{token}' in algorithm: '{algorithm}'");
                    }
                }
                else
                {
                    return Result.Failure<List<IMove>>($"Invalid token: '{token}' in algorithm: '{algorithm}'");
                }
            }
        }

        return Result.Success(operations);
    }

    public static Result<List<Move>> ParseAlgorithm(string algorithm)
    {
        if (string.IsNullOrWhiteSpace(algorithm))
            return Result.Success(new List<Move>());

        var moves = new List<Move>();
        var cleanAlgorithm = FilterMetadata(algorithm);
        var tokens = Tokenize(cleanAlgorithm);

        foreach (var token in tokens)
        {
            if (IsValidMoveToken(token))
            {
                // Move.Parse can still throw for programming errors (null, malformed)
                // but we've already validated the token
                moves.Add(Move.Parse(token));
            }
            else if (IsValidRotationToken(token))
            {
                return Result.Failure<List<Move>>($"Rotation '{token}' found in algorithm, but this parser only handles face moves. Use ParseAlgorithmWithRotations instead.");
            }
            else if (!string.IsNullOrWhiteSpace(token))
            {
                return Result.Failure<List<Move>>($"Invalid move token: '{token}' in algorithm: '{algorithm}'");
            }
        }

        return Result.Success(moves);
    }

    // Legacy method for backward compatibility - will remove after refactoring callers
    public static List<Move> ParseAlgorithmUnsafe(string algorithm)
    {
        var result = ParseAlgorithm(algorithm);
        if (result.IsSuccess)
            return result.Value;
        
        throw new ArgumentException(result.Error);
    }

    public static string FilterMetadata(string algorithm)
    {
        if (string.IsNullOrWhiteSpace(algorithm))
            return string.Empty;

        var result = algorithm;
        
        // Remove content in braces: {comment}
        result = RemoveBracedContent(result);
        
        // Remove content in parentheses (for grouping that we'll ignore for now)
        result = RemoveParenthesesContent(result);
        
        return result.Trim();
    }

    private static string RemoveBracedContent(string input)
    {
        var result = input;
        while (true)
        {
            var start = result.IndexOf('{');
            if (start == -1) break;
            
            var end = result.IndexOf('}', start);
            if (end == -1) break; // Unmatched brace, keep as is
            
            result = result.Remove(start, end - start + 1);
        }
        
        // Clean up extra whitespace
        return System.Text.RegularExpressions.Regex.Replace(result, @"\s+", " ");
    }

    private static string RemoveParenthesesContent(string input)
    {
        // For now, just remove parentheses but keep content
        // Later we might use them for grouping/repetition
        return input.Replace("(", "").Replace(")", "");
    }

    private static string[] Tokenize(string algorithm)
    {
        // Split on whitespace and common delimiters
        var separators = new[] { ' ', '\t', '\n', '\r', ',' };
        return algorithm.Split(separators, StringSplitOptions.RemoveEmptyEntries);
    }

    private static bool IsValidMoveToken(string token)
    {
        if (string.IsNullOrWhiteSpace(token))
            return false;

        // Basic validation - let Move.Parse do the heavy lifting
        try
        {
            Move.Parse(token);
            return true;
        }
        catch
        {
            return false;
        }
    }
    
    private static bool IsValidRotationToken(string token)
    {
        if (string.IsNullOrWhiteSpace(token))
            return false;

        // Check if it's a rotation token (x, y, z with optional modifiers)
        try
        {
            Rotation.Parse(token);
            return true;
        }
        catch
        {
            return false;
        }
    }

    public static bool IsValidAlgorithm(string algorithm)
    {
        return ParseAlgorithm(algorithm).IsSuccess;
    }

    public static Result<int> CountMoves(string algorithm)
    {
        return ParseAlgorithm(algorithm)
            .Map(moves => moves.Count);
    }

    public static Result<string> NormalizeAlgorithm(string algorithm)
    {
        return ParseAlgorithm(algorithm)
            .Map(moves => string.Join(" ", moves.Select(m => m.ToString())));
    }

    // Legacy unsafe methods for backward compatibility
    public static int CountMovesUnsafe(string algorithm)
    {
        return CountMoves(algorithm).Value; // Will throw if invalid
    }

    public static string NormalizeAlgorithmUnsafe(string algorithm)
    {
        return NormalizeAlgorithm(algorithm).Value; // Will throw if invalid
    }

    // Future extension point for advanced notation features
    public static class Advanced
    {
        // Placeholder for future features like:
        // - Repetition notation: (R U R' U')3
        // - Wide moves: Rw, Uw
        // - Slice moves: M, E, S
        // - Rotations: x, y, z
        
        public static bool ContainsWideOrSliceMoves(string algorithm)
        {
            var wideMovePattern = new[] { "Rw", "Lw", "Uw", "Dw", "Fw", "Bw", "M", "E", "S" };
            return wideMovePattern.Any(pattern => algorithm.Contains(pattern));
        }
        
        public static bool ContainsRotations(string algorithm)
        {
            var rotationPattern = new[] { "x", "y", "z" };
            return rotationPattern.Any(pattern => algorithm.Contains(pattern));
        }
    }
}