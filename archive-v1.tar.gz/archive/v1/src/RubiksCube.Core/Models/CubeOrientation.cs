namespace RubiksCube.Core.Models;

/// <summary>
/// Represents the orientation of a cube in 3D space by tracking which physical face
/// is currently in each position (Front, Back, Right, Left, Up, Down).
/// </summary>
public class CubeOrientation
{
    // Maps from position (Front, Back, etc.) to which face is currently there
    private readonly Dictionary<CubeFace, CubeFace> _positionToFace;
    
    public CubeOrientation()
    {
        // Initialize with standard WCA orientation: White on bottom (Down), Green on Front
        _positionToFace = new Dictionary<CubeFace, CubeFace>
        {
            { CubeFace.Front, CubeFace.Front },   // Green stays on Front
            { CubeFace.Back, CubeFace.Back },     // Blue stays on Back
            { CubeFace.Right, CubeFace.Right },   // Red stays on Right
            { CubeFace.Left, CubeFace.Left },     // Orange stays on Left
            { CubeFace.Up, CubeFace.Up },         // Yellow stays on Up
            { CubeFace.Down, CubeFace.Down }      // White stays on Down
        };
    }
    
    private CubeOrientation(Dictionary<CubeFace, CubeFace> positionToFace)
    {
        _positionToFace = new Dictionary<CubeFace, CubeFace>(positionToFace);
    }
    
    /// <summary>
    /// Gets which face is currently in the specified position.
    /// For example, after a y rotation, GetFaceAt(CubeFace.Front) might return CubeFace.Right.
    /// </summary>
    public CubeFace GetFaceAt(CubeFace position)
    {
        return _positionToFace[position];
    }
    
    /// <summary>
    /// Creates a copy of this orientation.
    /// </summary>
    public CubeOrientation Clone()
    {
        return new CubeOrientation(_positionToFace);
    }

    /// <summary>
    /// Sets the orientation from a mapping of position names to color names.
    /// </summary>
    public void SetOrientationFromColors(Dictionary<string, string> orientationColors)
    {
        var colorToFace = new Dictionary<string, CubeFace>
        {
            { "Green", CubeFace.Front },
            { "Orange", CubeFace.Right },
            { "Blue", CubeFace.Back },
            { "Red", CubeFace.Left },
            { "Yellow", CubeFace.Up },
            { "White", CubeFace.Down }
        };

        var positionMap = new Dictionary<string, CubeFace>
        {
            { "front", CubeFace.Front },
            { "right", CubeFace.Right },
            { "back", CubeFace.Back },
            { "left", CubeFace.Left },
            { "up", CubeFace.Up },
            { "down", CubeFace.Down }
        };

        foreach (var entry in orientationColors)
        {
            if (positionMap.TryGetValue(entry.Key.ToLower(), out var position) &&
                colorToFace.TryGetValue(entry.Value, out var face))
            {
                _positionToFace[position] = face;
            }
        }
    }
    
    /// <summary>
    /// Apply an X rotation (around the R-L axis).
    /// </summary>
    public void ApplyXRotation(RotationDirection direction)
    {
        var oldMapping = new Dictionary<CubeFace, CubeFace>(_positionToFace);
        
        switch (direction)
        {
            case RotationDirection.Clockwise:
                // F → U → B → D → F
                _positionToFace[CubeFace.Front] = oldMapping[CubeFace.Down];
                _positionToFace[CubeFace.Up] = oldMapping[CubeFace.Front];
                _positionToFace[CubeFace.Back] = oldMapping[CubeFace.Up];
                _positionToFace[CubeFace.Down] = oldMapping[CubeFace.Back];
                // R and L stay in place but rotate
                break;
                
            case RotationDirection.CounterClockwise:
                // F → D → B → U → F
                _positionToFace[CubeFace.Front] = oldMapping[CubeFace.Up];
                _positionToFace[CubeFace.Down] = oldMapping[CubeFace.Front];
                _positionToFace[CubeFace.Back] = oldMapping[CubeFace.Down];
                _positionToFace[CubeFace.Up] = oldMapping[CubeFace.Back];
                break;
                
            case RotationDirection.Double:
                // F ↔ B, U ↔ D
                _positionToFace[CubeFace.Front] = oldMapping[CubeFace.Back];
                _positionToFace[CubeFace.Back] = oldMapping[CubeFace.Front];
                _positionToFace[CubeFace.Up] = oldMapping[CubeFace.Down];
                _positionToFace[CubeFace.Down] = oldMapping[CubeFace.Up];
                break;
        }
    }
    
    /// <summary>
    /// Apply a Y rotation (around the U-D axis).
    /// </summary>
    public void ApplyYRotation(RotationDirection direction)
    {
        var oldMapping = new Dictionary<CubeFace, CubeFace>(_positionToFace);
        
        switch (direction)
        {
            case RotationDirection.Clockwise:
                // y: F → R → B → L → F (clockwise when viewed from above, follows U direction)
                _positionToFace[CubeFace.Front] = oldMapping[CubeFace.Left];
                _positionToFace[CubeFace.Right] = oldMapping[CubeFace.Front];
                _positionToFace[CubeFace.Back] = oldMapping[CubeFace.Right];
                _positionToFace[CubeFace.Left] = oldMapping[CubeFace.Back];
                // U and D stay in place but rotate
                break;
                
            case RotationDirection.CounterClockwise:
                // y': F → L → B → R → F (counterclockwise when viewed from above)
                _positionToFace[CubeFace.Front] = oldMapping[CubeFace.Right];
                _positionToFace[CubeFace.Left] = oldMapping[CubeFace.Front];
                _positionToFace[CubeFace.Back] = oldMapping[CubeFace.Left];
                _positionToFace[CubeFace.Right] = oldMapping[CubeFace.Back];
                break;
                
            case RotationDirection.Double:
                // F ↔ B, L ↔ R
                _positionToFace[CubeFace.Front] = oldMapping[CubeFace.Back];
                _positionToFace[CubeFace.Back] = oldMapping[CubeFace.Front];
                _positionToFace[CubeFace.Left] = oldMapping[CubeFace.Right];
                _positionToFace[CubeFace.Right] = oldMapping[CubeFace.Left];
                break;
        }
    }
    
    /// <summary>
    /// Apply a Z rotation (around the F-B axis).
    /// </summary>
    public void ApplyZRotation(RotationDirection direction)
    {
        var oldMapping = new Dictionary<CubeFace, CubeFace>(_positionToFace);
        
        switch (direction)
        {
            case RotationDirection.Clockwise:
                // z: U → L → D → R → U (clockwise when viewed from front, follows F direction)
                _positionToFace[CubeFace.Up] = oldMapping[CubeFace.Left];
                _positionToFace[CubeFace.Right] = oldMapping[CubeFace.Up];
                _positionToFace[CubeFace.Down] = oldMapping[CubeFace.Right];
                _positionToFace[CubeFace.Left] = oldMapping[CubeFace.Down];
                // F and B stay in place but rotate
                break;
                
            case RotationDirection.CounterClockwise:
                // z': U → R → D → L → U (counter-clockwise when viewed from front)
                _positionToFace[CubeFace.Up] = oldMapping[CubeFace.Right];
                _positionToFace[CubeFace.Left] = oldMapping[CubeFace.Up];
                _positionToFace[CubeFace.Down] = oldMapping[CubeFace.Left];
                _positionToFace[CubeFace.Right] = oldMapping[CubeFace.Down];
                break;
                
            case RotationDirection.Double:
                // U ↔ D, L ↔ R
                _positionToFace[CubeFace.Up] = oldMapping[CubeFace.Down];
                _positionToFace[CubeFace.Down] = oldMapping[CubeFace.Up];
                _positionToFace[CubeFace.Left] = oldMapping[CubeFace.Right];
                _positionToFace[CubeFace.Right] = oldMapping[CubeFace.Left];
                break;
        }
    }
}

public enum RotationAxis
{
    X, // Around R-L axis (like R move)
    Y, // Around U-D axis (like U move)
    Z  // Around F-B axis (like F move)
}

public enum RotationDirection
{
    Clockwise = 1,
    CounterClockwise = -1,
    Double = 2
}

public record Rotation(RotationAxis Axis, RotationDirection Direction)
{
    public override string ToString()
    {
        var axisChar = Axis.ToString().ToLowerInvariant();
        return Direction switch
        {
            RotationDirection.Clockwise => axisChar,
            RotationDirection.CounterClockwise => axisChar + "'",
            RotationDirection.Double => axisChar + "2",
            _ => throw new InvalidOperationException($"Unknown rotation direction: {Direction}")
        };
    }
    
    public Rotation GetInverse()
    {
        var inverseDirection = Direction switch
        {
            RotationDirection.Clockwise => RotationDirection.CounterClockwise,
            RotationDirection.CounterClockwise => RotationDirection.Clockwise,
            RotationDirection.Double => RotationDirection.Double,
            _ => throw new InvalidOperationException($"Unknown rotation direction: {Direction}")
        };
        return new Rotation(Axis, inverseDirection);
    }
    
    public static Rotation Parse(string rotationString)
    {
        if (string.IsNullOrWhiteSpace(rotationString))
            throw new ArgumentException("Rotation string cannot be null or empty", nameof(rotationString));

        rotationString = rotationString.Trim();
        
        // Rotations must be lowercase in Singmaster notation
        if (rotationString.Length > 0 && char.IsUpper(rotationString[0]))
            throw new ArgumentException($"Rotation axis must be lowercase: {rotationString}", nameof(rotationString));

        if (rotationString.Length == 0 || rotationString.Length > 2)
            throw new ArgumentException($"Invalid rotation string format: {rotationString}", nameof(rotationString));

        var axisChar = rotationString[0];
        var axis = axisChar switch
        {
            'x' => RotationAxis.X,
            'y' => RotationAxis.Y,
            'z' => RotationAxis.Z,
            _ => throw new ArgumentException($"Invalid rotation axis: {axisChar}", nameof(rotationString))
        };

        if (rotationString.Length == 1)
        {
            return new Rotation(axis, RotationDirection.Clockwise);
        }
        else
        {
            var direction = rotationString[1] switch
            {
                '\'' => RotationDirection.CounterClockwise,
                '2' => RotationDirection.Double,
                _ => throw new ArgumentException($"Invalid rotation modifier: {rotationString[1]}", nameof(rotationString))
            };
            return new Rotation(axis, direction);
        }
    }
}