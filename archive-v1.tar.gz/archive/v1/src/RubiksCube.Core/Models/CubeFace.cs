namespace RubiksCube.Core.Models;

public enum CubeFace
{
    Front = 0,
    Back = 1,
    Right = 2,
    Left = 3,
    Up = 4,
    Down = 5
}

public static class CubeFaceExtensions
{
    public static char ToChar(this CubeFace face) => face switch
    {
        CubeFace.Front => 'F',
        CubeFace.Back => 'B',
        CubeFace.Right => 'R',
        CubeFace.Left => 'L',
        CubeFace.Up => 'U',
        CubeFace.Down => 'D',
        _ => throw new ArgumentOutOfRangeException(nameof(face))
    };

    public static CubeFace FromChar(char c) => char.ToUpper(c) switch
    {
        'F' => CubeFace.Front,
        'B' => CubeFace.Back,
        'R' => CubeFace.Right,
        'L' => CubeFace.Left,
        'U' => CubeFace.Up,
        'D' => CubeFace.Down,
        _ => throw new ArgumentOutOfRangeException(nameof(c), $"Invalid face character: {c}")
    };

    public static CubeFace GetOpposite(this CubeFace face) => face switch
    {
        CubeFace.Front => CubeFace.Back,
        CubeFace.Back => CubeFace.Front,
        CubeFace.Right => CubeFace.Left,
        CubeFace.Left => CubeFace.Right,
        CubeFace.Up => CubeFace.Down,
        CubeFace.Down => CubeFace.Up,
        _ => throw new ArgumentOutOfRangeException(nameof(face))
    };
}