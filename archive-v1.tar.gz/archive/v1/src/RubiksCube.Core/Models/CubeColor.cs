namespace RubiksCube.Core.Models;

public enum CubeColor
{
    White = 0,
    Red = 1,
    Blue = 2,
    Orange = 3,
    Green = 4,
    Yellow = 5
}

public static class CubeColorExtensions
{
    public static char ToChar(this CubeColor color) => color switch
    {
        CubeColor.White => 'W',
        CubeColor.Red => 'R',
        CubeColor.Blue => 'B',
        CubeColor.Orange => 'O',
        CubeColor.Green => 'G',
        CubeColor.Yellow => 'Y',
        _ => throw new ArgumentOutOfRangeException(nameof(color))
    };

    public static CubeColor FromChar(char c) => char.ToUpper(c) switch
    {
        'W' => CubeColor.White,
        'R' => CubeColor.Red,
        'B' => CubeColor.Blue,
        'O' => CubeColor.Orange,
        'G' => CubeColor.Green,
        'Y' => CubeColor.Yellow,
        _ => throw new ArgumentOutOfRangeException(nameof(c), $"Invalid color character: {c}")
    };
}