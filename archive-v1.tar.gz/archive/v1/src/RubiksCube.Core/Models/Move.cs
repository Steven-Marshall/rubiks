namespace RubiksCube.Core.Models;

public enum MoveType
{
    Clockwise = 1,
    CounterClockwise = -1,
    Double = 2
}

public record Move(CubeFace Face, MoveType Type)
{
    public override string ToString()
    {
        return Type switch
        {
            MoveType.Clockwise => Face.ToChar().ToString(),
            MoveType.CounterClockwise => Face.ToChar() + "'",
            MoveType.Double => Face.ToChar() + "2",
            _ => throw new InvalidOperationException($"Unknown move type: {Type}")
        };
    }

    public static Move Parse(string moveString)
    {
        if (string.IsNullOrWhiteSpace(moveString))
            throw new ArgumentException("Move string cannot be null or empty", nameof(moveString));

        moveString = moveString.Trim();

        if (moveString.Length == 1)
        {
            return new Move(CubeFaceExtensions.FromChar(moveString[0]), MoveType.Clockwise);
        }
        else if (moveString.Length == 2)
        {
            var face = CubeFaceExtensions.FromChar(moveString[0]);
            return moveString[1] switch
            {
                '\'' => new Move(face, MoveType.CounterClockwise),
                '2' => new Move(face, MoveType.Double),
                _ => throw new ArgumentException($"Invalid move modifier: {moveString[1]}", nameof(moveString))
            };
        }
        else
        {
            throw new ArgumentException($"Invalid move string format: {moveString}", nameof(moveString));
        }
    }

    public Move GetInverse() => Type switch
    {
        MoveType.Clockwise => new Move(Face, MoveType.CounterClockwise),
        MoveType.CounterClockwise => new Move(Face, MoveType.Clockwise),
        MoveType.Double => new Move(Face, MoveType.Double),
        _ => throw new InvalidOperationException($"Unknown move type: {Type}")
    };
}