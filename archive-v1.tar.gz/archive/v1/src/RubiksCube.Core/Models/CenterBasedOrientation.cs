using System.Text.Json;

namespace RubiksCube.Core.Models;

/// <summary>
/// Tracks cube orientation using center piece positions instead of face mappings.
/// This approach allows proper piece-based rendering that accounts for face rotation within positions.
/// </summary>
public class CenterBasedOrientation
{
    // Tracks which color center is currently in each viewing position
    private CubeColor _frontCenter;
    private CubeColor _rightCenter;
    private CubeColor _backCenter;
    private CubeColor _leftCenter;
    private CubeColor _upCenter;
    private CubeColor _downCenter;

    public CenterBasedOrientation()
    {
        // Initialize with standard WCA orientation: Yellow top, Green front, Red left
        _frontCenter = CubeColor.Green;   // Green center in front position
        _rightCenter = CubeColor.Orange;  // Orange center in right position
        _backCenter = CubeColor.Blue;     // Blue center in back position
        _leftCenter = CubeColor.Red;      // Red center in left position
        _upCenter = CubeColor.Yellow;     // Yellow center in up position
        _downCenter = CubeColor.White;    // White center in down position
    }

    private CenterBasedOrientation(CubeColor front, CubeColor right, CubeColor back, 
                                  CubeColor left, CubeColor up, CubeColor down)
    {
        _frontCenter = front;
        _rightCenter = right;
        _backCenter = back;
        _leftCenter = left;
        _upCenter = up;
        _downCenter = down;
    }

    /// <summary>
    /// Gets the color of the center piece currently in the specified viewing position.
    /// </summary>
    public CubeColor GetCenterAt(CubeFace position)
    {
        return position switch
        {
            CubeFace.Front => _frontCenter,
            CubeFace.Right => _rightCenter,
            CubeFace.Back => _backCenter,
            CubeFace.Left => _leftCenter,
            CubeFace.Up => _upCenter,
            CubeFace.Down => _downCenter,
            _ => throw new ArgumentException($"Invalid face position: {position}")
        };
    }

    /// <summary>
    /// Gets which viewing position currently contains the specified color center.
    /// </summary>
    public CubeFace GetPositionOf(CubeColor centerColor)
    {
        if (_frontCenter == centerColor) return CubeFace.Front;
        if (_rightCenter == centerColor) return CubeFace.Right;
        if (_backCenter == centerColor) return CubeFace.Back;
        if (_leftCenter == centerColor) return CubeFace.Left;
        if (_upCenter == centerColor) return CubeFace.Up;
        if (_downCenter == centerColor) return CubeFace.Down;
        
        throw new ArgumentException($"Center color not found: {centerColor}");
    }

    /// <summary>
    /// Creates a copy of this orientation.
    /// </summary>
    public CenterBasedOrientation Clone()
    {
        return new CenterBasedOrientation(_frontCenter, _rightCenter, _backCenter, 
                                        _leftCenter, _upCenter, _downCenter);
    }

    /// <summary>
    /// Apply an X rotation (around the R-L axis).
    /// </summary>
    public void ApplyXRotation(RotationDirection direction)
    {
        var originalFront = _frontCenter;
        var originalUp = _upCenter;
        var originalBack = _backCenter;
        var originalDown = _downCenter;

        switch (direction)
        {
            case RotationDirection.Clockwise:
                // x: F → U → B → D → F (clockwise when viewed from right)
                _frontCenter = originalDown;
                _upCenter = originalFront;
                _backCenter = originalUp;
                _downCenter = originalBack;
                break;

            case RotationDirection.CounterClockwise:
                // x': F → D → B → U → F (counter-clockwise when viewed from right)
                _frontCenter = originalUp;
                _downCenter = originalFront;
                _backCenter = originalDown;
                _upCenter = originalBack;
                break;

            case RotationDirection.Double:
                // x2: F ↔ B, U ↔ D
                _frontCenter = originalBack;
                _backCenter = originalFront;
                _upCenter = originalDown;
                _downCenter = originalUp;
                break;
        }
        // Left and Right centers stay in place during X rotation
    }

    /// <summary>
    /// Apply a Y rotation (around the U-D axis).
    /// </summary>
    public void ApplyYRotation(RotationDirection direction)
    {
        var originalFront = _frontCenter;
        var originalRight = _rightCenter;
        var originalBack = _backCenter;
        var originalLeft = _leftCenter;

        switch (direction)
        {
            case RotationDirection.Clockwise:
                // y: F → L → B → R → F (clockwise when viewed from above)
                _frontCenter = originalRight;
                _leftCenter = originalFront;
                _backCenter = originalLeft;
                _rightCenter = originalBack;
                break;

            case RotationDirection.CounterClockwise:
                // y': F → R → B → L → F (counter-clockwise when viewed from above)
                _frontCenter = originalLeft;
                _rightCenter = originalFront;
                _backCenter = originalRight;
                _leftCenter = originalBack;
                break;

            case RotationDirection.Double:
                // y2: F ↔ B, L ↔ R
                _frontCenter = originalBack;
                _backCenter = originalFront;
                _leftCenter = originalRight;
                _rightCenter = originalLeft;
                break;
        }
        // Up and Down centers stay in place during Y rotation
    }

    /// <summary>
    /// Apply a Z rotation (around the F-B axis).
    /// </summary>
    public void ApplyZRotation(RotationDirection direction)
    {
        var originalUp = _upCenter;
        var originalRight = _rightCenter;
        var originalDown = _downCenter;
        var originalLeft = _leftCenter;

        switch (direction)
        {
            case RotationDirection.Clockwise:
                // z: U → L → D → R → U (clockwise when viewed from front)
                _upCenter = originalRight;
                _leftCenter = originalUp;
                _downCenter = originalLeft;
                _rightCenter = originalDown;
                break;

            case RotationDirection.CounterClockwise:
                // z': U → R → D → L → U (counter-clockwise when viewed from front)
                _upCenter = originalLeft;
                _rightCenter = originalUp;
                _downCenter = originalRight;
                _leftCenter = originalDown;
                break;

            case RotationDirection.Double:
                // z2: U ↔ D, L ↔ R
                _upCenter = originalDown;
                _downCenter = originalUp;
                _leftCenter = originalRight;
                _rightCenter = originalLeft;
                break;
        }
        // Front and Back centers stay in place during Z rotation
    }

    /// <summary>
    /// Sets the orientation from a JSON mapping of position names to color names.
    /// Used for deserialization.
    /// </summary>
    public void SetOrientationFromColors(Dictionary<string, string> orientationColors)
    {
        var stringToColor = new Dictionary<string, CubeColor>
        {
            { "Green", CubeColor.Green },
            { "Orange", CubeColor.Orange },
            { "Blue", CubeColor.Blue },
            { "Red", CubeColor.Red },
            { "Yellow", CubeColor.Yellow },
            { "White", CubeColor.White }
        };

        foreach (var entry in orientationColors)
        {
            if (stringToColor.TryGetValue(entry.Value, out var color))
            {
                switch (entry.Key.ToLower())
                {
                    case "front":
                        _frontCenter = color;
                        break;
                    case "right":
                        _rightCenter = color;
                        break;
                    case "back":
                        _backCenter = color;
                        break;
                    case "left":
                        _leftCenter = color;
                        break;
                    case "up":
                        _upCenter = color;
                        break;
                    case "down":
                        _downCenter = color;
                        break;
                }
            }
        }
    }

    /// <summary>
    /// Gets orientation data for JSON serialization.
    /// </summary>
    public Dictionary<string, string> GetOrientationForJson()
    {
        var colorToString = new Dictionary<CubeColor, string>
        {
            { CubeColor.Green, "Green" },
            { CubeColor.Orange, "Orange" },
            { CubeColor.Blue, "Blue" },
            { CubeColor.Red, "Red" },
            { CubeColor.Yellow, "Yellow" },
            { CubeColor.White, "White" }
        };

        return new Dictionary<string, string>
        {
            { "front", colorToString[_frontCenter] },
            { "right", colorToString[_rightCenter] },
            { "back", colorToString[_backCenter] },
            { "left", colorToString[_leftCenter] },
            { "up", colorToString[_upCenter] },
            { "down", colorToString[_downCenter] }
        };
    }

    /// <summary>
    /// Provides debug information about current center positions.
    /// </summary>
    public string GetDebugInfo()
    {
        return $"Front center: {_frontCenter}, " +
               $"Right center: {_rightCenter}, " +
               $"Back center: {_backCenter}, " +
               $"Left center: {_leftCenter}, " +
               $"Up center: {_upCenter}, " +
               $"Down center: {_downCenter}";
    }

    /// <summary>
    /// Checks if two orientations are equivalent.
    /// </summary>
    public bool IsEquivalentTo(CenterBasedOrientation other)
    {
        return other != null &&
               _frontCenter == other._frontCenter &&
               _rightCenter == other._rightCenter &&
               _backCenter == other._backCenter &&
               _leftCenter == other._leftCenter &&
               _upCenter == other._upCenter &&
               _downCenter == other._downCenter;
    }
}