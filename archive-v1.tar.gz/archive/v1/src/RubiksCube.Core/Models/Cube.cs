using System.Text.Json;
using System.Text.Json.Serialization;
using CSharpFunctionalExtensions;

namespace RubiksCube.Core.Models;

public class Cube
{
    private readonly CubeColor[,] _faces;
    private readonly CubeOrientation _orientation;
    private readonly CenterBasedOrientation _centerBasedOrientation;

    public Cube()
    {
        _faces = new CubeColor[6, 9];
        _orientation = new CubeOrientation();
        _centerBasedOrientation = new CenterBasedOrientation();
        InitializeSolved();
    }

    public Cube(CubeColor[,] faces)
    {
        if (faces.GetLength(0) != 6 || faces.GetLength(1) != 9)
            throw new ArgumentException("Faces array must be 6x9", nameof(faces));
        
        _faces = (CubeColor[,])faces.Clone();
        _orientation = new CubeOrientation();
        _centerBasedOrientation = new CenterBasedOrientation();
    }
    
    private Cube(CubeColor[,] faces, CubeOrientation orientation)
    {
        _faces = (CubeColor[,])faces.Clone();
        _orientation = orientation.Clone();
        _centerBasedOrientation = new CenterBasedOrientation();
    }
    
    private Cube(CubeColor[,] faces, CubeOrientation orientation, CenterBasedOrientation centerBasedOrientation)
    {
        _faces = (CubeColor[,])faces.Clone();
        _orientation = orientation.Clone();
        _centerBasedOrientation = centerBasedOrientation.Clone();
    }

    public CubeColor GetSticker(CubeFace face, int position)
    {
        if (position < 0 || position > 8)
            throw new ArgumentOutOfRangeException(nameof(position), "Position must be 0-8");
        
        return _faces[(int)face, position];
    }

    public void SetSticker(CubeFace face, int position, CubeColor color)
    {
        if (position < 0 || position > 8)
            throw new ArgumentOutOfRangeException(nameof(position), "Position must be 0-8");
        
        _faces[(int)face, position] = color;
    }

    public CubeColor[] GetFace(CubeFace face)
    {
        var result = new CubeColor[9];
        for (int i = 0; i < 9; i++)
        {
            result[i] = _faces[(int)face, i];
        }
        return result;
    }

    /// <summary>
    /// Gets the face that is currently in the specified position based on current orientation.
    /// For example, after a y' rotation, GetFaceFromCurrentOrientation(CubeFace.Front) 
    /// will return the face that is now facing front, not the original Front face.
    /// </summary>
    public CubeColor[] GetFaceFromCurrentOrientation(CubeFace position)
    {
        var actualFace = _orientation.GetFaceAt(position);
        return GetFace(actualFace);
    }

    /// <summary>
    /// Maps each face to its center color (which never changes).
    /// </summary>
    private static readonly Dictionary<CubeFace, string> FaceToColor = new()
    {
        { CubeFace.Front, "Green" },
        { CubeFace.Right, "Orange" },
        { CubeFace.Back, "Blue" },
        { CubeFace.Left, "Red" },
        { CubeFace.Up, "Yellow" },
        { CubeFace.Down, "White" }
    };

    /// <summary>
    /// Maps each color to its corresponding face.
    /// </summary>
    private static readonly Dictionary<string, CubeFace> ColorToFace = new()
    {
        { "Green", CubeFace.Front },
        { "Orange", CubeFace.Right },
        { "Blue", CubeFace.Back },
        { "Red", CubeFace.Left },
        { "Yellow", CubeFace.Up },
        { "White", CubeFace.Down }
    };

    /// <summary>
    /// Gets the color name for a face (based on center sticker).
    /// </summary>
    public static string GetColorForFace(CubeFace face) => FaceToColor[face];

    /// <summary>
    /// Gets the face that has the specified color center.
    /// </summary>
    public static CubeFace GetFaceForColor(string color) => ColorToFace[color];

    /// <summary>
    /// Debug method to check which color is currently at each position.
    /// </summary>
    public string GetOrientationDebugInfo()
    {
        return $"Front position has: {GetColorForFace(_orientation.GetFaceAt(CubeFace.Front))}, " +
               $"Right position has: {GetColorForFace(_orientation.GetFaceAt(CubeFace.Right))}, " +
               $"Back position has: {GetColorForFace(_orientation.GetFaceAt(CubeFace.Back))}, " +
               $"Left position has: {GetColorForFace(_orientation.GetFaceAt(CubeFace.Left))}";
    }

    /// <summary>
    /// Sets the cube orientation from a mapping of positions to colors.
    /// </summary>
    public void SetOrientationFromColors(Dictionary<string, string> orientationColors)
    {
        _orientation.SetOrientationFromColors(orientationColors);
    }

    /// <summary>
    /// Gets the center-based orientation for rendering and piece lookup.
    /// </summary>
    public CenterBasedOrientation GetCenterBasedOrientation()
    {
        return _centerBasedOrientation;
    }
    
    /// <summary>
    /// Debug method to check center-based orientation.
    /// </summary>
    public string GetCenterBasedOrientationDebugInfo()
    {
        return _centerBasedOrientation.GetDebugInfo();
    }

    public void SetFace(CubeFace face, CubeColor[] colors)
    {
        if (colors.Length != 9)
            throw new ArgumentException("Face must have exactly 9 colors", nameof(colors));
        
        for (int i = 0; i < 9; i++)
        {
            _faces[(int)face, i] = colors[i];
        }
    }

    private void InitializeSolved()
    {
        // CFOP Standard: White bottom, Green front (Western color scheme)
        // Face layout: Front=0, Back=1, Right=2, Left=3, Up=4, Down=5
        SetFace(CubeFace.Front, Enumerable.Repeat(CubeColor.Green, 9).ToArray());
        SetFace(CubeFace.Back, Enumerable.Repeat(CubeColor.Blue, 9).ToArray());
        SetFace(CubeFace.Right, Enumerable.Repeat(CubeColor.Orange, 9).ToArray());
        SetFace(CubeFace.Left, Enumerable.Repeat(CubeColor.Red, 9).ToArray());
        SetFace(CubeFace.Up, Enumerable.Repeat(CubeColor.Yellow, 9).ToArray());
        SetFace(CubeFace.Down, Enumerable.Repeat(CubeColor.White, 9).ToArray());
    }

    public bool IsSolved()
    {
        foreach (CubeFace face in Enum.GetValues<CubeFace>())
        {
            var faceColors = GetFace(face);
            var centerColor = faceColors[4]; // Center piece
            
            if (faceColors.Any(color => color != centerColor))
                return false;
        }
        return true;
    }

    public Result ApplyMove(Move move)
    {
        // Apply move to the actual face that's currently in the position
        var actualFace = _orientation.GetFaceAt(move.Face);
        
        for (int i = 0; i < Math.Abs((int)move.Type); i++)
        {
            if (move.Type == MoveType.CounterClockwise)
                ApplyCounterClockwiseTurn(actualFace);
            else
                ApplyClockwiseTurn(actualFace);
        }
        
        return Result.Success();
    }
    
    public Result ApplyRotation(Rotation rotation)
    {
        // Update both orientation tracking systems - no sticker movement
        switch (rotation.Axis)
        {
            case RotationAxis.X:
                _orientation.ApplyXRotation(rotation.Direction);
                _centerBasedOrientation.ApplyXRotation(rotation.Direction);
                break;
            case RotationAxis.Y:
                _orientation.ApplyYRotation(rotation.Direction);
                _centerBasedOrientation.ApplyYRotation(rotation.Direction);
                break;
            case RotationAxis.Z:
                _orientation.ApplyZRotation(rotation.Direction);
                _centerBasedOrientation.ApplyZRotation(rotation.Direction);
                break;
            default:
                return Result.Failure($"Unknown rotation axis: {rotation.Axis}");
        }
        
        return Result.Success();
    }

    // Legacy method for backward compatibility
    public void ApplyMoveUnsafe(Move move)
    {
        var result = ApplyMove(move);
        if (result.IsFailure)
            throw new InvalidOperationException(result.Error);
    }

    private void ApplyClockwiseTurn(CubeFace face)
    {
        // Rotate the face itself 90 degrees clockwise
        RotateFaceClockwise(face);
        
        // Rotate adjacent face edges
        RotateAdjacentEdges(face, clockwise: true);
    }

    private void ApplyCounterClockwiseTurn(CubeFace face)
    {
        // Rotate the face itself 90 degrees counter-clockwise
        RotateFaceCounterClockwise(face);
        
        // Rotate adjacent face edges
        RotateAdjacentEdges(face, clockwise: false);
    }

    private void RotateFaceClockwise(CubeFace face)
    {
        var faceColors = GetFace(face);
        var rotated = new CubeColor[9];
        
        // Clockwise rotation mapping: 0->2, 1->5, 2->8, 3->1, 4->4, 5->7, 6->0, 7->3, 8->6
        int[] mapping = { 6, 3, 0, 7, 4, 1, 8, 5, 2 };
        
        for (int i = 0; i < 9; i++)
        {
            rotated[i] = faceColors[mapping[i]];
        }
        
        SetFace(face, rotated);
    }

    private void RotateFaceCounterClockwise(CubeFace face)
    {
        var faceColors = GetFace(face);
        var rotated = new CubeColor[9];
        
        // Counter-clockwise rotation mapping: 0->6, 1->3, 2->0, 3->7, 4->4, 5->1, 6->8, 7->5, 8->2
        int[] mapping = { 2, 5, 8, 1, 4, 7, 0, 3, 6 };
        
        for (int i = 0; i < 9; i++)
        {
            rotated[i] = faceColors[mapping[i]];
        }
        
        SetFace(face, rotated);
    }

    private void RotateAdjacentEdges(CubeFace face, bool clockwise)
    {
        // This is complex - need to define which edges move for each face
        // For now, implement a basic version for R moves
        switch (face)
        {
            case CubeFace.Right:
                RotateRightFaceEdges(clockwise);
                break;
            case CubeFace.Up:
                RotateUpFaceEdges(clockwise);
                break;
            case CubeFace.Front:
                RotateFrontFaceEdges(clockwise);
                break;
            case CubeFace.Left:
                RotateLeftFaceEdges(clockwise);
                break;
            case CubeFace.Down:
                RotateDownFaceEdges(clockwise);
                break;
            case CubeFace.Back:
                RotateBackFaceEdges(clockwise);
                break;
        }
    }

    private void RotateRightFaceEdges(bool clockwise)
    {
        var temp = new CubeColor[3];
        
        if (clockwise)
        {
            // Save Front right column
            temp[0] = GetSticker(CubeFace.Front, 2);
            temp[1] = GetSticker(CubeFace.Front, 5);
            temp[2] = GetSticker(CubeFace.Front, 8);
            
            // Front <- Down
            SetSticker(CubeFace.Front, 2, GetSticker(CubeFace.Down, 2));
            SetSticker(CubeFace.Front, 5, GetSticker(CubeFace.Down, 5));
            SetSticker(CubeFace.Front, 8, GetSticker(CubeFace.Down, 8));
            
            // Down <- Back (reversed)
            SetSticker(CubeFace.Down, 2, GetSticker(CubeFace.Back, 6));
            SetSticker(CubeFace.Down, 5, GetSticker(CubeFace.Back, 3));
            SetSticker(CubeFace.Down, 8, GetSticker(CubeFace.Back, 0));
            
            // Back <- Up (reversed)
            SetSticker(CubeFace.Back, 6, GetSticker(CubeFace.Up, 2));
            SetSticker(CubeFace.Back, 3, GetSticker(CubeFace.Up, 5));
            SetSticker(CubeFace.Back, 0, GetSticker(CubeFace.Up, 8));
            
            // Up <- Front (from temp)
            SetSticker(CubeFace.Up, 2, temp[0]);
            SetSticker(CubeFace.Up, 5, temp[1]);
            SetSticker(CubeFace.Up, 8, temp[2]);
        }
        else
        {
            // Counter-clockwise is the reverse
            // Save Front right column
            temp[0] = GetSticker(CubeFace.Front, 2);
            temp[1] = GetSticker(CubeFace.Front, 5);
            temp[2] = GetSticker(CubeFace.Front, 8);
            
            // Front <- Up
            SetSticker(CubeFace.Front, 2, GetSticker(CubeFace.Up, 2));
            SetSticker(CubeFace.Front, 5, GetSticker(CubeFace.Up, 5));
            SetSticker(CubeFace.Front, 8, GetSticker(CubeFace.Up, 8));
            
            // Up <- Back (reversed)
            SetSticker(CubeFace.Up, 2, GetSticker(CubeFace.Back, 6));
            SetSticker(CubeFace.Up, 5, GetSticker(CubeFace.Back, 3));
            SetSticker(CubeFace.Up, 8, GetSticker(CubeFace.Back, 0));
            
            // Back <- Down (reversed)
            SetSticker(CubeFace.Back, 6, GetSticker(CubeFace.Down, 2));
            SetSticker(CubeFace.Back, 3, GetSticker(CubeFace.Down, 5));
            SetSticker(CubeFace.Back, 0, GetSticker(CubeFace.Down, 8));
            
            // Down <- Front (from temp)
            SetSticker(CubeFace.Down, 2, temp[0]);
            SetSticker(CubeFace.Down, 5, temp[1]);
            SetSticker(CubeFace.Down, 8, temp[2]);
        }
    }

    // Placeholder implementations for other faces - need to be completed
    private void RotateUpFaceEdges(bool clockwise)
    {
        var temp = new CubeColor[3];
        
        if (clockwise)
        {
            // For U clockwise: Front top row -> Left top row -> Back top row -> Right top row -> Front
            // Save Front top row
            temp[0] = GetSticker(CubeFace.Front, 0);
            temp[1] = GetSticker(CubeFace.Front, 1);
            temp[2] = GetSticker(CubeFace.Front, 2);
            
            // Front <- Right
            SetSticker(CubeFace.Front, 0, GetSticker(CubeFace.Right, 0));
            SetSticker(CubeFace.Front, 1, GetSticker(CubeFace.Right, 1));
            SetSticker(CubeFace.Front, 2, GetSticker(CubeFace.Right, 2));
            
            // Right <- Back
            SetSticker(CubeFace.Right, 0, GetSticker(CubeFace.Back, 0));
            SetSticker(CubeFace.Right, 1, GetSticker(CubeFace.Back, 1));
            SetSticker(CubeFace.Right, 2, GetSticker(CubeFace.Back, 2));
            
            // Back <- Left
            SetSticker(CubeFace.Back, 0, GetSticker(CubeFace.Left, 0));
            SetSticker(CubeFace.Back, 1, GetSticker(CubeFace.Left, 1));
            SetSticker(CubeFace.Back, 2, GetSticker(CubeFace.Left, 2));
            
            // Left <- Front (from temp)
            SetSticker(CubeFace.Left, 0, temp[0]);
            SetSticker(CubeFace.Left, 1, temp[1]);
            SetSticker(CubeFace.Left, 2, temp[2]);
        }
        else
        {
            // Counter-clockwise: Front top row -> Right top row -> Back top row -> Left top row -> Front
            // Save Front top row
            temp[0] = GetSticker(CubeFace.Front, 0);
            temp[1] = GetSticker(CubeFace.Front, 1);
            temp[2] = GetSticker(CubeFace.Front, 2);
            
            // Front <- Left
            SetSticker(CubeFace.Front, 0, GetSticker(CubeFace.Left, 0));
            SetSticker(CubeFace.Front, 1, GetSticker(CubeFace.Left, 1));
            SetSticker(CubeFace.Front, 2, GetSticker(CubeFace.Left, 2));
            
            // Left <- Back
            SetSticker(CubeFace.Left, 0, GetSticker(CubeFace.Back, 0));
            SetSticker(CubeFace.Left, 1, GetSticker(CubeFace.Back, 1));
            SetSticker(CubeFace.Left, 2, GetSticker(CubeFace.Back, 2));
            
            // Back <- Right
            SetSticker(CubeFace.Back, 0, GetSticker(CubeFace.Right, 0));
            SetSticker(CubeFace.Back, 1, GetSticker(CubeFace.Right, 1));
            SetSticker(CubeFace.Back, 2, GetSticker(CubeFace.Right, 2));
            
            // Right <- Front (from temp)
            SetSticker(CubeFace.Right, 0, temp[0]);
            SetSticker(CubeFace.Right, 1, temp[1]);
            SetSticker(CubeFace.Right, 2, temp[2]);
        }
    }
    private void RotateFrontFaceEdges(bool clockwise)
    {
        var temp = new CubeColor[3];
        
        if (clockwise)
        {
            // For F clockwise: Up bottom row -> Left right column -> Down top row -> Right left column -> Up
            // Save Up bottom row
            temp[0] = GetSticker(CubeFace.Up, 6);
            temp[1] = GetSticker(CubeFace.Up, 7);
            temp[2] = GetSticker(CubeFace.Up, 8);
            
            // Up bottom row <- Left right column (reversed)
            SetSticker(CubeFace.Up, 6, GetSticker(CubeFace.Left, 8));
            SetSticker(CubeFace.Up, 7, GetSticker(CubeFace.Left, 5));
            SetSticker(CubeFace.Up, 8, GetSticker(CubeFace.Left, 2));
            
            // Left right column <- Down top row (reversed) 
            SetSticker(CubeFace.Left, 2, GetSticker(CubeFace.Down, 2));
            SetSticker(CubeFace.Left, 5, GetSticker(CubeFace.Down, 1));
            SetSticker(CubeFace.Left, 8, GetSticker(CubeFace.Down, 0));
            
            // Down top row <- Right left column (reversed)
            SetSticker(CubeFace.Down, 0, GetSticker(CubeFace.Right, 6));
            SetSticker(CubeFace.Down, 1, GetSticker(CubeFace.Right, 3));
            SetSticker(CubeFace.Down, 2, GetSticker(CubeFace.Right, 0));
            
            // Right left column <- Up bottom row (from temp)
            SetSticker(CubeFace.Right, 0, temp[0]);
            SetSticker(CubeFace.Right, 3, temp[1]);
            SetSticker(CubeFace.Right, 6, temp[2]);
        }
        else
        {
            // Counter-clockwise: Up bottom row -> Right left column -> Down top row -> Left right column -> Up
            // Save Up bottom row
            temp[0] = GetSticker(CubeFace.Up, 6);
            temp[1] = GetSticker(CubeFace.Up, 7);
            temp[2] = GetSticker(CubeFace.Up, 8);
            
            // Up bottom row <- Right left column (reversed)
            SetSticker(CubeFace.Up, 6, GetSticker(CubeFace.Right, 0));
            SetSticker(CubeFace.Up, 7, GetSticker(CubeFace.Right, 3));
            SetSticker(CubeFace.Up, 8, GetSticker(CubeFace.Right, 6));
            
            // Right left column <- Down top row
            SetSticker(CubeFace.Right, 0, GetSticker(CubeFace.Down, 2));
            SetSticker(CubeFace.Right, 3, GetSticker(CubeFace.Down, 1));
            SetSticker(CubeFace.Right, 6, GetSticker(CubeFace.Down, 0));
            
            // Down top row <- Left right column (reversed)
            SetSticker(CubeFace.Down, 0, GetSticker(CubeFace.Left, 2));
            SetSticker(CubeFace.Down, 1, GetSticker(CubeFace.Left, 5));
            SetSticker(CubeFace.Down, 2, GetSticker(CubeFace.Left, 8));
            
            // Left right column <- Up bottom row (from temp)
            SetSticker(CubeFace.Left, 2, temp[2]);
            SetSticker(CubeFace.Left, 5, temp[1]);
            SetSticker(CubeFace.Left, 8, temp[0]);
        }
    }
    private void RotateLeftFaceEdges(bool clockwise)
    {
        var temp = new CubeColor[3];
        
        if (clockwise)
        {
            // For L clockwise: Front left column -> Up left column -> Back right column (reversed) -> Down left column -> Front
            // Save Front left column
            temp[0] = GetSticker(CubeFace.Front, 0);
            temp[1] = GetSticker(CubeFace.Front, 3);
            temp[2] = GetSticker(CubeFace.Front, 6);
            
            // Front left column <- Up left column
            SetSticker(CubeFace.Front, 0, GetSticker(CubeFace.Up, 0));
            SetSticker(CubeFace.Front, 3, GetSticker(CubeFace.Up, 3));
            SetSticker(CubeFace.Front, 6, GetSticker(CubeFace.Up, 6));
            
            // Up left column <- Back right column (reversed)
            SetSticker(CubeFace.Up, 0, GetSticker(CubeFace.Back, 8));
            SetSticker(CubeFace.Up, 3, GetSticker(CubeFace.Back, 5));
            SetSticker(CubeFace.Up, 6, GetSticker(CubeFace.Back, 2));
            
            // Back right column <- Down left column (reversed)
            SetSticker(CubeFace.Back, 2, GetSticker(CubeFace.Down, 6));
            SetSticker(CubeFace.Back, 5, GetSticker(CubeFace.Down, 3));
            SetSticker(CubeFace.Back, 8, GetSticker(CubeFace.Down, 0));
            
            // Down left column <- Front left column (from temp)
            SetSticker(CubeFace.Down, 0, temp[0]);
            SetSticker(CubeFace.Down, 3, temp[1]);
            SetSticker(CubeFace.Down, 6, temp[2]);
        }
        else
        {
            // Counter-clockwise: Front left column -> Down left column -> Back right column (reversed) -> Up left column -> Front
            // Save Front left column
            temp[0] = GetSticker(CubeFace.Front, 0);
            temp[1] = GetSticker(CubeFace.Front, 3);
            temp[2] = GetSticker(CubeFace.Front, 6);
            
            // Front left column <- Down left column
            SetSticker(CubeFace.Front, 0, GetSticker(CubeFace.Down, 0));
            SetSticker(CubeFace.Front, 3, GetSticker(CubeFace.Down, 3));
            SetSticker(CubeFace.Front, 6, GetSticker(CubeFace.Down, 6));
            
            // Down left column <- Back right column (reversed)
            SetSticker(CubeFace.Down, 0, GetSticker(CubeFace.Back, 8));
            SetSticker(CubeFace.Down, 3, GetSticker(CubeFace.Back, 5));
            SetSticker(CubeFace.Down, 6, GetSticker(CubeFace.Back, 2));
            
            // Back right column <- Up left column (reversed)
            SetSticker(CubeFace.Back, 2, GetSticker(CubeFace.Up, 6));
            SetSticker(CubeFace.Back, 5, GetSticker(CubeFace.Up, 3));
            SetSticker(CubeFace.Back, 8, GetSticker(CubeFace.Up, 0));
            
            // Up left column <- Front left column (from temp)
            SetSticker(CubeFace.Up, 0, temp[0]);
            SetSticker(CubeFace.Up, 3, temp[1]);
            SetSticker(CubeFace.Up, 6, temp[2]);
        }
    }
    private void RotateDownFaceEdges(bool clockwise)
    {
        var temp = new CubeColor[3];
        
        if (clockwise)
        {
            // For D clockwise: Front bottom row -> Left bottom row -> Back bottom row -> Right bottom row -> Front
            // Save Front bottom row
            temp[0] = GetSticker(CubeFace.Front, 6);
            temp[1] = GetSticker(CubeFace.Front, 7);
            temp[2] = GetSticker(CubeFace.Front, 8);
            
            // Front bottom row <- Left bottom row
            SetSticker(CubeFace.Front, 6, GetSticker(CubeFace.Left, 6));
            SetSticker(CubeFace.Front, 7, GetSticker(CubeFace.Left, 7));
            SetSticker(CubeFace.Front, 8, GetSticker(CubeFace.Left, 8));
            
            // Left bottom row <- Back bottom row
            SetSticker(CubeFace.Left, 6, GetSticker(CubeFace.Back, 6));
            SetSticker(CubeFace.Left, 7, GetSticker(CubeFace.Back, 7));
            SetSticker(CubeFace.Left, 8, GetSticker(CubeFace.Back, 8));
            
            // Back bottom row <- Right bottom row
            SetSticker(CubeFace.Back, 6, GetSticker(CubeFace.Right, 6));
            SetSticker(CubeFace.Back, 7, GetSticker(CubeFace.Right, 7));
            SetSticker(CubeFace.Back, 8, GetSticker(CubeFace.Right, 8));
            
            // Right bottom row <- Front bottom row (from temp)
            SetSticker(CubeFace.Right, 6, temp[0]);
            SetSticker(CubeFace.Right, 7, temp[1]);
            SetSticker(CubeFace.Right, 8, temp[2]);
        }
        else
        {
            // Counter-clockwise: Front bottom row -> Right bottom row -> Back bottom row -> Left bottom row -> Front
            // Save Front bottom row
            temp[0] = GetSticker(CubeFace.Front, 6);
            temp[1] = GetSticker(CubeFace.Front, 7);
            temp[2] = GetSticker(CubeFace.Front, 8);
            
            // Front bottom row <- Right bottom row
            SetSticker(CubeFace.Front, 6, GetSticker(CubeFace.Right, 6));
            SetSticker(CubeFace.Front, 7, GetSticker(CubeFace.Right, 7));
            SetSticker(CubeFace.Front, 8, GetSticker(CubeFace.Right, 8));
            
            // Right bottom row <- Back bottom row
            SetSticker(CubeFace.Right, 6, GetSticker(CubeFace.Back, 6));
            SetSticker(CubeFace.Right, 7, GetSticker(CubeFace.Back, 7));
            SetSticker(CubeFace.Right, 8, GetSticker(CubeFace.Back, 8));
            
            // Back bottom row <- Left bottom row
            SetSticker(CubeFace.Back, 6, GetSticker(CubeFace.Left, 6));
            SetSticker(CubeFace.Back, 7, GetSticker(CubeFace.Left, 7));
            SetSticker(CubeFace.Back, 8, GetSticker(CubeFace.Left, 8));
            
            // Left bottom row <- Front bottom row (from temp)
            SetSticker(CubeFace.Left, 6, temp[0]);
            SetSticker(CubeFace.Left, 7, temp[1]);
            SetSticker(CubeFace.Left, 8, temp[2]);
        }
    }
    private void RotateBackFaceEdges(bool clockwise)
    {
        var temp = new CubeColor[3];
        
        if (clockwise)
        {
            // For B clockwise: Up top row -> Left left column -> Down bottom row -> Right right column -> Up
            // Save Up top row
            temp[0] = GetSticker(CubeFace.Up, 0);
            temp[1] = GetSticker(CubeFace.Up, 1);
            temp[2] = GetSticker(CubeFace.Up, 2);
            
            // Up top row <- Right right column
            SetSticker(CubeFace.Up, 0, GetSticker(CubeFace.Right, 2));
            SetSticker(CubeFace.Up, 1, GetSticker(CubeFace.Right, 5));
            SetSticker(CubeFace.Up, 2, GetSticker(CubeFace.Right, 8));
            
            // Right right column <- Down bottom row (reversed)
            SetSticker(CubeFace.Right, 2, GetSticker(CubeFace.Down, 8));
            SetSticker(CubeFace.Right, 5, GetSticker(CubeFace.Down, 7));
            SetSticker(CubeFace.Right, 8, GetSticker(CubeFace.Down, 6));
            
            // Down bottom row <- Left left column
            SetSticker(CubeFace.Down, 6, GetSticker(CubeFace.Left, 0));
            SetSticker(CubeFace.Down, 7, GetSticker(CubeFace.Left, 3));
            SetSticker(CubeFace.Down, 8, GetSticker(CubeFace.Left, 6));
            
            // Left left column <- Up top row (from temp, reversed)
            SetSticker(CubeFace.Left, 0, temp[2]);
            SetSticker(CubeFace.Left, 3, temp[1]);
            SetSticker(CubeFace.Left, 6, temp[0]);
        }
        else
        {
            // Counter-clockwise: Up top row -> Right right column -> Down bottom row -> Left left column -> Up
            // Save Up top row
            temp[0] = GetSticker(CubeFace.Up, 0);
            temp[1] = GetSticker(CubeFace.Up, 1);
            temp[2] = GetSticker(CubeFace.Up, 2);
            
            // Up top row <- Left left column (reversed)
            SetSticker(CubeFace.Up, 0, GetSticker(CubeFace.Left, 6));
            SetSticker(CubeFace.Up, 1, GetSticker(CubeFace.Left, 3));
            SetSticker(CubeFace.Up, 2, GetSticker(CubeFace.Left, 0));
            
            // Left left column <- Down bottom row
            SetSticker(CubeFace.Left, 0, GetSticker(CubeFace.Down, 6));
            SetSticker(CubeFace.Left, 3, GetSticker(CubeFace.Down, 7));
            SetSticker(CubeFace.Left, 6, GetSticker(CubeFace.Down, 8));
            
            // Down bottom row <- Right right column (reversed)
            SetSticker(CubeFace.Down, 6, GetSticker(CubeFace.Right, 8));
            SetSticker(CubeFace.Down, 7, GetSticker(CubeFace.Right, 5));
            SetSticker(CubeFace.Down, 8, GetSticker(CubeFace.Right, 2));
            
            // Right right column <- Up top row (from temp)
            SetSticker(CubeFace.Right, 2, temp[0]);
            SetSticker(CubeFace.Right, 5, temp[1]);
            SetSticker(CubeFace.Right, 8, temp[2]);
        }
    }

    public Cube Clone()
    {
        return new Cube(_faces, _orientation, _centerBasedOrientation);
    }

    public string ToJson()
    {
        var data = new
        {
            faces = new Dictionary<string, string[]>
            {
                ["front"] = GetFace(CubeFace.Front).Select(c => c.ToChar().ToString()).ToArray(),
                ["back"] = GetFace(CubeFace.Back).Select(c => c.ToChar().ToString()).ToArray(),
                ["right"] = GetFace(CubeFace.Right).Select(c => c.ToChar().ToString()).ToArray(),
                ["left"] = GetFace(CubeFace.Left).Select(c => c.ToChar().ToString()).ToArray(),
                ["up"] = GetFace(CubeFace.Up).Select(c => c.ToChar().ToString()).ToArray(),
                ["down"] = GetFace(CubeFace.Down).Select(c => c.ToChar().ToString()).ToArray()
            },
            orientation = _centerBasedOrientation.GetOrientationForJson()
        };
        
        return JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
    }

    public static Cube FromJson(string json)
    {
        var data = JsonSerializer.Deserialize<Dictionary<string, object>>(json);
        if (data == null || !data.ContainsKey("faces"))
            throw new ArgumentException("Invalid JSON format", nameof(json));
        
        var cube = new Cube();
        var facesElement = (JsonElement)data["faces"];
        
        // Load face data
        foreach (var face in Enum.GetValues<CubeFace>())
        {
            var faceName = face.ToString().ToLower();
            if (facesElement.TryGetProperty(faceName, out var faceData))
            {
                var colors = faceData.EnumerateArray()
                    .Select(e => CubeColorExtensions.FromChar(e.GetString()![0]))
                    .ToArray();
                cube.SetFace(face, colors);
            }
        }
        
        // Load orientation data (if present)
        if (data.ContainsKey("orientation"))
        {
            var orientationElement = (JsonElement)data["orientation"];
            var orientationColors = new Dictionary<string, string>();
            
            foreach (var property in orientationElement.EnumerateObject())
            {
                orientationColors[property.Name] = property.Value.GetString()!;
            }
            
            cube.SetOrientationFromColors(orientationColors);
            cube._centerBasedOrientation.SetOrientationFromColors(orientationColors);
        }
        // If no orientation data, cube will have default orientation (which is correct for backward compatibility)
        
        return cube;
    }
}