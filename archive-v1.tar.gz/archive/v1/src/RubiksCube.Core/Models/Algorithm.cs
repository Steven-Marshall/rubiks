using System.Text.Json;
using CSharpFunctionalExtensions;

namespace RubiksCube.Core.Models;

public class Algorithm
{
    public string Sequence { get; }
    public List<IMove> Operations { get; }
    public List<Move> Moves => Operations.OfType<MoveOperation>().Select(op => op.Move).ToList();
    public int MoveCount => Operations.Count;

    public Algorithm(string sequence)
    {
        if (string.IsNullOrWhiteSpace(sequence))
            throw new ArgumentException("Algorithm sequence cannot be null or empty", nameof(sequence));
        
        var normalizedSequence = RubiksCube.Core.Notation.NotationParser.FilterMetadata(sequence);
        Sequence = string.Join(" ", normalizedSequence.Split(new[] { ' ', '\t', '\n', '\r', ',' }, StringSplitOptions.RemoveEmptyEntries));
        Operations = ParseSequence(Sequence);
    }

    public Algorithm(List<Move> moves)
    {
        if (moves == null)
            throw new ArgumentNullException(nameof(moves));
        
        Operations = moves.Select(m => (IMove)new MoveOperation(m)).ToList();
        Sequence = string.Join(" ", Operations.Select(op => op.ToString()));
    }
    
    public Algorithm(List<IMove> operations)
    {
        if (operations == null)
            throw new ArgumentNullException(nameof(operations));
        
        Operations = new List<IMove>(operations);
        Sequence = string.Join(" ", Operations.Select(op => op.ToString()));
    }

    private static List<IMove> ParseSequence(string sequence)
    {
        // Use NotationParser with rotation support
        var result = RubiksCube.Core.Notation.NotationParser.ParseAlgorithmWithRotations(sequence);
        if (result.IsFailure)
            throw new ArgumentException(result.Error);
        return result.Value;
    }

    public Result ApplyTo(Cube cube)
    {
        foreach (var operation in Operations)
        {
            var result = operation.ApplyTo(cube);
            if (result.IsFailure)
                return Result.Failure($"Failed to apply operation {operation}: {result.Error}");
        }
        
        return Result.Success();
    }

    // Legacy method for backward compatibility
    public void ApplyToUnsafe(Cube cube)
    {
        var result = ApplyTo(cube);
        if (result.IsFailure)
            throw new InvalidOperationException(result.Error);
    }

    public Algorithm GetInverse()
    {
        var inverseOperations = Operations.Select(op => op.GetInverse()).Reverse().ToList();
        return new Algorithm(inverseOperations);
    }

    public Algorithm Concatenate(Algorithm other)
    {
        var combinedOperations = new List<IMove>(Operations);
        combinedOperations.AddRange(other.Operations);
        return new Algorithm(combinedOperations);
    }

    public static Result<Algorithm> Create(string sequence)
    {
        if (string.IsNullOrWhiteSpace(sequence))
            return Result.Failure<Algorithm>("Algorithm sequence cannot be null or empty");

        try
        {
            return Result.Success(new Algorithm(sequence));
        }
        catch (Exception ex)
        {
            return Result.Failure<Algorithm>(ex.Message);
        }
    }

    public static Algorithm Parse(string sequence)
    {
        return new Algorithm(sequence);
    }

    public override string ToString()
    {
        return Sequence;
    }

    public override bool Equals(object? obj)
    {
        return obj is Algorithm other && Sequence == other.Sequence;
    }

    public override int GetHashCode()
    {
        return Sequence.GetHashCode();
    }

    public string ToJson()
    {
        var data = new
        {
            sequence = Sequence,
            moveCount = MoveCount,
            moves = Moves.Select(m => m.ToString()).ToArray()
        };
        
        return JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
    }

    public static Algorithm FromJson(string json)
    {
        var data = JsonSerializer.Deserialize<Dictionary<string, object>>(json);
        if (data == null || !data.ContainsKey("sequence"))
            throw new ArgumentException("Invalid JSON format", nameof(json));
        
        var sequenceElement = (JsonElement)data["sequence"];
        return new Algorithm(sequenceElement.GetString()!);
    }

    /// <summary>
    /// Debug method to show what operations are in an algorithm.
    /// </summary>
    public string GetAlgorithmDebugInfo()
    {
        var operations = Operations.Select(op => $"{op.GetType().Name}: {op}").ToArray();
        return $"Algorithm '{Sequence}' contains {Operations.Count} operations: [{string.Join(", ", operations)}]";
    }
}