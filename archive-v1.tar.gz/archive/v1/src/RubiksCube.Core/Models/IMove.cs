using CSharpFunctionalExtensions;

namespace RubiksCube.Core.Models;

/// <summary>
/// Common interface for all cube operations (moves and rotations).
/// </summary>
public interface IMove
{
    /// <summary>
    /// Apply this operation to a cube.
    /// </summary>
    Result ApplyTo(Cube cube);
    
    /// <summary>
    /// Get the inverse of this operation.
    /// </summary>
    IMove GetInverse();
    
    /// <summary>
    /// Get the string representation of this operation.
    /// </summary>
    string ToString();
}

/// <summary>
/// Wrapper for Move to implement IMove.
/// </summary>
public record MoveOperation(Move Move) : IMove
{
    public Result ApplyTo(Cube cube)
    {
        return cube.ApplyMove(Move);
    }
    
    public IMove GetInverse()
    {
        return new MoveOperation(Move.GetInverse());
    }
    
    public override string ToString()
    {
        return Move.ToString();
    }
}

/// <summary>
/// Wrapper for Rotation to implement IMove.
/// </summary>
public record RotationOperation(Rotation Rotation) : IMove
{
    public Result ApplyTo(Cube cube)
    {
        return cube.ApplyRotation(Rotation);
    }
    
    public IMove GetInverse()
    {
        return new RotationOperation(Rotation.GetInverse());
    }
    
    public override string ToString()
    {
        return Rotation.ToString();
    }
}