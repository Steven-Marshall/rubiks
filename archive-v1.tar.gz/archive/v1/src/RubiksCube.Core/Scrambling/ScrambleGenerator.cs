using RubiksCube.Core.Models;
using CSharpFunctionalExtensions;

namespace RubiksCube.Core.Scrambling;

public class ScrambleGenerator
{
    private readonly Random _random;
    private readonly CubeFace[] _faces = { CubeFace.Up, CubeFace.Front, CubeFace.Right, CubeFace.Left, CubeFace.Down, CubeFace.Back };
    private readonly MoveType[] _moveTypes = { MoveType.Clockwise, MoveType.CounterClockwise, MoveType.Double };

    public ScrambleGenerator(int? seed = null)
    {
        _random = seed.HasValue ? new Random(seed.Value) : new Random();
    }

    public Result<Algorithm> GenerateScramble(int moveCount = 20, bool strictWcaRules = true)
    {
        if (moveCount <= 0)
            return Result.Failure<Algorithm>("Move count must be positive");

        if (moveCount > 100)
            return Result.Failure<Algorithm>("Move count cannot exceed 100 moves");

        var moves = new List<Move>();
        
        for (int i = 0; i < moveCount; i++)
        {
            var move = GenerateValidMove(moves, strictWcaRules);
            if (move == null)
            {
                // If we can't generate a valid move after reasonable attempts,
                // this is a domain failure (overly restrictive rules)
                return Result.Failure<Algorithm>($"Unable to generate valid move at position {i + 1}");
            }
            moves.Add(move);
        }

        var algorithmString = string.Join(" ", moves.Select(m => m.ToString()));
        return Algorithm.Create(algorithmString);
    }

    private Move? GenerateValidMove(List<Move> previousMoves, bool strictWcaRules)
    {
        const int maxAttempts = 50; // Prevent infinite loops
        
        for (int attempt = 0; attempt < maxAttempts; attempt++)
        {
            var face = _faces[_random.Next(_faces.Length)];
            var moveType = _moveTypes[_random.Next(_moveTypes.Length)];
            var candidateMove = new Move(face, moveType);

            if (IsValidMove(candidateMove, previousMoves, strictWcaRules))
            {
                return candidateMove;
            }
        }

        return null; // Unable to find valid move
    }

    private bool IsValidMove(Move candidateMove, List<Move> previousMoves, bool strictWcaRules)
    {
        if (previousMoves.Count == 0)
            return true;

        var lastMove = previousMoves[^1];

        // Rule 1: No consecutive same-face moves (always enforced)
        if (candidateMove.Face == lastMove.Face)
            return false;

        if (strictWcaRules && previousMoves.Count >= 2)
        {
            var secondLastMove = previousMoves[^2];
            
            // Rule 2: No opposite faces within 2 moves (WCA rule)
            if (AreOppositeFaces(candidateMove.Face, secondLastMove.Face))
                return false;
        }

        return true;
    }

    private static bool AreOppositeFaces(CubeFace face1, CubeFace face2)
    {
        return (face1, face2) switch
        {
            (CubeFace.Up, CubeFace.Down) or (CubeFace.Down, CubeFace.Up) => true,
            (CubeFace.Front, CubeFace.Back) or (CubeFace.Back, CubeFace.Front) => true,
            (CubeFace.Right, CubeFace.Left) or (CubeFace.Left, CubeFace.Right) => true,
            _ => false
        };
    }
}