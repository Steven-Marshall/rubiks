using RubiksCube.Core.Models;
using RubiksCube.Core.Configuration;
using RubiksCube.Core.Display;

Console.WriteLine("=== Compare Memory vs JSON-loaded cubes ===");

// Create cube in memory
var memoryCube = new Cube();
Console.WriteLine("Memory cube - Left face [0]: " + memoryCube.GetFaceFromCurrentOrientation(CubeFace.Left)[0]);
Console.WriteLine("Memory cube - Right face [0]: " + memoryCube.GetFaceFromCurrentOrientation(CubeFace.Right)[0]);

// Serialize to JSON then reload
var json = memoryCube.ToJson();
var jsonCube = Cube.FromJson(json);
Console.WriteLine("JSON cube - Left face [0]: " + jsonCube.GetFaceFromCurrentOrientation(CubeFace.Left)[0]);
Console.WriteLine("JSON cube - Right face [0]: " + jsonCube.GetFaceFromCurrentOrientation(CubeFace.Right)[0]);

// Test if they render the same
var config = new DisplayConfig();
var memoryDisplay = new CubeRenderer(config).Render(memoryCube);
var jsonDisplay = new CubeRenderer(config).Render(jsonCube);

Console.WriteLine("\nMemory cube rendering:");
Console.WriteLine(memoryDisplay.Value);
Console.WriteLine("\nJSON cube rendering:");
Console.WriteLine(jsonDisplay.Value);

Console.WriteLine("\nThey render the same: " + (memoryDisplay.Value == jsonDisplay.Value));