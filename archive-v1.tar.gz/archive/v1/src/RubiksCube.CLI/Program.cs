using RubiksCube.Core.Models;
using RubiksCube.Core.Display;
using RubiksCube.Core.Configuration;
using RubiksCube.Core.Notation;
using RubiksCube.Core.Storage;
using RubiksCube.Core.Scrambling;
using RubiksCube.Core.PatternRecognition;
using CSharpFunctionalExtensions;
using CoreAlgorithm = RubiksCube.Core.Models.Algorithm;

namespace RubiksCube.CLI;

class Program
{
    static async Task<int> Main(string[] args)
    {
        try
        {
            if (args.Length == 0)
            {
                ShowHelp();
                return 0;
            }

            string command = args[0].ToLowerInvariant();
            
            return command switch
            {
                "create" => await HandleCreate(args),
                "apply" => await HandleApply(args),
                "display" => await HandleDisplay(args),
                "debug-orientation" => await HandleDebugOrientation(args),
                "debug-algorithm" => HandleDebugAlgorithm(args),
                "list" => HandleList(),
                "delete" => HandleDelete(args),
                "export" => HandleExport(args),
                "scramble-gen" => HandleScrambleGen(args),
                "analyze" => await HandleAnalyze(args),
                "solve" => await HandleSolve(args),
                "help" or "--help" or "-h" => HandleHelp(),
                _ => HandleUnknownCommand(command)
            };
        }
        catch (Exception ex)
        {
            await Console.Error.WriteLineAsync($"Unexpected error: {ex.Message}");
            return 1;
        }
    }

    private static async Task<int> HandleCreate(string[] args)
    {
        try
        {
            var cube = new Cube();
            
            // Check if cube name provided
            if (args.Length > 1)
            {
                string cubeName = args[1];
                var saveResult = CubeStorageService.Save(cube, cubeName);
                if (saveResult.IsFailure)
                {
                    await Console.Error.WriteLineAsync($"Error saving cube: {saveResult.Error}");
                    return 1;
                }
                // For named saves, don't output JSON to stdout
                return 0;
            }
            
            // No cube name - output JSON to stdout (original behavior)
            var json = cube.ToJson();
            Console.WriteLine(json);
            return 0;
        }
        catch (Exception ex)
        {
            await Console.Error.WriteLineAsync($"Error creating cube: {ex.Message}");
            return 1;
        }
    }

    private static async Task<int> HandleApply(string[] args)
    {
        if (args.Length < 2)
        {
            await Console.Error.WriteLineAsync("Error: Algorithm required for 'apply' command");
            await Console.Error.WriteLineAsync("Usage: rubiks apply \"R U R' U'\" [cube-name]");
            return 1;
        }

        try
        {
            string algorithmString = args[1];
            
            // Check if cube name provided (apply to named cube)
            if (args.Length > 2)
            {
                string cubeName = args[2];
                
                // Load cube
                var loadResult = CubeStorageService.Load(cubeName);
                if (loadResult.IsFailure)
                {
                    await Console.Error.WriteLineAsync($"Error loading cube: {loadResult.Error}");
                    return 1;
                }
                
                var cube = loadResult.Value;
                
                // Apply algorithm
                var algorithmResult = CoreAlgorithm.Create(algorithmString);
                if (algorithmResult.IsFailure)
                {
                    await Console.Error.WriteLineAsync($"Error parsing algorithm: {algorithmResult.Error}");
                    return 1;
                }

                var applyResult = algorithmResult.Value.ApplyTo(cube);
                if (applyResult.IsFailure)
                {
                    await Console.Error.WriteLineAsync($"Error applying algorithm: {applyResult.Error}");
                    return 1;
                }

                // Save modified cube back
                var saveResult = CubeStorageService.Save(cube, cubeName);
                if (saveResult.IsFailure)
                {
                    await Console.Error.WriteLineAsync($"Error saving cube: {saveResult.Error}");
                    return 1;
                }
                
                return 0;
            }
            
            // No cube name - use stdin/stdout (original behavior)
            var cubeJson = await Console.In.ReadToEndAsync();
            if (string.IsNullOrWhiteSpace(cubeJson))
            {
                await Console.Error.WriteLineAsync("Error: No cube data provided via stdin");
                return 1;
            }

            var stdinCube = Cube.FromJson(cubeJson.Trim());
            var stdinAlgorithmResult = CoreAlgorithm.Create(algorithmString);
            if (stdinAlgorithmResult.IsFailure)
            {
                await Console.Error.WriteLineAsync($"Error parsing algorithm: {stdinAlgorithmResult.Error}");
                return 1;
            }

            var stdinApplyResult = stdinAlgorithmResult.Value.ApplyTo(stdinCube);
            if (stdinApplyResult.IsFailure)
            {
                await Console.Error.WriteLineAsync($"Error applying algorithm: {stdinApplyResult.Error}");
                return 1;
            }

            Console.WriteLine(stdinCube.ToJson());
            return 0;
        }
        catch (Exception ex)
        {
            await Console.Error.WriteLineAsync($"Error applying algorithm: {ex.Message}");
            return 1;
        }
    }

    private static async Task<int> HandleDisplay(string[] args)
    {
        try
        {
            string format = "unicode";
            string? cubeName = null;
            bool useCenterBasedRenderer = false;
            
            // Parse arguments
            for (int i = 1; i < args.Length; i++)
            {
                if (args[i] == "--format" || args[i] == "-f")
                {
                    if (i + 1 < args.Length)
                    {
                        format = args[i + 1];
                        i++; // Skip the format value
                    }
                    else
                    {
                        await Console.Error.WriteLineAsync("Error: --format requires a value (ascii or unicode)");
                        return 1;
                    }
                }
                else if (args[i].StartsWith("--format="))
                {
                    format = args[i].Substring("--format=".Length);
                }
                else if (args[i] == "--renderer")
                {
                    if (i + 1 < args.Length)
                    {
                        var rendererType = args[i + 1];
                        if (rendererType == "center-based")
                        {
                            useCenterBasedRenderer = true;
                        }
                        else if (rendererType != "default")
                        {
                            await Console.Error.WriteLineAsync("Error: --renderer must be 'default' or 'center-based'");
                            return 1;
                        }
                        i++; // Skip the renderer value
                    }
                    else
                    {
                        await Console.Error.WriteLineAsync("Error: --renderer requires a value (default or center-based)");
                        return 1;
                    }
                }
                else if (args[i].StartsWith("--renderer="))
                {
                    var rendererType = args[i].Substring("--renderer=".Length);
                    if (rendererType == "center-based")
                    {
                        useCenterBasedRenderer = true;
                    }
                    else if (rendererType != "default")
                    {
                        await Console.Error.WriteLineAsync("Error: --renderer must be 'default' or 'center-based'");
                        return 1;
                    }
                }
                else if (!args[i].StartsWith("-"))
                {
                    // Assume it's a cube name
                    cubeName = args[i];
                }
            }

            Cube cube;
            
            // Load cube from name or stdin
            if (cubeName != null)
            {
                var loadResult = CubeStorageService.Load(cubeName);
                if (loadResult.IsFailure)
                {
                    await Console.Error.WriteLineAsync($"Error loading cube: {loadResult.Error}");
                    return 1;
                }
                cube = loadResult.Value;
            }
            else
            {
                // Read from stdin (original behavior)
                var cubeJson = await Console.In.ReadToEndAsync();
                if (string.IsNullOrWhiteSpace(cubeJson))
                {
                    await Console.Error.WriteLineAsync("Error: No cube data provided via stdin");
                    return 1;
                }
                cube = Cube.FromJson(cubeJson.Trim());
            }

            // Display cube
            var displayFormat = format.ToLowerInvariant() switch
            {
                "ascii" => DisplayFormat.ASCII,
                "unicode" => DisplayFormat.Unicode,
                _ => DisplayFormat.Unicode
            };

            var config = new DisplayConfig { Format = displayFormat };
            var displayResult = DisplayService.DisplayCubeWithConfig(cube, config, useCenterBasedRenderer);

            if (displayResult.IsFailure)
            {
                await Console.Error.WriteLineAsync($"Error displaying cube: {displayResult.Error}");
                return 1;
            }

            Console.WriteLine(displayResult.Value);
            return 0;
        }
        catch (Exception ex)
        {
            await Console.Error.WriteLineAsync($"Error displaying cube: {ex.Message}");
            return 1;
        }
    }

    private static async Task<int> HandleDebugOrientation(string[] args)
    {
        try
        {
            string? cubeName = args.Length > 1 ? args[1] : null;
            Cube cube;

            if (cubeName != null)
            {
                // Load named cube
                var loadResult = CubeStorageService.Load(cubeName);
                if (loadResult.IsFailure)
                {
                    await Console.Error.WriteLineAsync($"Error loading cube '{cubeName}': {loadResult.Error}");
                    return 1;
                }
                cube = loadResult.Value;
            }
            else
            {
                // Read from stdin
                string json = await Console.In.ReadToEndAsync();
                if (string.IsNullOrWhiteSpace(json))
                {
                    await Console.Error.WriteLineAsync("Error: No cube data provided via stdin");
                    return 1;
                }

                cube = Cube.FromJson(json);
            }

            // Output orientation debug info
            Console.WriteLine(cube.GetOrientationDebugInfo());
            return 0;
        }
        catch (Exception ex)
        {
            await Console.Error.WriteLineAsync($"Error debugging orientation: {ex.Message}");
            return 1;
        }
    }

    private static int HandleDebugAlgorithm(string[] args)
    {
        try
        {
            if (args.Length < 2)
            {
                Console.Error.WriteLine("Usage: debug-algorithm \"algorithm sequence\"");
                return 1;
            }

            string algorithmSequence = args[1];
            var algorithm = new CoreAlgorithm(algorithmSequence);
            
            Console.WriteLine(algorithm.GetAlgorithmDebugInfo());
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"Error debugging algorithm: {ex.Message}");
            return 1;
        }
    }

    private static int HandleList()
    {
        try
        {
            var cubes = CubeStorageService.List();
            if (!cubes.Any())
            {
                Console.WriteLine("No saved cubes found.");
                return 0;
            }

            Console.WriteLine("Saved cubes:");
            foreach (var cubeName in cubes)
            {
                Console.WriteLine($"  {cubeName}");
            }
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"Error listing cubes: {ex.Message}");
            return 1;
        }
    }

    private static int HandleDelete(string[] args)
    {
        if (args.Length < 2)
        {
            Console.Error.WriteLine("Error: Cube name required for 'delete' command");
            Console.Error.WriteLine("Usage: rubiks delete cube-name");
            return 1;
        }

        try
        {
            string cubeName = args[1];
            var result = CubeStorageService.Delete(cubeName);
            if (result.IsFailure)
            {
                Console.Error.WriteLine($"Error deleting cube: {result.Error}");
                return 1;
            }

            Console.WriteLine($"Cube '{cubeName}' deleted successfully.");
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"Error deleting cube: {ex.Message}");
            return 1;
        }
    }

    private static int HandleExport(string[] args)
    {
        if (args.Length < 2)
        {
            Console.Error.WriteLine("Error: Cube name required for 'export' command");
            Console.Error.WriteLine("Usage: rubiks export cube-name");
            return 1;
        }

        try
        {
            string cubeName = args[1];
            var result = CubeStorageService.Export(cubeName);
            if (result.IsFailure)
            {
                Console.Error.WriteLine($"Error exporting cube: {result.Error}");
                return 1;
            }

            Console.WriteLine(result.Value);
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"Error exporting cube: {ex.Message}");
            return 1;
        }
    }

    private static int HandleScrambleGen(string[] args)
    {
        try
        {
            int moveCount = 20; // WCA default
            int? seed = null;
            bool strictWcaRules = true;

            // Parse arguments
            for (int i = 1; i < args.Length; i++)
            {
                if (args[i] == "--moves" && i + 1 < args.Length)
                {
                    if (!int.TryParse(args[i + 1], out moveCount) || moveCount <= 0)
                    {
                        Console.Error.WriteLine("Error: --moves requires a positive integer");
                        return 1;
                    }
                    i++; // Skip the value
                }
                else if (args[i].StartsWith("--moves="))
                {
                    var movesValue = args[i].Substring("--moves=".Length);
                    if (!int.TryParse(movesValue, out moveCount) || moveCount <= 0)
                    {
                        Console.Error.WriteLine("Error: --moves requires a positive integer");
                        return 1;
                    }
                }
                else if (args[i] == "--seed" && i + 1 < args.Length)
                {
                    if (!int.TryParse(args[i + 1], out int seedValue))
                    {
                        Console.Error.WriteLine("Error: --seed requires an integer");
                        return 1;
                    }
                    seed = seedValue;
                    i++; // Skip the value
                }
                else if (args[i].StartsWith("--seed="))
                {
                    var seedValue = args[i].Substring("--seed=".Length);
                    if (!int.TryParse(seedValue, out int parsedSeed))
                    {
                        Console.Error.WriteLine("Error: --seed requires an integer");
                        return 1;
                    }
                    seed = parsedSeed;
                }
                else if (args[i] == "--relaxed")
                {
                    strictWcaRules = false;
                }
                else
                {
                    Console.Error.WriteLine($"Error: Unknown argument '{args[i]}'");
                    Console.Error.WriteLine("Usage: rubiks scramble-gen [--moves=N] [--seed=N] [--relaxed]");
                    return 1;
                }
            }

            var scrambleGenerator = new ScrambleGenerator(seed);
            var scrambleResult = scrambleGenerator.GenerateScramble(moveCount, strictWcaRules);

            if (scrambleResult.IsFailure)
            {
                Console.Error.WriteLine($"Error generating scramble: {scrambleResult.Error}");
                return 1;
            }

            Console.WriteLine(scrambleResult.Value.ToString());
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"Error generating scramble: {ex.Message}");
            return 1;
        }
    }

    private static async Task<int> HandleAnalyze(string[] args)
    {
        try
        {
            string? cubeName = null;
            bool detailed = false;
            
            // Parse arguments
            for (int i = 1; i < args.Length; i++)
            {
                if (args[i] == "--detailed" || args[i] == "-d")
                {
                    detailed = true;
                }
                else if (!args[i].StartsWith("-"))
                {
                    cubeName = args[i];
                }
            }

            Cube cube;
            
            // Load cube from name or stdin
            if (cubeName != null)
            {
                var loadResult = CubeStorageService.Load(cubeName);
                if (loadResult.IsFailure)
                {
                    await Console.Error.WriteLineAsync($"Error loading cube: {loadResult.Error}");
                    return 1;
                }
                cube = loadResult.Value;
            }
            else
            {
                // Read from stdin
                var cubeJson = await Console.In.ReadToEndAsync();
                if (string.IsNullOrWhiteSpace(cubeJson))
                {
                    await Console.Error.WriteLineAsync("Error: No cube data provided via stdin");
                    return 1;
                }
                cube = Cube.FromJson(cubeJson.Trim());
            }

            // Analyze cube state
            var analyzer = new SimpleCfopStateAnalyzer();
            var state = analyzer.AnalyzeState(cube);
            
            if (detailed)
            {
                // Provide detailed analysis
                if (state == CfopState.Cross)
                {
                    var crossAnalyzer = new CrossAnalyzer();
                    var crossResult = crossAnalyzer.AnalyzeCross(cube);
                    Console.WriteLine($"CFOP State: {state}");
                    Console.WriteLine($"Cross completed: {crossResult.CompletedEdges}/4 edges");
                    Console.WriteLine($"Details: {crossResult.Description}");
                }
                else
                {
                    Console.WriteLine($"CFOP State: {state}");
                    var progress = analyzer.GetProgress(cube);
                    Console.WriteLine($"Cross: {(progress.IsStepComplete(CfopStep.Cross) ? "Complete" : "Incomplete")}");
                    Console.WriteLine($"F2L: {(progress.IsStepComplete(CfopStep.F2L) ? "Complete" : "Incomplete")}");
                    Console.WriteLine($"OLL: {(progress.IsStepComplete(CfopStep.OLL) ? "Complete" : "Incomplete")}");
                    Console.WriteLine($"PLL: {(progress.IsStepComplete(CfopStep.PLL) ? "Complete" : "Incomplete")}");
                }
            }
            else
            {
                // Simple state output
                Console.WriteLine(state.ToString());
            }
            
            return 0;
        }
        catch (Exception ex)
        {
            await Console.Error.WriteLineAsync($"Error analyzing cube: {ex.Message}");
            return 1;
        }
    }

    private static async Task<int> HandleSolve(string[] args)
    {
        if (args.Length < 2)
        {
            await Console.Error.WriteLineAsync("Error: Solve step required");
            await Console.Error.WriteLineAsync("Usage: rubiks solve {cross|f2l|oll|pll|cfop} [cube-name] [--level=efficient] [--cn=white]");
            return 1;
        }

        try
        {
            string step = args[1].ToLowerInvariant();
            string? cubeName = null;
            SolvingLevel level = SolvingLevel.Efficient;
            string colorNeutral = "white";
            
            // Parse arguments
            for (int i = 2; i < args.Length; i++)
            {
                if (args[i].StartsWith("--level="))
                {
                    var levelString = args[i].Substring("--level=".Length);
                    if (!Enum.TryParse<SolvingLevel>(levelString, true, out level))
                    {
                        await Console.Error.WriteLineAsync($"Error: Invalid level '{levelString}'. Valid: beginner, efficient, optimal");
                        return 1;
                    }
                }
                else if (args[i].StartsWith("--cn="))
                {
                    colorNeutral = args[i].Substring("--cn=".Length);
                }
                else if (!args[i].StartsWith("-"))
                {
                    cubeName = args[i];
                }
            }

            Cube cube;
            
            // Load cube from name or stdin
            if (cubeName != null)
            {
                var loadResult = CubeStorageService.Load(cubeName);
                if (loadResult.IsFailure)
                {
                    await Console.Error.WriteLineAsync($"Error loading cube: {loadResult.Error}");
                    return 1;
                }
                cube = loadResult.Value;
            }
            else
            {
                // Read from stdin
                var cubeJson = await Console.In.ReadToEndAsync();
                if (string.IsNullOrWhiteSpace(cubeJson))
                {
                    await Console.Error.WriteLineAsync("Error: No cube data provided via stdin");
                    return 1;
                }
                cube = Cube.FromJson(cubeJson.Trim());
            }

            // Solve based on step
            Result<CoreAlgorithm> solveResult = step switch
            {
                "cross" => SolveCross(cube, level),
                "f2l" => Result.Failure<CoreAlgorithm>("F2L solver not yet implemented"),
                "oll" => Result.Failure<CoreAlgorithm>("OLL solver not yet implemented"),
                "pll" => Result.Failure<CoreAlgorithm>("PLL solver not yet implemented"),
                "cfop" => Result.Failure<CoreAlgorithm>("Full CFOP solver not yet implemented"),
                _ => Result.Failure<CoreAlgorithm>($"Unknown solve step: {step}")
            };

            if (solveResult.IsFailure)
            {
                await Console.Error.WriteLineAsync($"Error solving {step}: {solveResult.Error}");
                return 1;
            }

            // Output solution algorithm
            Console.WriteLine(solveResult.Value.ToString());
            return 0;
        }
        catch (Exception ex)
        {
            await Console.Error.WriteLineAsync($"Error solving cube: {ex.Message}");
            return 1;
        }
    }

    private static Result<CoreAlgorithm> SolveCross(Cube cube, SolvingLevel level)
    {
        var solver = new CrossSolver();
        var result = solver.Solve(cube, level);
        
        // Convert from PatternRecognition.Algorithm to Models.Algorithm
        if (result.IsFailure)
            return Result.Failure<CoreAlgorithm>(result.Error);
            
        var patternAlgorithm = result.Value;
        if (patternAlgorithm.IsEmpty)
        {
            // Create empty algorithm with no moves
            var emptyAlgorithm = new CoreAlgorithm(new List<Move>());
            return Result.Success(emptyAlgorithm);
        }
            
        // Convert the moves to a Models.Algorithm
        var algorithmString = patternAlgorithm.ToString();
        var coreAlgorithmResult = CoreAlgorithm.Create(algorithmString);
        
        return coreAlgorithmResult.IsSuccess 
            ? Result.Success(coreAlgorithmResult.Value)
            : Result.Failure<CoreAlgorithm>($"Failed to convert algorithm: {coreAlgorithmResult.Error}");
    }

    private static int HandleHelp()
    {
        ShowHelp();
        return 0;
    }

    private static int HandleUnknownCommand(string command)
    {
        Console.Error.WriteLine($"Unknown command: {command}");
        ShowHelp();
        return 1;
    }

    private static void ShowHelp()
    {
        Console.WriteLine("RubiksCube - A CLI tool for 3x3x3 Rubik's cube operations");
        Console.WriteLine();
        Console.WriteLine("Usage:");
        Console.WriteLine("  rubiks create [cube-name]                     Generate a solved cube state");
        Console.WriteLine("  rubiks apply \"R U R' U'\" [cube-name]          Apply an algorithm to a cube");
        Console.WriteLine("  rubiks display [cube-name] [--format=fmt]     Display a cube in visual format");
        Console.WriteLine("  rubiks scramble-gen [options]                 Generate a WCA-compliant scramble");
        Console.WriteLine("  rubiks analyze [cube-name] [--detailed]       Analyze CFOP state and progress");
        Console.WriteLine("  rubiks solve {step} [cube-name] [options]     Generate solution algorithm");
        Console.WriteLine("  rubiks list                                   List all saved cubes");
        Console.WriteLine("  rubiks delete cube-name                       Delete a saved cube");
        Console.WriteLine("  rubiks export cube-name                       Export cube JSON to stdout");
        Console.WriteLine("  rubiks help                                   Show this help message");
        Console.WriteLine();
        Console.WriteLine("Examples:");
        Console.WriteLine("  # Named cube operations");
        Console.WriteLine("  rubiks create scramble1");
        Console.WriteLine("  rubiks apply \"R U R' U'\" scramble1");
        Console.WriteLine("  rubiks display scramble1");
        Console.WriteLine("  rubiks list");
        Console.WriteLine("  rubiks export scramble1 | rubiks display");
        Console.WriteLine();
        Console.WriteLine("  # Traditional piping (still works)");
        Console.WriteLine("  rubiks create | rubiks apply \"R U R' U'\" | rubiks display");
        Console.WriteLine("  rubiks create | rubiks display --format=ascii");
        Console.WriteLine();
        Console.WriteLine("  # Scramble generation and application");
        Console.WriteLine("  rubiks create | rubiks apply \"$(rubiks scramble-gen)\" | rubiks display");
        Console.WriteLine("  rubiks scramble-gen --moves=25 --seed=12345");
        Console.WriteLine("  rubiks scramble-gen --relaxed");
        Console.WriteLine();
        Console.WriteLine("  # Pattern recognition and solving");
        Console.WriteLine("  rubiks analyze scramble1");
        Console.WriteLine("  rubiks analyze scramble1 --detailed");
        Console.WriteLine("  rubiks solve cross scramble1");
        Console.WriteLine("  rubiks solve cross --level=optimal | rubiks apply - scramble1");
        Console.WriteLine();
        Console.WriteLine("Options:");
        Console.WriteLine("  --format, -f    Display format: ascii or unicode (default: unicode)");
        Console.WriteLine("  --moves=N       Scramble length in moves (default: 20)");
        Console.WriteLine("  --seed=N        Random seed for reproducible scrambles");
        Console.WriteLine("  --relaxed       Use relaxed rules (default: strict WCA rules)");
        Console.WriteLine("  --detailed, -d  Detailed analysis output");
        Console.WriteLine("  --level=L       Solving level: beginner, efficient, optimal (default: efficient)");
        Console.WriteLine("  --cn=C          Color neutrality: white, dual, full (default: white)");
        Console.WriteLine("  --help, -h      Show help information");
        Console.WriteLine();
        Console.WriteLine("Solve Steps:");
        Console.WriteLine("  cross           Solve white cross (or color-neutral cross)");
        Console.WriteLine("  f2l             Solve First Two Layers (planned)");
        Console.WriteLine("  oll             Orient Last Layer (planned)");
        Console.WriteLine("  pll             Permute Last Layer (planned)");
        Console.WriteLine("  cfop            Complete CFOP solve (planned)");
        Console.WriteLine();
        Console.WriteLine("Storage:");
        Console.WriteLine("  Cubes are saved as .cube files in the current directory");
    }
}