using RubiksCube.Core.Models;
using RubiksCube.Core.Display;
using RubiksCube.Core.Configuration;

namespace RubiksCube.Tests.Display;

public class CubeRendererTests
{
    private readonly DisplayConfig _unicodeConfig = new()
    {
        Format = DisplayFormat.Unicode,
        Squares = new UnicodeSquares()
    };

    private readonly DisplayConfig _asciiConfig = new()
    {
        Format = DisplayFormat.ASCII,
        Letters = new AsciiLetters()
    };

    [Fact]
    public void Render_UnicodeFormat_ShouldReturnUnicodeDisplay()
    {
        var cube = new Cube();
        var renderer = new CubeRenderer(_unicodeConfig);
        
        var result = renderer.Render(cube);
        
        Assert.True(result.IsSuccess);
        
        var display = result.Value;
        Assert.Contains("🔳", display); // White (bottom face)
        Assert.Contains("🟨", display); // Yellow (top face)
        Assert.Contains("🟩", display); // Green (front face)
        Assert.Contains("🟧", display); // Orange (left face)
        Assert.Contains("🟥", display); // Red (right face)
        Assert.Contains("🟦", display); // Blue (back face)
    }

    [Fact]
    public void Render_AsciiFormat_ShouldReturnAsciiDisplay()
    {
        var cube = new Cube();
        var renderer = new CubeRenderer(_asciiConfig);
        
        var result = renderer.Render(cube);
        
        Assert.True(result.IsSuccess);
        
        var display = result.Value;
        Assert.Contains("W", display); // White
        Assert.Contains("Y", display); // Yellow
        Assert.Contains("G", display); // Green
        Assert.Contains("O", display); // Orange
        Assert.Contains("R", display); // Red
        Assert.Contains("B", display); // Blue
    }

    [Fact]
    public void Render_WithNullCube_ShouldReturnFailure()
    {
        var renderer = new CubeRenderer(_unicodeConfig);
        
        var result = renderer.Render(null!);
        
        Assert.True(result.IsFailure);
        Assert.Contains("cannot be null", result.Error);
    }

    [Fact]
    public void Render_UnicodeDisplay_ShouldHaveCorrectLayout()
    {
        var cube = new Cube();
        var renderer = new CubeRenderer(_unicodeConfig);
        
        var result = renderer.Render(cube);
        var lines = result.Value.Split('\n', StringSplitOptions.RemoveEmptyEntries);
        
        // Should have 9 lines (3 for top, 3 for middle, 3 for bottom)
        Assert.Equal(9, lines.Length);
        
        // Top face lines should start with 4 spaces for Unicode
        for (int i = 0; i < 3; i++)
        {
            Assert.StartsWith("    ", lines[i]);
        }
        
        // Bottom face lines should start with 4 spaces for Unicode
        for (int i = 6; i < 9; i++)
        {
            Assert.StartsWith("    ", lines[i]);
        }
        
        // Middle lines should not start with spaces (left face starts immediately)
        for (int i = 3; i < 6; i++)
        {
            Assert.False(lines[i].StartsWith(" "));
        }
    }

    [Fact]
    public void Render_AsciiDisplay_ShouldHaveSpacesBetweenLetters()
    {
        var cube = new Cube();
        var renderer = new CubeRenderer(_asciiConfig);
        
        var result = renderer.Render(cube);
        var lines = result.Value.Split('\n', StringSplitOptions.RemoveEmptyEntries);
        
        // Check that ASCII format has spaces between letters
        // Top face should be like "Y Y Y"
        Assert.Contains(" ", lines[0]);
        
        // Middle row should have double spaces between faces
        Assert.Contains("  ", lines[3]);
    }

    [Fact]
    public void Render_ScrambledCube_ShouldShowMixedColors()
    {
        var cube = new Cube();
        
        // Apply some moves to scramble
        cube.ApplyMoveUnsafe(new Move(CubeFace.Right, MoveType.Clockwise));
        cube.ApplyMoveUnsafe(new Move(CubeFace.Right, MoveType.Clockwise));
        
        var renderer = new CubeRenderer(_unicodeConfig);
        var result = renderer.Render(cube);
        
        Assert.True(result.IsSuccess);
        // After R2, the cube should have mixed colors (no longer solved)
        Assert.False(cube.IsSolved());
    }

    [Theory]
    [InlineData(DisplayFormat.Unicode)]
    [InlineData(DisplayFormat.ASCII)]
    public void Render_SolvedCube_ShouldShowAllSixColors(DisplayFormat format)
    {
        var cube = new Cube();
        var config = format == DisplayFormat.Unicode ? _unicodeConfig : _asciiConfig;
        var renderer = new CubeRenderer(config);
        
        var result = renderer.Render(cube);
        var display = result.Value;
        
        if (format == DisplayFormat.Unicode)
        {
            Assert.Contains("🔳", display); // White
            Assert.Contains("🟨", display); // Yellow  
            Assert.Contains("🟩", display); // Green
            Assert.Contains("🟧", display); // Orange
            Assert.Contains("🟥", display); // Red
            Assert.Contains("🟦", display); // Blue
        }
        else
        {
            Assert.Contains("W", display); // White
            Assert.Contains("Y", display); // Yellow
            Assert.Contains("G", display); // Green
            Assert.Contains("O", display); // Orange
            Assert.Contains("R", display); // Red
            Assert.Contains("B", display); // Blue
        }
    }

    [Fact]
    public void Constructor_WithNullConfig_ShouldThrowException()
    {
        Assert.Throws<ArgumentNullException>(() => new CubeRenderer(null!));
    }
}