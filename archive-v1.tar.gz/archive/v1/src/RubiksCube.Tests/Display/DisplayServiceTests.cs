using RubiksCube.Core.Models;
using RubiksCube.Core.Display;
using RubiksCube.Core.Configuration;

namespace RubiksCube.Tests.Display;

public class DisplayServiceTests
{
    [Fact]
    public void DisplayCube_WithValidCube_ShouldReturnSuccess()
    {
        var cube = new Cube();
        
        var result = DisplayService.DisplayCube(cube);
        
        Assert.True(result.IsSuccess);
        Assert.NotEmpty(result.Value);
    }

    [Fact]
    public void DisplayCube_WithNullCube_ShouldReturnFailure()
    {
        var result = DisplayService.DisplayCube(null!);
        
        Assert.True(result.IsFailure);
        Assert.Contains("cannot be null", result.Error);
    }

    [Fact]
    public void DisplayCubeWithConfig_UnicodeFormat_ShouldContainUnicodeSquares()
    {
        var cube = new Cube();
        var config = new DisplayConfig
        {
            Format = DisplayFormat.Unicode,
            Squares = new UnicodeSquares()
        };
        
        var result = DisplayService.DisplayCubeWithConfig(cube, config);
        
        Assert.True(result.IsSuccess);
        Assert.Contains("🔳", result.Value); // White squares
        Assert.Contains("🟩", result.Value); // Green squares (front face)
    }

    [Fact]
    public void DisplayCubeWithConfig_AsciiFormat_ShouldContainLetters()
    {
        var cube = new Cube();
        var config = new DisplayConfig
        {
            Format = DisplayFormat.ASCII,
            Letters = new AsciiLetters()
        };
        
        var result = DisplayService.DisplayCubeWithConfig(cube, config);
        
        Assert.True(result.IsSuccess);
        Assert.Contains("W", result.Value); // White letters
        Assert.Contains("G", result.Value); // Green letters (front face)
    }

    [Fact]
    public void DisplayCubeWithConfig_CustomUnicodeSquares_ShouldUseCustomSymbols()
    {
        var cube = new Cube();
        var config = new DisplayConfig
        {
            Format = DisplayFormat.Unicode,
            Squares = new UnicodeSquares
            {
                White = "⬜",  // Different white square
                Green = "🟢"  // Different green square
            }
        };
        
        var result = DisplayService.DisplayCubeWithConfig(cube, config);
        
        Assert.True(result.IsSuccess);
        Assert.Contains("⬜", result.Value); // Custom white
        Assert.Contains("🟢", result.Value); // Custom green
    }

    [Fact]
    public void DisplayCubeJson_WithValidJson_ShouldReturnSuccess()
    {
        var cube = new Cube();
        var json = cube.ToJson();
        
        var result = DisplayService.DisplayCubeJson(json);
        
        Assert.True(result.IsSuccess);
        Assert.NotEmpty(result.Value);
    }

    [Fact]
    public void DisplayCubeJson_WithInvalidJson_ShouldReturnFailure()
    {
        var result = DisplayService.DisplayCubeJson("invalid json");
        
        Assert.True(result.IsFailure);
        Assert.Contains("Invalid cube JSON", result.Error);
    }

    [Fact]
    public void DisplayCubeJson_WithEmptyString_ShouldReturnFailure()
    {
        var result = DisplayService.DisplayCubeJson("");
        
        Assert.True(result.IsFailure);
        Assert.Contains("cannot be empty", result.Error);
    }

    [Fact]
    public void GetDefaultConfig_ShouldReturnValidConfig()
    {
        var result = DisplayService.GetDefaultConfig();
        
        Assert.True(result.IsSuccess);
        Assert.Equal(DisplayFormat.Unicode, result.Value.Format);
        Assert.Equal("🔳", result.Value.Squares.White);
        Assert.Equal("🟥", result.Value.Squares.Red);
    }

    [Fact]
    public void GetConfigInfo_ShouldReturnConfigurationDetails()
    {
        var result = DisplayService.GetConfigInfo();
        
        Assert.True(result.IsSuccess);
        Assert.Contains("Configuration:", result.Value);
        Assert.Contains("Format:", result.Value);
        Assert.Contains("Unicode Squares:", result.Value);
    }
}