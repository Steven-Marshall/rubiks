using RubiksCube.Core.Models;
using Xunit;
using Xunit.Abstractions;

namespace RubiksCube.Tests.TestHelpers;

/// <summary>
/// Tests to verify our test infrastructure is working correctly
/// </summary>
public class TestInfrastructureTests
{
    private readonly ITestOutputHelper _output;

    public TestInfrastructureTests(ITestOutputHelper output)
    {
        _output = output;
    }

    [Fact]
    public void TestHelpers_CreateSolvedCube_ShouldHaveCorrectColors()
    {
        // Arrange & Act
        var cube = TestHelpers.CreateSolvedCube();
        
        // Assert
        Assert.Equal(TestHelpers.StandardColors.Front, cube.GetSticker(CubeFace.Front, 4));
        Assert.Equal(TestHelpers.StandardColors.Back, cube.GetSticker(CubeFace.Back, 4));
        Assert.Equal(TestHelpers.StandardColors.Right, cube.GetSticker(CubeFace.Right, 4)); // Orange
        Assert.Equal(TestHelpers.StandardColors.Left, cube.GetSticker(CubeFace.Left, 4));   // Red
        Assert.Equal(TestHelpers.StandardColors.Up, cube.GetSticker(CubeFace.Up, 4));
        Assert.Equal(TestHelpers.StandardColors.Down, cube.GetSticker(CubeFace.Down, 4));
        
        // Verify it's solved
        Assert.True(cube.IsSolved());
        Assert.True(CubeStateValidator.IsSolved(cube));
    }

    [Fact]
    public void CubeStateValidator_IsValidCubeState_ShouldValidateSolvedCube()
    {
        // Arrange
        var cube = TestHelpers.CreateSolvedCube();
        
        // Act
        var isValid = CubeStateValidator.IsValidCubeState(cube, out string error);
        
        // Assert
        Assert.True(isValid);
        Assert.Empty(error);
    }

    [Fact]
    public void MoveTestDataGenerator_ShouldGenerateCorrectRMoveData()
    {
        // Arrange & Act
        var moveData = MoveTestDataGenerator.GetMoveChanges(CubeFace.Right, MoveType.Clockwise);
        
        // Assert
        Assert.Equal(12, moveData.Changes.Count); // 12 edge stickers that move
        // R move affects adjacent faces but not Right face itself (all orange stickers)
        Assert.Contains(CubeFace.Front, moveData.AffectedFaces);
        Assert.Contains(CubeFace.Up, moveData.AffectedFaces);
        Assert.Contains(CubeFace.Back, moveData.AffectedFaces);
        Assert.Contains(CubeFace.Down, moveData.AffectedFaces);
        
        // Log the changes for debugging
        _output.WriteLine(moveData.GetChangeDescription());
    }

    [Fact]
    public void VisualDiagrams_ShouldCreateMoveEffectDiagram()
    {
        // Arrange
        var move = new Move(CubeFace.Right, MoveType.Clockwise);
        
        // Act
        var diagram = VisualDiagrams.CreateMoveEffectDiagram(move);
        
        // Assert
        Assert.NotEmpty(diagram);
        Assert.Contains("BEFORE:", diagram);
        Assert.Contains("AFTER:", diagram);
        
        // Output for visual verification
        _output.WriteLine(diagram);
    }

    [Fact]
    public void EdgeCycleData_GetDMoveEdgeCycle_ShouldHaveCorrectColors()
    {
        // Arrange & Act
        var edgeCycle = MoveTestDataGenerator.EdgeCycleData.GetDMoveEdgeCycle();
        
        // Assert
        // Front bottom should get Orange (from Right)
        var frontData = edgeCycle.First(e => e.face == CubeFace.Front);
        Assert.Equal(new[] { 6, 7, 8 }, frontData.positions);
        Assert.All(frontData.expectedColors, c => Assert.Equal(CubeColor.Orange, c));
        
        // Right bottom should get Blue (from Back)
        var rightData = edgeCycle.First(e => e.face == CubeFace.Right);
        Assert.All(rightData.expectedColors, c => Assert.Equal(CubeColor.Blue, c));
        
        // Back bottom should get Red (from Left)
        var backData = edgeCycle.First(e => e.face == CubeFace.Back);
        Assert.All(backData.expectedColors, c => Assert.Equal(CubeColor.Red, c));
        
        // Left bottom should get Green (from Front)
        var leftData = edgeCycle.First(e => e.face == CubeFace.Left);
        Assert.All(leftData.expectedColors, c => Assert.Equal(CubeColor.Green, c));
    }

    [Fact]
    public void StandardColorReference_ShouldShowCorrectScheme()
    {
        // Act
        var reference = VisualDiagrams.GetStandardColorReference();
        
        // Assert
        Assert.Contains("Left = Red", reference);
        Assert.Contains("Right = Orange", reference);
        
        // Output for verification
        _output.WriteLine(reference);
    }
}