using RubiksCube.Core.Models;
using System.Text;

namespace RubiksCube.Tests.TestHelpers;

/// <summary>
/// Creates visual diagrams for debugging and documentation
/// </summary>
public static class VisualDiagrams
{
    /// <summary>
    /// Creates an ASCII art diagram showing move effects
    /// </summary>
    public static string CreateMoveEffectDiagram(Move move)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"=== {move} Move Effect ===");
        sb.AppendLine();
        
        var original = TestHelpers.CreateSolvedCube();
        var modified = TestHelpers.CreateSolvedCube();
        modified.ApplyMove(move);
        
        sb.AppendLine("BEFORE:                    AFTER:");
        sb.Append(CreateSideBySideDiagram(original, modified));
        
        return sb.ToString();
    }

    /// <summary>
    /// Creates a side-by-side comparison of two cube states
    /// </summary>
    public static string CreateSideBySideDiagram(Cube cube1, Cube cube2)
    {
        var sb = new StringBuilder();
        
        // Get face data
        var faces1 = GetAllFaceData(cube1);
        var faces2 = GetAllFaceData(cube2);
        
        // Up face
        AppendSideBySideFaces(sb, "Up", faces1[CubeFace.Up], faces2[CubeFace.Up], 11);
        sb.AppendLine();
        
        // Middle row (L, F, R, B)
        for (int row = 0; row < 3; row++)
        {
            // Left face
            AppendFaceRow(sb, faces1[CubeFace.Left], row);
            sb.Append(" ");
            
            // Front face
            AppendFaceRow(sb, faces1[CubeFace.Front], row);
            sb.Append(" ");
            
            // Right face
            AppendFaceRow(sb, faces1[CubeFace.Right], row);
            sb.Append(" ");
            
            // Back face
            AppendFaceRow(sb, faces1[CubeFace.Back], row);
            
            sb.Append("    |    ");
            
            // Same for cube2
            AppendFaceRow(sb, faces2[CubeFace.Left], row);
            sb.Append(" ");
            AppendFaceRow(sb, faces2[CubeFace.Front], row);
            sb.Append(" ");
            AppendFaceRow(sb, faces2[CubeFace.Right], row);
            sb.Append(" ");
            AppendFaceRow(sb, faces2[CubeFace.Back], row);
            
            sb.AppendLine();
        }
        
        sb.AppendLine();
        
        // Down face
        AppendSideBySideFaces(sb, "Down", faces1[CubeFace.Down], faces2[CubeFace.Down], 11);
        
        return sb.ToString();
    }

    /// <summary>
    /// Creates a detailed edge tracking diagram for a move
    /// </summary>
    public static string CreateEdgeTrackingDiagram(CubeFace moveFace)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"=== {moveFace} Move Edge Tracking ===");
        sb.AppendLine();
        
        switch (moveFace)
        {
            case CubeFace.Right:
                sb.AppendLine("R Move Edge Cycle (clockwise):");
                sb.AppendLine("  Front[2,5,8] → Up[2,5,8] → Back[6,3,0] → Down[2,5,8] → Front[2,5,8]");
                sb.AppendLine("  Colors: Green → Yellow → Blue → White → Green");
                break;
                
            case CubeFace.Left:
                sb.AppendLine("L Move Edge Cycle (clockwise):");
                sb.AppendLine("  Front[0,3,6] ← Up[0,3,6] ← Back[8,5,2] ← Down[0,3,6] ← Front[0,3,6]");
                sb.AppendLine("  Colors: Green ← Yellow ← Blue ← White ← Green");
                break;
                
            case CubeFace.Down:
                sb.AppendLine("D Move Edge Cycle (clockwise):");
                sb.AppendLine("  Front[6,7,8] → Right[6,7,8] → Back[6,7,8] → Left[6,7,8] → Front[6,7,8]");
                sb.AppendLine("  Colors: Green → Orange → Blue → Red → Green");
                break;
                
            case CubeFace.Front:
                sb.AppendLine("F Move Edge Cycle (clockwise):");
                sb.AppendLine("  Up[6,7,8] → Right[0,3,6] → Down[2,1,0] → Left[8,5,2] → Up[6,7,8]");
                sb.AppendLine("  Colors: Yellow → Orange → White → Red → Yellow");
                break;
                
            case CubeFace.Up:
                sb.AppendLine("U Move Edge Cycle (clockwise):");
                sb.AppendLine("  Front[0,1,2] → Left[0,1,2] → Back[0,1,2] → Right[0,1,2] → Front[0,1,2]");
                sb.AppendLine("  Colors: Green → Red → Blue → Orange → Green");
                break;
                
            case CubeFace.Back:
                sb.AppendLine("B Move Edge Cycle (clockwise):");
                sb.AppendLine("  Up[2,1,0] → Left[6,3,0] → Down[6,7,8] → Right[8,5,2] → Up[2,1,0]");
                sb.AppendLine("  Colors: Yellow → Red → White → Orange → Yellow");
                break;
        }
        
        return sb.ToString();
    }

    private static Dictionary<CubeFace, CubeColor[,]> GetAllFaceData(Cube cube)
    {
        var result = new Dictionary<CubeFace, CubeColor[,]>();
        
        foreach (CubeFace face in Enum.GetValues<CubeFace>())
        {
            var colors = cube.GetFace(face);
            var grid = new CubeColor[3, 3];
            
            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 3; col++)
                {
                    grid[row, col] = colors[row * 3 + col];
                }
            }
            
            result[face] = grid;
        }
        
        return result;
    }

    private static void AppendFaceRow(StringBuilder sb, CubeColor[,] face, int row)
    {
        for (int col = 0; col < 3; col++)
        {
            sb.Append(GetColorChar(face[row, col]));
            if (col < 2) sb.Append(" ");
        }
    }

    private static void AppendSideBySideFaces(StringBuilder sb, string label, CubeColor[,] face1, CubeColor[,] face2, int spacing)
    {
        for (int row = 0; row < 3; row++)
        {
            sb.Append(new string(' ', spacing));
            AppendFaceRow(sb, face1, row);
            sb.Append("    |    ");
            sb.Append(new string(' ', spacing));
            AppendFaceRow(sb, face2, row);
            sb.AppendLine();
        }
    }

    private static char GetColorChar(CubeColor color) => color switch
    {
        CubeColor.White => 'W',
        CubeColor.Red => 'R',
        CubeColor.Blue => 'B',
        CubeColor.Orange => 'O',
        CubeColor.Green => 'G',
        CubeColor.Yellow => 'Y',
        _ => '?'
    };

    /// <summary>
    /// Creates a reference diagram for standard color positions
    /// </summary>
    public static string GetStandardColorReference()
    {
        return @"
=== Standard Western Color Scheme ===
(Yellow top, Green front orientation)

         Y Y Y
         Y Y Y
         Y Y Y
    
R R R  G G G  O O O  B B B
R R R  G G G  O O O  B B B
R R R  G G G  O O O  B B B

         W W W
         W W W
         W W W

Left = Red (R)
Front = Green (G)
Right = Orange (O)
Back = Blue (B)
Up = Yellow (Y)
Down = White (W)
";
    }
}