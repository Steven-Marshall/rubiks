using RubiksCube.Core.Models;
using System.Text;

namespace RubiksCube.Tests.TestHelpers;

/// <summary>
/// Common test utilities for Rubik's Cube tests
/// </summary>
public static class TestHelpers
{
    /// <summary>
    /// Creates a solved cube with standard Western color scheme
    /// Yellow top, Green front -> Red left, Orange right, Blue back, White bottom
    /// </summary>
    public static Cube CreateSolvedCube() => new();

    /// <summary>
    /// Creates a cube from a specific state for testing
    /// </summary>
    public static Cube CreateCubeFromState(Dictionary<CubeFace, CubeColor[]> faceColors)
    {
        var cube = new Cube();
        foreach (var (face, colors) in faceColors)
        {
            cube.SetFace(face, colors);
        }
        return cube;
    }

    /// <summary>
    /// Asserts that two cubes have identical states
    /// </summary>
    public static void AssertCubesEqual(Cube expected, Cube actual, string message = "")
    {
        foreach (CubeFace face in Enum.GetValues<CubeFace>())
        {
            var expectedColors = expected.GetFace(face);
            var actualColors = actual.GetFace(face);
            
            for (int i = 0; i < 9; i++)
            {
                if (expectedColors[i] != actualColors[i])
                {
                    throw new Xunit.Sdk.XunitException(
                        $"{message}\nFace {face}, position {i}: expected {expectedColors[i]} but got {actualColors[i]}\n" +
                        $"Expected state:\n{GetCubeStateString(expected)}\n" +
                        $"Actual state:\n{GetCubeStateString(actual)}");
                }
            }
        }
    }

    /// <summary>
    /// Asserts that a specific face has the expected colors
    /// </summary>
    public static void AssertFaceEquals(Cube cube, CubeFace face, params CubeColor[] expectedColors)
    {
        if (expectedColors.Length != 9)
            throw new ArgumentException("Must provide exactly 9 colors for a face");

        var actualColors = cube.GetFace(face);
        for (int i = 0; i < 9; i++)
        {
            if (expectedColors[i] != actualColors[i])
            {
                throw new Xunit.Sdk.XunitException(
                    $"Face {face}, position {i}: expected {expectedColors[i]} but got {actualColors[i]}\n" +
                    $"Expected: {string.Join(", ", expectedColors)}\n" +
                    $"Actual: {string.Join(", ", actualColors)}");
            }
        }
    }

    /// <summary>
    /// Gets a human-readable string representation of cube state
    /// </summary>
    public static string GetCubeStateString(Cube cube)
    {
        var sb = new StringBuilder();
        sb.AppendLine("Cube State:");
        
        foreach (CubeFace face in Enum.GetValues<CubeFace>())
        {
            sb.AppendLine($"  {face}:");
            var colors = cube.GetFace(face);
            for (int row = 0; row < 3; row++)
            {
                sb.Append("    ");
                for (int col = 0; col < 3; col++)
                {
                    sb.Append(colors[row * 3 + col].ToString()[0]);
                    if (col < 2) sb.Append(" ");
                }
                sb.AppendLine();
            }
        }
        
        return sb.ToString();
    }

    /// <summary>
    /// Standard color scheme reference
    /// </summary>
    public static class StandardColors
    {
        public const CubeColor Front = CubeColor.Green;
        public const CubeColor Back = CubeColor.Blue;
        public const CubeColor Right = CubeColor.Orange;  // Corrected!
        public const CubeColor Left = CubeColor.Red;      // Corrected!
        public const CubeColor Up = CubeColor.Yellow;
        public const CubeColor Down = CubeColor.White;
    }

    /// <summary>
    /// Gets the color that should be on a face in solved state
    /// </summary>
    public static CubeColor GetSolvedFaceColor(CubeFace face) => face switch
    {
        CubeFace.Front => StandardColors.Front,
        CubeFace.Back => StandardColors.Back,
        CubeFace.Right => StandardColors.Right,
        CubeFace.Left => StandardColors.Left,
        CubeFace.Up => StandardColors.Up,
        CubeFace.Down => StandardColors.Down,
        _ => throw new ArgumentException($"Invalid face: {face}")
    };

    /// <summary>
    /// Creates an array of 9 identical colors (for a solved face)
    /// </summary>
    public static CubeColor[] CreateSolvedFace(CubeColor color) => 
        Enumerable.Repeat(color, 9).ToArray();

    /// <summary>
    /// Sticker position indices for reference
    /// </summary>
    public static class StickerPositions
    {
        // Standard 3x3 face layout:
        // 0 1 2
        // 3 4 5  
        // 6 7 8
        
        public const int TopLeft = 0;
        public const int TopCenter = 1;
        public const int TopRight = 2;
        public const int MiddleLeft = 3;
        public const int Center = 4;
        public const int MiddleRight = 5;
        public const int BottomLeft = 6;
        public const int BottomCenter = 7;
        public const int BottomRight = 8;
        
        // Useful position arrays
        public static readonly int[] TopRow = { 0, 1, 2 };
        public static readonly int[] MiddleRow = { 3, 4, 5 };
        public static readonly int[] BottomRow = { 6, 7, 8 };
        
        public static readonly int[] LeftColumn = { 0, 3, 6 };
        public static readonly int[] CenterColumn = { 1, 4, 7 };
        public static readonly int[] RightColumn = { 2, 5, 8 };
        
        public static readonly int[] Corners = { 0, 2, 6, 8 };
        public static readonly int[] Edges = { 1, 3, 5, 7 };
    }
}