using RubiksCube.Core.Models;

namespace RubiksCube.Tests.TestHelpers;

/// <summary>
/// Validates cube states for integrity and correctness
/// </summary>
public static class CubeStateValidator
{
    /// <summary>
    /// Validates that a cube has a valid state (correct number of each color)
    /// </summary>
    public static bool IsValidCubeState(Cube cube, out string error)
    {
        error = "";
        
        // Count occurrences of each color
        var colorCounts = new Dictionary<CubeColor, int>();
        foreach (CubeColor color in Enum.GetValues<CubeColor>())
        {
            colorCounts[color] = 0;
        }
        
        // Count colors across all faces
        foreach (CubeFace face in Enum.GetValues<CubeFace>())
        {
            var faceColors = cube.GetFace(face);
            foreach (var color in faceColors)
            {
                colorCounts[color]++;
            }
        }
        
        // Each color should appear exactly 9 times
        foreach (var (color, count) in colorCounts)
        {
            if (count != 9)
            {
                error = $"Color {color} appears {count} times, expected 9";
                return false;
            }
        }
        
        // Validate center pieces (they define face identity)
        if (!ValidateCenterColors(cube, out error))
        {
            return false;
        }
        
        return true;
    }

    /// <summary>
    /// Validates that center stickers are unique across faces
    /// </summary>
    private static bool ValidateCenterColors(Cube cube, out string error)
    {
        error = "";
        var centerColors = new HashSet<CubeColor>();
        
        foreach (CubeFace face in Enum.GetValues<CubeFace>())
        {
            var centerColor = cube.GetSticker(face, TestHelpers.StickerPositions.Center);
            if (!centerColors.Add(centerColor))
            {
                error = $"Duplicate center color {centerColor} found";
                return false;
            }
        }
        
        return true;
    }

    /// <summary>
    /// Validates that a cube is in solved state
    /// </summary>
    public static bool IsSolved(Cube cube)
    {
        foreach (CubeFace face in Enum.GetValues<CubeFace>())
        {
            var faceColors = cube.GetFace(face);
            var firstColor = faceColors[0];
            
            // All stickers on a face should be the same color
            if (!faceColors.All(c => c == firstColor))
            {
                return false;
            }
            
            // The color should match the expected color for that face
            var expectedColor = TestHelpers.GetSolvedFaceColor(face);
            if (firstColor != expectedColor)
            {
                return false;
            }
        }
        
        return true;
    }

    /// <summary>
    /// Checks if cube state was preserved except for expected changes
    /// Useful for verifying moves only affect intended stickers
    /// </summary>
    public static bool StatePreservedExcept(
        Cube originalCube, 
        Cube modifiedCube, 
        Dictionary<(CubeFace face, int position), CubeColor> expectedChanges,
        out string error)
    {
        error = "";
        
        foreach (CubeFace face in Enum.GetValues<CubeFace>())
        {
            var originalColors = originalCube.GetFace(face);
            var modifiedColors = modifiedCube.GetFace(face);
            
            for (int i = 0; i < 9; i++)
            {
                var key = (face, i);
                
                if (expectedChanges.ContainsKey(key))
                {
                    // This position should have changed
                    if (modifiedColors[i] != expectedChanges[key])
                    {
                        error = $"Face {face}, position {i}: expected {expectedChanges[key]} but got {modifiedColors[i]}";
                        return false;
                    }
                }
                else
                {
                    // This position should not have changed
                    if (originalColors[i] != modifiedColors[i])
                    {
                        error = $"Face {face}, position {i}: unexpected change from {originalColors[i]} to {modifiedColors[i]}";
                        return false;
                    }
                }
            }
        }
        
        return true;
    }

    /// <summary>
    /// Validates edge piece consistency (each edge has exactly 2 stickers)
    /// </summary>
    public static bool ValidateEdgePieces(Cube cube, out string error)
    {
        error = "";
        
        // Define all 12 edges as pairs of (face, position)
        var edges = new[]
        {
            // Top layer edges
            ((CubeFace.Up, 1), (CubeFace.Back, 1)),     // UB
            ((CubeFace.Up, 3), (CubeFace.Left, 1)),     // UL
            ((CubeFace.Up, 5), (CubeFace.Right, 1)),    // UR
            ((CubeFace.Up, 7), (CubeFace.Front, 1)),    // UF
            
            // Middle layer edges
            ((CubeFace.Front, 3), (CubeFace.Left, 5)),  // FL
            ((CubeFace.Front, 5), (CubeFace.Right, 3)), // FR
            ((CubeFace.Back, 3), (CubeFace.Right, 5)),  // BR
            ((CubeFace.Back, 5), (CubeFace.Left, 3)),   // BL
            
            // Bottom layer edges
            ((CubeFace.Down, 1), (CubeFace.Front, 7)),  // DF
            ((CubeFace.Down, 3), (CubeFace.Left, 7)),   // DL
            ((CubeFace.Down, 5), (CubeFace.Right, 7)),  // DR
            ((CubeFace.Down, 7), (CubeFace.Back, 7))    // DB
        };
        
        // In a solved cube, each edge piece should have its two stickers
        // be from the two faces it connects
        foreach (var (sticker1, sticker2) in edges)
        {
            var color1 = cube.GetSticker(sticker1.Item1, sticker1.Item2);
            var color2 = cube.GetSticker(sticker2.Item1, sticker2.Item2);
            
            // For validation, we just check that it's a valid edge combination
            // (In a real cube, certain color pairs cannot be edges)
            if (color1 == color2)
            {
                error = $"Edge piece at {sticker1.Item1}:{sticker1.Item2} and {sticker2.Item1}:{sticker2.Item2} has same color on both stickers";
                return false;
            }
        }
        
        return true;
    }
}