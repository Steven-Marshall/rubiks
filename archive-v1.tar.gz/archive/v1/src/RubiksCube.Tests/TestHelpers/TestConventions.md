# Rubik's Cube Test Conventions

## Color Scheme (Western/BOY)
Standard solved cube orientation:
- **Up**: Yellow 🟨
- **Down**: White ⬜
- **Front**: Green 🟩  
- **Back**: Blue 🟦
- **Left**: Red 🟥 (IMPORTANT: Fixed from old scheme)
- **Right**: Orange 🟧 (IMPORTANT: Fixed from old scheme)

## Move Directions
All moves are **clockwise when looking at that face**:
- **R**: Right face clockwise (looking from right side)
- **L**: Left face clockwise (looking from left side)
- **U**: Up face clockwise (looking from above)
- **D**: Down face clockwise (looking from below)
- **F**: Front face clockwise (looking from front)
- **B**: Back face clockwise (looking from back)

Move modifiers:
- **'** (prime): Counter-clockwise (e.g., R' is right face counter-clockwise)
- **2** (double): 180-degree turn (e.g., R2 is right face twice)

## Sticker Positions
Each face has 9 stickers numbered 0-8:
```
0 1 2
3 4 5
6 7 8
```

- Position 4 is always the center sticker
- Corners: 0, 2, 6, 8
- Edges: 1, 3, 5, 7

## Edge Cycles for Moves

### R Move (Right Clockwise)
Front right column → Up right column → Back left column → Down right column → Front
- Affected positions: Front/Up/Down [2,5,8], Back [0,3,6]

### L Move (Left Clockwise) - FIXED!
Front left ← Up left ← Back right ← Down left ← Front
- Affected positions: Front/Up/Down [0,3,6], Back [8,5,2]

### U Move (Up Clockwise)
Front top → Left top → Back top → Right top → Front
- Affected positions: All faces [0,1,2]

### D Move (Down Clockwise) - FIXED!
Front bottom → Right bottom → Back bottom → Left bottom → Front
- Affected positions: All faces [6,7,8]

### F Move (Front Clockwise) - FIXED!
Up bottom → Right left → Down top → Left right → Up
- Up [6,7,8], Right [0,3,6], Down [0,1,2], Left [2,5,8]

### B Move (Back Clockwise)
Up top → Left left → Down bottom → Right right → Up
- Up [0,1,2], Left [0,3,6], Down [6,7,8], Right [2,5,8]

## Cube Rotations

### x Rotation (follows R direction)
Entire cube rotates around Right-Left axis
- Front → Up → Back → Down → Front

### y Rotation (follows U direction)  
Entire cube rotates around Up-Down axis
- Front → Left → Back → Right → Front

### z Rotation (follows F direction) - FIXED!
Entire cube rotates around Front-Back axis (now clockwise!)
- Up → Right → Down → Left → Up

## Test Naming Conventions

### Unit Tests
- `{MethodName}_Should{ExpectedBehavior}_When{Condition}`
- Example: `ApplyMove_ShouldRotateFaceClockwise_WhenRMoveApplied`

### Integration Tests
- `{Feature}_Should{Result}_For{Scenario}`
- Example: `CrossSolver_ShouldReturnEmptyAlgorithm_ForSolvedCube`

## Assertion Best Practices

1. **Use TestHelpers methods** for common assertions
2. **Include diagnostic info** in failure messages
3. **Test one concept per test** 
4. **Use descriptive variable names**
5. **Comment complex test setups**

## Example Test Structure
```csharp
[Fact]
public void RMove_ShouldCycleFrontRightToUpRight_WhenAppliedToSolvedCube()
{
    // Arrange
    var cube = TestHelpers.CreateSolvedCube();
    var move = new Move(CubeFace.Right, MoveType.Clockwise);
    
    // Act
    cube.ApplyMove(move);
    
    // Assert
    // Front right column should now have white (from down face)
    TestHelpers.AssertFaceEquals(cube, CubeFace.Front,
        StandardColors.Front, StandardColors.Front, StandardColors.Down,
        StandardColors.Front, StandardColors.Front, StandardColors.Down,
        StandardColors.Front, StandardColors.Front, StandardColors.Down);
}
```