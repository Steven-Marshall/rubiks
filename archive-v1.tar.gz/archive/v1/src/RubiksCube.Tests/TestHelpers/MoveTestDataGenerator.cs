using RubiksCube.Core.Models;

namespace RubiksCube.Tests.TestHelpers;

/// <summary>
/// Generates expected cube states after moves for testing
/// </summary>
public class MoveTestDataGenerator
{
    /// <summary>
    /// Generates the expected cube state after applying a move to a solved cube
    /// </summary>
    public static Cube GenerateExpectedState(Move move)
    {
        var cube = TestHelpers.CreateSolvedCube();
        cube.ApplyMove(move);
        return cube;
    }

    /// <summary>
    /// Generates expected states for all basic moves
    /// </summary>
    public static Dictionary<string, Cube> GenerateAllBasicMoveStates()
    {
        var states = new Dictionary<string, Cube>();
        var faces = Enum.GetValues<CubeFace>();
        var moveTypes = new[] { MoveType.Clockwise, MoveType.CounterClockwise, MoveType.Double };
        
        foreach (var face in faces)
        {
            foreach (var moveType in moveTypes)
            {
                var move = new Move(face, moveType);
                var moveNotation = move.ToString();
                states[moveNotation] = GenerateExpectedState(move);
            }
        }
        
        return states;
    }

    /// <summary>
    /// Gets detailed information about what stickers change for a given move
    /// </summary>
    public static MoveChangeData GetMoveChanges(CubeFace face, MoveType moveType)
    {
        var original = TestHelpers.CreateSolvedCube();
        var modified = TestHelpers.CreateSolvedCube();
        modified.ApplyMove(new Move(face, moveType));
        
        var changes = new Dictionary<(CubeFace face, int position), (CubeColor from, CubeColor to)>();
        
        foreach (CubeFace f in Enum.GetValues<CubeFace>())
        {
            var originalColors = original.GetFace(f);
            var modifiedColors = modified.GetFace(f);
            
            for (int i = 0; i < 9; i++)
            {
                if (originalColors[i] != modifiedColors[i])
                {
                    changes[(f, i)] = (originalColors[i], modifiedColors[i]);
                }
            }
        }
        
        return new MoveChangeData
        {
            Move = new Move(face, moveType),
            Changes = changes,
            AffectedFaces = changes.Select(c => c.Key.face).Distinct().ToList()
        };
    }

    /// <summary>
    /// Generates test data for edge cycle validation
    /// </summary>
    public static class EdgeCycleData
    {
        /// <summary>
        /// Gets the edge cycle for R move (clockwise)
        /// </summary>
        public static List<(CubeFace face, int[] positions, CubeColor[] expectedColors)> GetRMoveEdgeCycle()
        {
            // R move affects: Front right -> Up right -> Back left -> Down right -> Front right
            return new List<(CubeFace, int[], CubeColor[])>
            {
                (CubeFace.Front, new[] { 2, 5, 8 }, new[] { CubeColor.White, CubeColor.White, CubeColor.White }), // From Down
                (CubeFace.Up, new[] { 2, 5, 8 }, new[] { CubeColor.Green, CubeColor.Green, CubeColor.Green }), // From Front
                (CubeFace.Back, new[] { 0, 3, 6 }, new[] { CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow }), // From Up (reversed)
                (CubeFace.Down, new[] { 2, 5, 8 }, new[] { CubeColor.Blue, CubeColor.Blue, CubeColor.Blue }) // From Back (reversed)
            };
        }

        /// <summary>
        /// Gets the edge cycle for L move (clockwise) - FIXED!
        /// </summary>
        public static List<(CubeFace face, int[] positions, CubeColor[] expectedColors)> GetLMoveEdgeCycle()
        {
            // L move affects: Front left <- Up left <- Back right <- Down left <- Front left
            return new List<(CubeFace, int[], CubeColor[])>
            {
                (CubeFace.Front, new[] { 0, 3, 6 }, new[] { CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow }), // From Up
                (CubeFace.Up, new[] { 0, 3, 6 }, new[] { CubeColor.Blue, CubeColor.Blue, CubeColor.Blue }), // From Back (reversed)
                (CubeFace.Back, new[] { 8, 5, 2 }, new[] { CubeColor.White, CubeColor.White, CubeColor.White }), // From Down (reversed)
                (CubeFace.Down, new[] { 0, 3, 6 }, new[] { CubeColor.Green, CubeColor.Green, CubeColor.Green }) // From Front
            };
        }

        /// <summary>
        /// Gets the edge cycle for D move (clockwise) - FIXED!
        /// </summary>
        public static List<(CubeFace face, int[] positions, CubeColor[] expectedColors)> GetDMoveEdgeCycle()
        {
            // D move affects bottom rows: Front -> Right -> Back -> Left -> Front
            return new List<(CubeFace, int[], CubeColor[])>
            {
                (CubeFace.Front, new[] { 6, 7, 8 }, new[] { CubeColor.Orange, CubeColor.Orange, CubeColor.Orange }), // From Right
                (CubeFace.Right, new[] { 6, 7, 8 }, new[] { CubeColor.Blue, CubeColor.Blue, CubeColor.Blue }), // From Back
                (CubeFace.Back, new[] { 6, 7, 8 }, new[] { CubeColor.Red, CubeColor.Red, CubeColor.Red }), // From Left
                (CubeFace.Left, new[] { 6, 7, 8 }, new[] { CubeColor.Green, CubeColor.Green, CubeColor.Green }) // From Front
            };
        }

        /// <summary>
        /// Gets the edge cycle for F move (clockwise) - FIXED!
        /// </summary>
        public static List<(CubeFace face, int[] positions, CubeColor[] expectedColors)> GetFMoveEdgeCycle()
        {
            // F move affects: Up bottom -> Right left -> Down top -> Left right -> Up bottom
            return new List<(CubeFace, int[], CubeColor[])>
            {
                (CubeFace.Up, new[] { 6, 7, 8 }, new[] { CubeColor.Orange, CubeColor.Orange, CubeColor.Orange }), // From Right (rotated)
                (CubeFace.Right, new[] { 0, 3, 6 }, new[] { CubeColor.White, CubeColor.White, CubeColor.White }), // From Down (reversed)
                (CubeFace.Down, new[] { 0, 1, 2 }, new[] { CubeColor.Red, CubeColor.Red, CubeColor.Red }), // From Left (rotated)  
                (CubeFace.Left, new[] { 2, 5, 8 }, new[] { CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow }) // From Up (reversed)
            };
        }
    }

    /// <summary>
    /// Data class for move changes
    /// </summary>
    public class MoveChangeData
    {
        public Move Move { get; set; }
        public Dictionary<(CubeFace face, int position), (CubeColor from, CubeColor to)> Changes { get; set; }
        public List<CubeFace> AffectedFaces { get; set; }
        
        public string GetChangeDescription()
        {
            var desc = $"Move {Move} affects {Changes.Count} stickers on faces: {string.Join(", ", AffectedFaces)}\n";
            foreach (var change in Changes.OrderBy(c => c.Key.face).ThenBy(c => c.Key.position))
            {
                desc += $"  {change.Key.face}[{change.Key.position}]: {change.Value.from} → {change.Value.to}\n";
            }
            return desc;
        }
    }
}