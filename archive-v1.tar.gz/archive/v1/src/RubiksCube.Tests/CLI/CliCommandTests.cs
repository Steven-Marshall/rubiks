using RubiksCube.Core.Models;
using RubiksCube.Core.Notation;
using RubiksCube.Core.Storage;
using RubiksCube.Core.Scrambling;
using RubiksCube.Core.Display;
using RubiksCube.Core.Configuration;
using Xunit;
using Xunit.Abstractions;

namespace RubiksCube.Tests.CLI;

public class CliCommandTests : IDisposable
{
    private readonly ITestOutputHelper _output;
    private readonly string _testDirectory;

    public CliCommandTests(ITestOutputHelper output)
    {
        _output = output;
        _testDirectory = Path.Combine(Path.GetTempPath(), $"rubiks-cli-test-{Guid.NewGuid()}");
        Directory.CreateDirectory(_testDirectory);
    }

    public void Dispose()
    {
        if (Directory.Exists(_testDirectory))
        {
            Directory.Delete(_testDirectory, true);
        }
    }

    #region Storage Service Tests (CLI Foundation)

    [Fact]
    public void Storage_SaveAndLoad_ShouldWorkCorrectly()
    {
        // Arrange
        string cubeName = "test-cube";
        var originalCube = new Cube();
        var algorithm = Algorithm.Create("R U R' U'");
        algorithm.Value.ApplyTo(originalCube);

        // Act
        var saveResult = CubeStorageService.Save(originalCube, cubeName, _testDirectory);
        var loadResult = CubeStorageService.Load(cubeName, _testDirectory);

        // Assert
        Assert.True(saveResult.IsSuccess);
        Assert.True(loadResult.IsSuccess);
        Assert.Equal(originalCube.ToJson(), loadResult.Value.ToJson());
    }

    [Fact]
    public void Storage_List_ShouldReturnSavedCubes()
    {
        // Arrange
        var cube = new Cube();
        CubeStorageService.Save(cube, "cube1", _testDirectory);
        CubeStorageService.Save(cube, "cube2", _testDirectory);

        // Act
        var cubes = CubeStorageService.List(_testDirectory);

        // Assert
        Assert.Equal(2, cubes.Count());
        Assert.Contains("cube1", cubes);
        Assert.Contains("cube2", cubes);
    }

    [Fact]
    public void Storage_Delete_ShouldRemoveCube()
    {
        // Arrange
        string cubeName = "delete-test";
        var cube = new Cube();
        CubeStorageService.Save(cube, cubeName, _testDirectory);
        Assert.True(CubeStorageService.Exists(cubeName, _testDirectory));

        // Act
        var result = CubeStorageService.Delete(cubeName, _testDirectory);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.False(CubeStorageService.Exists(cubeName, _testDirectory));
    }

    [Fact]
    public void Storage_Export_ShouldReturnCubeJson()
    {
        // Arrange
        string cubeName = "export-test";
        var cube = new Cube();
        var algorithm = Algorithm.Create("R U R'");
        algorithm.Value.ApplyTo(cube);
        CubeStorageService.Save(cube, cubeName, _testDirectory);

        // Act
        var result = CubeStorageService.Export(cubeName, _testDirectory);

        // Assert
        Assert.True(result.IsSuccess);
        var exportedCube = Cube.FromJson(result.Value);
        Assert.Equal(cube.ToJson(), exportedCube.ToJson());
    }

    #endregion

    #region Cube Creation Tests

    [Fact]
    public void CreateCube_ShouldGenerateSolvedState()
    {
        // Act
        var cube = new Cube();

        // Assert
        Assert.NotNull(cube);
        var json = cube.ToJson();
        Assert.Contains("\"faces\"", json);
        Assert.Contains("\"front\"", json);
        
        // Verify it's in solved state
        var frontFace = cube.GetFace(CubeFace.Front);
        Assert.All(frontFace, color => Assert.Equal(CubeColor.Green, color));
    }

    #endregion

    #region Algorithm Application Tests

    [Fact]
    public void ApplyAlgorithm_ValidSequence_ShouldModifyCube()
    {
        // Arrange
        var cube = new Cube();
        var originalJson = cube.ToJson();

        // Act
        var algorithm = Algorithm.Create("R U R' U'");
        Assert.True(algorithm.IsSuccess);
        
        var result = algorithm.Value.ApplyTo(cube);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.NotEqual(originalJson, cube.ToJson());
    }

    [Fact]
    public void ApplyAlgorithm_WithRotations_ShouldModifyCubeAndOrientation()
    {
        // Arrange
        var cube = new Cube();
        var originalJson = cube.ToJson();

        // Act
        var algorithm = Algorithm.Create("y' R U R'");
        Assert.True(algorithm.IsSuccess);
        
        var result = algorithm.Value.ApplyTo(cube);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.NotEqual(originalJson, cube.ToJson());
        
        // Verify orientation changed
        var orientationInfo = cube.GetOrientationDebugInfo();
        Assert.Contains("Red", orientationInfo); // Red face should be in front after y'
    }

    [Fact]
    public void ApplyAlgorithm_InvalidSequence_ShouldFail()
    {
        // Act
        var algorithm = Algorithm.Create("INVALID_MOVE");

        // Assert
        Assert.True(algorithm.IsFailure);
        Assert.Contains("Invalid move token", algorithm.Error);
    }

    #endregion

    #region Display Tests

    [Fact]
    public void DisplayCube_UnicodeFormat_ShouldContainUnicodeCharacters()
    {
        // Arrange
        var cube = new Cube();
        var config = new DisplayConfig { Format = DisplayFormat.Unicode };

        // Act
        var result = DisplayService.DisplayCubeWithConfig(cube, config);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.Contains("🟨", result.Value); // Yellow face
        Assert.Contains("🟩", result.Value); // Green face
    }

    [Fact]
    public void DisplayCube_AsciiFormat_ShouldContainAsciiCharacters()
    {
        // Arrange
        var cube = new Cube();
        var config = new DisplayConfig { Format = DisplayFormat.ASCII };

        // Act
        var result = DisplayService.DisplayCubeWithConfig(cube, config);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.Contains("Y", result.Value); // Yellow face
        Assert.Contains("G", result.Value); // Green face
        Assert.DoesNotContain("🟨", result.Value); // Should not contain unicode
    }

    [Fact]
    public void DisplayCube_WithOrientation_ShouldShowCorrectColors()
    {
        // Arrange
        var cube = new Cube();
        var algorithm = Algorithm.Create("y"); // Rotate cube
        algorithm.Value.ApplyTo(cube);
        var config = new DisplayConfig { Format = DisplayFormat.ASCII };

        // Act
        var result = DisplayService.DisplayCubeWithConfig(cube, config);

        // Assert
        Assert.True(result.IsSuccess);
        // After y rotation, orientation should change what's visible in each position
        Assert.NotEmpty(result.Value);
    }

    #endregion

    #region Scramble Generation Tests

    [Fact]
    public void ScrambleGeneration_DefaultParameters_ShouldGenerate20Moves()
    {
        // Arrange
        var generator = new ScrambleGenerator(seed: 12345);

        // Act
        var result = generator.GenerateScramble();

        // Assert
        Assert.True(result.IsSuccess);
        Assert.Equal(20, result.Value.MoveCount);
    }

    [Fact]
    public void ScrambleGeneration_WithSeed_ShouldBeReproducible()
    {
        // Arrange
        var generator1 = new ScrambleGenerator(seed: 42);
        var generator2 = new ScrambleGenerator(seed: 42);

        // Act
        var result1 = generator1.GenerateScramble();
        var result2 = generator2.GenerateScramble();

        // Assert
        Assert.True(result1.IsSuccess);
        Assert.True(result2.IsSuccess);
        Assert.Equal(result1.Value.ToString(), result2.Value.ToString());
    }

    [Fact]
    public void ScrambleGeneration_CustomLength_ShouldGenerateCorrectCount()
    {
        // Arrange
        var generator = new ScrambleGenerator(seed: 123);

        // Act
        var result = generator.GenerateScramble(15);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.Equal(15, result.Value.MoveCount);
    }

    [Fact]
    public void ScrambleGeneration_StrictWcaRules_ShouldNotHaveConsecutiveSameFace()
    {
        // Arrange
        var generator = new ScrambleGenerator(seed: 999);

        // Act
        var result = generator.GenerateScramble(moveCount: 20, strictWcaRules: true);

        // Assert
        Assert.True(result.IsSuccess);
        
        var moves = result.Value.Moves;
        for (int i = 1; i < moves.Count; i++)
        {
            Assert.NotEqual(moves[i-1].Face, moves[i].Face);
        }
    }

    #endregion

    #region Debug Command Tests

    [Fact]
    public void DebugOrientation_ShouldShowPositionMapping()
    {
        // Arrange
        var cube = new Cube();
        var algorithm = Algorithm.Create("y' R U R'");
        algorithm.Value.ApplyTo(cube);

        // Act
        var debugInfo = cube.GetOrientationDebugInfo();

        // Assert
        Assert.Contains("position has:", debugInfo);
        Assert.Contains("Red", debugInfo); // Should show color mapping after y'
    }

    [Fact]
    public void DebugAlgorithm_ShouldShowMoveAndRotationCounts()
    {
        // Arrange
        var algorithm = new Algorithm("R U R' U' y x2");

        // Act
        var debugInfo = algorithm.GetAlgorithmDebugInfo();

        // Assert
        Assert.Contains("Algorithm", debugInfo);
        Assert.Contains("contains", debugInfo);
        Assert.Contains("operations", debugInfo);
    }

    #endregion

    #region Validation Tests

    [Theory]
    [InlineData("cube1")]
    [InlineData("my-cube")]
    [InlineData("test_cube")]
    [InlineData("cube123")]
    [InlineData("a")]
    [InlineData("very-long-cube-name-that-should-still-work")]
    public void ValidateCubeName_ValidNames_ShouldSucceed(string cubeName)
    {
        // Act
        var result = CubeStorageService.ValidateCubeName(cubeName);

        // Assert
        Assert.True(result.IsSuccess);
    }

    [Theory]
    [InlineData("")]
    [InlineData("cube/slash")]
    [InlineData("cube\\backslash")]
    [InlineData("cube:colon")]
    [InlineData("cube*asterisk")]
    [InlineData("cube?question")]
    [InlineData("cube|pipe")]
    [InlineData("cube<less")]
    [InlineData("cube>greater")]
    [InlineData("cube\"quote")]
    public void ValidateCubeName_InvalidNames_ShouldFail(string cubeName)
    {
        // Act
        var result = CubeStorageService.ValidateCubeName(cubeName);

        // Assert
        Assert.True(result.IsFailure);
        // Error message could be "empty", "cannot contain", or other validation messages
        Assert.NotEmpty(result.Error);
    }

    #endregion

    #region Integration Workflow Tests

    [Fact]
    public void WorkflowTest_CreateApplyDisplay_ShouldWork()
    {
        // Test traditional workflow: create -> apply -> display
        
        // Step 1: Create cube
        var cube = new Cube();
        var originalJson = cube.ToJson();
        Assert.Contains("\"faces\"", originalJson);
        
        // Step 2: Apply algorithm
        var algorithm = Algorithm.Create("R U R'");
        Assert.True(algorithm.IsSuccess);
        
        var applyResult = algorithm.Value.ApplyTo(cube);
        Assert.True(applyResult.IsSuccess);
        
        var modifiedJson = cube.ToJson();
        Assert.NotEqual(originalJson, modifiedJson);
        
        // Step 3: Display cube
        var config = new DisplayConfig { Format = DisplayFormat.Unicode };
        var displayResult = DisplayService.DisplayCubeWithConfig(cube, config);
        Assert.True(displayResult.IsSuccess);
        Assert.Contains("🟨", displayResult.Value);
    }

    [Fact]
    public void WorkflowTest_NamedCubeOperations_ShouldWork()
    {
        // Test named cube workflow: create -> save -> apply -> load -> display
        
        string cubeName = "workflow-test";
        
        // Step 1: Create and save cube
        var cube = new Cube();
        var saveResult = CubeStorageService.Save(cube, cubeName, _testDirectory);
        Assert.True(saveResult.IsSuccess);
        
        // Step 2: Apply algorithm to stored cube
        var loadResult = CubeStorageService.Load(cubeName, _testDirectory);
        Assert.True(loadResult.IsSuccess);
        
        var algorithm = Algorithm.Create("R U R' U'");
        Assert.True(algorithm.IsSuccess);
        
        var applyResult = algorithm.Value.ApplyTo(loadResult.Value);
        Assert.True(applyResult.IsSuccess);
        
        // Step 3: Save modified cube
        var saveModifiedResult = CubeStorageService.Save(loadResult.Value, cubeName, _testDirectory);
        Assert.True(saveModifiedResult.IsSuccess);
        
        // Step 4: Load and verify changes persisted
        var finalLoadResult = CubeStorageService.Load(cubeName, _testDirectory);
        Assert.True(finalLoadResult.IsSuccess);
        Assert.NotEqual(cube.ToJson(), finalLoadResult.Value.ToJson());
        
        // Step 5: Export and verify
        var exportResult = CubeStorageService.Export(cubeName, _testDirectory);
        Assert.True(exportResult.IsSuccess);
        
        var exportedCube = Cube.FromJson(exportResult.Value);
        Assert.Equal(finalLoadResult.Value.ToJson(), exportedCube.ToJson());
        
        // Step 6: List should show our cube
        var cubes = CubeStorageService.List(_testDirectory);
        Assert.Contains(cubeName, cubes);
        
        // Step 7: Delete cube
        var deleteResult = CubeStorageService.Delete(cubeName, _testDirectory);
        Assert.True(deleteResult.IsSuccess);
        
        // Step 8: Verify deletion
        var finalCubes = CubeStorageService.List(_testDirectory);
        Assert.DoesNotContain(cubeName, finalCubes);
    }

    [Fact]
    public void WorkflowTest_ScrambleAndSolve_ShouldWork()
    {
        // Test scramble generation and application workflow
        
        string cubeName = "scramble-test";
        
        // Step 1: Create cube
        var cube = new Cube();
        var solvedJson = cube.ToJson();
        
        // Step 2: Generate scramble
        var generator = new ScrambleGenerator(seed: 123);
        var scrambleResult = generator.GenerateScramble(5); // Short scramble for testing
        Assert.True(scrambleResult.IsSuccess);
        Assert.Equal(5, scrambleResult.Value.MoveCount);
        
        // Step 3: Apply scramble to cube
        var applyResult = scrambleResult.Value.ApplyTo(cube);
        Assert.True(applyResult.IsSuccess);
        
        // Step 4: Verify cube is scrambled
        var scrambledJson = cube.ToJson();
        Assert.NotEqual(solvedJson, scrambledJson);
        
        // Step 5: Save scrambled cube
        var saveResult = CubeStorageService.Save(cube, cubeName, _testDirectory);
        Assert.True(saveResult.IsSuccess);
        
        // Step 6: Test orientation with scrambled cube
        var orientationInfo = cube.GetOrientationDebugInfo();
        Assert.Contains("position has:", orientationInfo);
        
        // Step 7: Clean up
        var deleteResult = CubeStorageService.Delete(cubeName, _testDirectory);
        Assert.True(deleteResult.IsSuccess);
    }

    [Fact]
    public void WorkflowTest_OrientationPersistence_ShouldWork()
    {
        // Test that orientation changes persist through save/load
        
        string cubeName = "orientation-test";
        
        // Step 1: Create cube and apply rotation
        var cube = new Cube();
        var algorithm = Algorithm.Create("y' R U R'");
        Assert.True(algorithm.IsSuccess);
        
        var applyResult = algorithm.Value.ApplyTo(cube);
        Assert.True(applyResult.IsSuccess);
        
        var originalOrientationInfo = cube.GetOrientationDebugInfo();
        Assert.Contains("Red", originalOrientationInfo); // Red should be in front after y'
        
        // Step 2: Save cube
        var saveResult = CubeStorageService.Save(cube, cubeName, _testDirectory);
        Assert.True(saveResult.IsSuccess);
        
        // Step 3: Load cube and verify orientation persisted
        var loadResult = CubeStorageService.Load(cubeName, _testDirectory);
        Assert.True(loadResult.IsSuccess);
        
        var restoredOrientationInfo = loadResult.Value.GetOrientationDebugInfo();
        Assert.Equal(originalOrientationInfo, restoredOrientationInfo);
        
        // Step 4: Verify display also reflects orientation
        var config = new DisplayConfig { Format = DisplayFormat.ASCII };
        var originalDisplay = DisplayService.DisplayCubeWithConfig(cube, config);
        var restoredDisplay = DisplayService.DisplayCubeWithConfig(loadResult.Value, config);
        
        Assert.True(originalDisplay.IsSuccess);
        Assert.True(restoredDisplay.IsSuccess);
        Assert.Equal(originalDisplay.Value, restoredDisplay.Value);
        
        // Step 5: Clean up
        var deleteResult = CubeStorageService.Delete(cubeName, _testDirectory);
        Assert.True(deleteResult.IsSuccess);
    }

    #endregion
}