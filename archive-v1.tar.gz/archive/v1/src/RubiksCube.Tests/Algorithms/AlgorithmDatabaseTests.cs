using RubiksCube.Core.Algorithms;
using Xunit;

namespace RubiksCube.Tests.Algorithms;

public class AlgorithmDatabaseTests
{
    private readonly string _testConfigPath;
    private readonly AlgorithmDatabase _database;

    public AlgorithmDatabaseTests()
    {
        // Use absolute path to config file for testing
        _testConfigPath = "/mnt/c/users/steve/onedrive/Documents/code/rubiks/algorithms/algorithm-config.json";
        _database = new AlgorithmDatabase();
    }

    [Fact]
    public async Task LoadFromConfig_ValidConfig_ShouldSucceed()
    {
        // Act
        var result = await _database.LoadFromConfig(_testConfigPath);

        // Assert
        Assert.True(result.IsSuccess, result.IsFailure ? $"Failed to load config: {result.Error}. Path: {_testConfigPath}" : "Success");
    }

    [Fact]
    public async Task LoadFromConfig_InvalidPath_ShouldFail()
    {
        // Act
        var result = await _database.LoadFromConfig("nonexistent-config.json");

        // Assert
        Assert.True(result.IsFailure);
        Assert.Contains("Configuration file not found", result.Error);
    }

    [Fact]
    public async Task GetAlgorithmSets_AfterLoading_ShouldReturnEnabledSets()
    {
        // Arrange
        await _database.LoadFromConfig(_testConfigPath);

        // Act
        var algorithmSets = _database.GetAlgorithmSets().ToList();

        // Assert
        Assert.NotEmpty(algorithmSets);
        Assert.Contains(algorithmSets, set => set.Id == "4lll");
        Assert.All(algorithmSets, set => Assert.True(set.Enabled));
    }

    [Fact]
    public async Task GetAlgorithmSet_ValidId_ShouldReturnSet()
    {
        // Arrange
        await _database.LoadFromConfig(_testConfigPath);

        // Act
        var algorithmSet = _database.GetAlgorithmSet("4lll");

        // Assert
        Assert.NotNull(algorithmSet);
        Assert.Equal("4lll", algorithmSet.Id);
        Assert.Equal("4-Look Last Layer (4LLL)", algorithmSet.Name);
    }

    [Fact]
    public async Task GetAlgorithmSet_InvalidId_ShouldReturnNull()
    {
        // Arrange
        await _database.LoadFromConfig(_testConfigPath);

        // Act
        var algorithmSet = _database.GetAlgorithmSet("nonexistent");

        // Assert
        Assert.Null(algorithmSet);
    }

    [Fact]
    public async Task GetAlgorithmsFromAllSets_OLLCategory_ShouldReturnOLLAlgorithms()
    {
        // Arrange
        await _database.LoadFromConfig(_testConfigPath);

        // Act
        var ollAlgorithms = _database.GetAlgorithmsFromAllSets("OLL").ToList();

        // Assert
        Assert.NotEmpty(ollAlgorithms);
        Assert.All(ollAlgorithms, algo => Assert.Equal("OLL", algo.Category));
        Assert.Contains(ollAlgorithms, algo => algo.Id == "oll-dot");
        Assert.Contains(ollAlgorithms, algo => algo.Id == "oll-line");
        Assert.Contains(ollAlgorithms, algo => algo.Id == "oll-cross");
        Assert.Contains(ollAlgorithms, algo => algo.Id == "oll-l-shape");
    }

    [Fact]
    public async Task GetAlgorithmsFromAllSets_PLLCategory_ShouldReturnPLLAlgorithms()
    {
        // Arrange
        await _database.LoadFromConfig(_testConfigPath);

        // Act
        var pllAlgorithms = _database.GetAlgorithmsFromAllSets("PLL").ToList();

        // Assert
        Assert.NotEmpty(pllAlgorithms);
        Assert.All(pllAlgorithms, algo => Assert.Equal("PLL", algo.Category));
        Assert.Contains(pllAlgorithms, algo => algo.Id == "pll-t-perm");
        Assert.Contains(pllAlgorithms, algo => algo.Id == "pll-aa-perm");
        Assert.Contains(pllAlgorithms, algo => algo.Id == "pll-ab-perm");
        Assert.Contains(pllAlgorithms, algo => algo.Id == "pll-h-perm");
    }

    [Fact]
    public async Task FindAlgorithmById_ValidId_ShouldReturnAlgorithm()
    {
        // Arrange
        await _database.LoadFromConfig(_testConfigPath);

        // Act
        var algorithm = _database.FindAlgorithmById("oll-dot");

        // Assert
        Assert.NotNull(algorithm);
        Assert.Equal("oll-dot", algorithm.Id);
        Assert.Equal("Dot OLL", algorithm.Name);
        Assert.Equal("F R U R' U' F' f R U R' U' f'", algorithm.AlgorithmSequence);
    }

    [Fact]
    public async Task FindAlgorithmById_InvalidId_ShouldReturnNull()
    {
        // Arrange
        await _database.LoadFromConfig(_testConfigPath);

        // Act
        var algorithm = _database.FindAlgorithmById("nonexistent-algorithm");

        // Assert
        Assert.Null(algorithm);
    }

    [Fact]
    public async Task SearchByPattern_ValidPattern_ShouldReturnMatchingAlgorithms()
    {
        // Arrange
        await _database.LoadFromConfig(_testConfigPath);

        // Act
        var algorithms = _database.SearchByPattern("dot").ToList();

        // Assert
        Assert.NotEmpty(algorithms);
        Assert.Contains(algorithms, algo => algo.Id == "oll-dot");
    }

    [Fact]
    public async Task SearchByText_ValidQuery_ShouldReturnMatchingAlgorithms()
    {
        // Arrange
        await _database.LoadFromConfig(_testConfigPath);

        // Act
        var algorithms = _database.SearchByText("t-perm").ToList();

        // Assert
        Assert.NotEmpty(algorithms);
        Assert.Contains(algorithms, algo => algo.Id == "pll-t-perm");
    }

    [Fact]
    public async Task SetAlgorithmSetEnabled_ValidSet_ShouldUpdateEnabled()
    {
        // Arrange
        await _database.LoadFromConfig(_testConfigPath);

        // Act
        var result = _database.SetAlgorithmSetEnabled("4lll", false);
        var algorithmSet = _database.GetAlgorithmSet("4lll");

        // Assert
        Assert.True(result.IsSuccess);
        Assert.NotNull(algorithmSet);
        Assert.False(algorithmSet.Enabled);
    }

    [Fact]
    public async Task SetAlgorithmSetEnabled_InvalidSet_ShouldFail()
    {
        // Arrange
        await _database.LoadFromConfig(_testConfigPath);

        // Act
        var result = _database.SetAlgorithmSetEnabled("nonexistent", false);

        // Assert
        Assert.True(result.IsFailure);
        Assert.Contains("Algorithm set 'nonexistent' not found", result.Error);
    }

    [Fact]
    public async Task GetConfiguration_AfterLoading_ShouldReturnConfig()
    {
        // Arrange
        await _database.LoadFromConfig(_testConfigPath);

        // Act
        var config = _database.GetConfiguration();

        // Assert
        Assert.NotNull(config);
        Assert.Equal("4lll", config.DefaultSet);
        Assert.Equal("", config.BaseDirectory);
        Assert.Contains("4lll", config.AlgorithmSets.Keys);
    }

    [Fact]
    public async Task Reload_AfterInitialLoad_ShouldSucceed()
    {
        // Arrange
        await _database.LoadFromConfig(_testConfigPath);
        var initialCount = _database.GetAlgorithmSets().Count();

        // Act
        var result = await _database.Reload();
        var newCount = _database.GetAlgorithmSets().Count();

        // Assert
        Assert.True(result.IsSuccess);
        Assert.Equal(initialCount, newCount);
    }
}