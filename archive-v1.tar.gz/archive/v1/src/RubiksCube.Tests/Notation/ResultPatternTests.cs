using RubiksCube.Core.Models;
using RubiksCube.Core.Notation;
using CSharpFunctionalExtensions;

namespace RubiksCube.Tests.Notation;

public class ResultPatternTests
{
    [Fact]
    public void ParseAlgorithm_WithValidInput_ShouldReturnSuccess()
    {
        var result = NotationParser.ParseAlgorithm("R U R' U'");
        
        Assert.True(result.IsSuccess);
        Assert.Equal(4, result.Value.Count);
        Assert.Equal("R", result.Value[0].ToString());
    }

    [Fact]
    public void ParseAlgorithm_WithInvalidInput_ShouldReturnFailure()
    {
        var result = NotationParser.ParseAlgorithm("R U X R'");
        
        Assert.True(result.IsFailure);
        Assert.Contains("Invalid move token: 'X'", result.Error);
    }

    [Fact]
    public void ParseAlgorithm_WithEmptyInput_ShouldReturnEmptySuccess()
    {
        var result = NotationParser.ParseAlgorithm("");
        
        Assert.True(result.IsSuccess);
        Assert.Empty(result.Value);
    }

    [Fact]
    public void CountMoves_WithValidInput_ShouldReturnSuccess()
    {
        var result = NotationParser.CountMoves("R U R' U'");
        
        Assert.True(result.IsSuccess);
        Assert.Equal(4, result.Value);
    }

    [Fact]
    public void CountMoves_WithInvalidInput_ShouldReturnFailure()
    {
        var result = NotationParser.CountMoves("R X U");
        
        Assert.True(result.IsFailure);
        Assert.Contains("Invalid move token", result.Error);
    }

    [Fact]
    public void NormalizeAlgorithm_WithValidInput_ShouldReturnSuccess()
    {
        var result = NotationParser.NormalizeAlgorithm("R  U   R'    U'");
        
        Assert.True(result.IsSuccess);
        Assert.Equal("R U R' U'", result.Value);
    }

    [Fact]
    public void NormalizeAlgorithm_WithInvalidInput_ShouldReturnFailure()
    {
        var result = NotationParser.NormalizeAlgorithm("R U Q");
        
        Assert.True(result.IsFailure);
        Assert.Contains("Invalid move token", result.Error);
    }

    [Fact]
    public void AlgorithmCreate_WithValidInput_ShouldReturnSuccess()
    {
        var result = Algorithm.Create("R U R' U'");
        
        Assert.True(result.IsSuccess);
        Assert.Equal("R U R' U'", result.Value.Sequence);
        Assert.Equal(4, result.Value.MoveCount);
    }

    [Fact]
    public void AlgorithmCreate_WithInvalidInput_ShouldReturnFailure()
    {
        var result = Algorithm.Create("R U Z");
        
        Assert.True(result.IsFailure);
        Assert.Contains("Invalid move token", result.Error);
    }

    [Fact]
    public void AlgorithmCreate_WithEmptyInput_ShouldReturnFailure()
    {
        var result = Algorithm.Create("");
        
        Assert.True(result.IsFailure);
        Assert.Contains("cannot be null or empty", result.Error);
    }

    [Fact]
    public void AlgorithmApplyTo_WithValidMoves_ShouldReturnSuccess()
    {
        var algorithm = new Algorithm("R U R' U'");
        var cube = new Cube();
        
        var result = algorithm.ApplyTo(cube);
        
        Assert.True(result.IsSuccess);
        Assert.False(cube.IsSolved()); // Should be scrambled after applying algorithm
    }

    [Fact]
    public void CubeApplyMove_WithValidMove_ShouldReturnSuccess()
    {
        var cube = new Cube();
        var move = new Move(CubeFace.Right, MoveType.Clockwise);
        
        var result = cube.ApplyMove(move);
        
        Assert.True(result.IsSuccess);
        Assert.False(cube.IsSolved());
    }

    [Fact]
    public void ResultPattern_CanBeChained_WithMap()
    {
        var result = NotationParser.ParseAlgorithm("R U R' U'")
            .Map(moves => moves.Count)
            .Map(count => count * 2);
        
        Assert.True(result.IsSuccess);
        Assert.Equal(8, result.Value);
    }

    [Fact]
    public void ResultPattern_FailureStopsChain_WithMap()
    {
        var result = NotationParser.ParseAlgorithm("R U X")
            .Map(moves => moves.Count)
            .Map(count => count * 2);
        
        Assert.True(result.IsFailure);
        Assert.Contains("Invalid move token", result.Error);
    }
}