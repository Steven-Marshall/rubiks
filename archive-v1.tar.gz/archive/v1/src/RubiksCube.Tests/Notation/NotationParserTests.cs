using RubiksCube.Core.Models;
using RubiksCube.Core.Notation;

namespace RubiksCube.Tests.Notation;

public class NotationParserTests
{
    [Theory]
    [InlineData("R U R' U'", 4)]
    [InlineData("R U2 R' D'", 4)]
    [InlineData("F R U R' U' F'", 6)]
    [InlineData("R", 1)]
    [InlineData("", 0)]
    [InlineData("   ", 0)]
    public void ParseAlgorithm_ShouldReturnCorrectMoveCount(string algorithm, int expectedCount)
    {
        var moves = NotationParser.ParseAlgorithmUnsafe(algorithm);
        Assert.Equal(expectedCount, moves.Count);
    }

    [Fact]
    public void ParseAlgorithm_ShouldReturnCorrectMoves()
    {
        var moves = NotationParser.ParseAlgorithmUnsafe("R U R' U'");
        
        Assert.Equal(4, moves.Count);
        Assert.Equal(CubeFace.Right, moves[0].Face);
        Assert.Equal(MoveType.Clockwise, moves[0].Type);
        Assert.Equal(CubeFace.Up, moves[1].Face);
        Assert.Equal(MoveType.Clockwise, moves[1].Type);
        Assert.Equal(CubeFace.Right, moves[2].Face);
        Assert.Equal(MoveType.CounterClockwise, moves[2].Type);
        Assert.Equal(CubeFace.Up, moves[3].Face);
        Assert.Equal(MoveType.CounterClockwise, moves[3].Type);
    }

    [Theory]
    [InlineData("R U R' {Sune}", "R U R'")]
    [InlineData("R U R' {cross complete} U2", "R U R' U2")]
    [InlineData("{start} R U {middle} R' {end}", "R U R'")]
    [InlineData("R {comment with spaces} U", "R U")]
    [InlineData("R U R'", "R U R'")]  // No metadata to remove
    public void FilterMetadata_ShouldRemoveBracedContent(string input, string expected)
    {
        var result = NotationParser.FilterMetadata(input);
        Assert.Equal(expected, result);
    }

    [Theory]
    [InlineData("(R U R' U')", "R U R' U'")]
    [InlineData("(R U) (R' U')", "R U R' U'")]
    [InlineData("R (U R') U'", "R U R' U'")]
    public void FilterMetadata_ShouldRemoveParentheses(string input, string expected)
    {
        var result = NotationParser.FilterMetadata(input);
        Assert.Equal(expected, result);
    }

    [Theory]
    [InlineData("R  U   R'    U'")]
    [InlineData("R\tU\nR'\rU'")]
    [InlineData("R,U,R',U'")]
    public void ParseAlgorithm_ShouldHandleVariousWhitespace(string algorithm)
    {
        var moves = NotationParser.ParseAlgorithmUnsafe(algorithm);
        
        Assert.Equal(4, moves.Count);
        Assert.Equal("R", moves[0].ToString());
        Assert.Equal("U", moves[1].ToString());
        Assert.Equal("R'", moves[2].ToString());
        Assert.Equal("U'", moves[3].ToString());
    }

    [Theory]
    [InlineData("R U R' U'")]
    [InlineData("F R U R' U' F'")]
    [InlineData("R U2 R' D' R U' R' D")]
    [InlineData("L' U R U' L U R'")]
    public void IsValidAlgorithm_WithValidInput_ShouldReturnTrue(string algorithm)
    {
        Assert.True(NotationParser.IsValidAlgorithm(algorithm));
    }

    [Theory]
    [InlineData("X U R")]     // Invalid face
    [InlineData("R3 U")]      // Invalid modifier
    [InlineData("R Q")]       // Invalid move
    [InlineData("R U Z")]     // Invalid face in middle
    public void IsValidAlgorithm_WithInvalidInput_ShouldReturnFalse(string algorithm)
    {
        Assert.False(NotationParser.IsValidAlgorithm(algorithm));
    }

    [Theory]
    [InlineData("R U R' U'", 4)]
    [InlineData("R U2 R' D'", 4)]
    [InlineData("", 0)]
    [InlineData("R", 1)]
    public void CountMoves_ShouldReturnCorrectCount(string algorithm, int expectedCount)
    {
        var count = NotationParser.CountMovesUnsafe(algorithm);
        Assert.Equal(expectedCount, count);
    }

    [Theory]
    [InlineData("R  U   R'    U'", "R U R' U'")]
    [InlineData("R\tU\nR'\rU'", "R U R' U'")]
    [InlineData("R {comment} U R' U'", "R U R' U'")]
    [InlineData("(R U) (R' U')", "R U R' U'")]
    public void NormalizeAlgorithm_ShouldCleanupFormat(string input, string expected)
    {
        var result = NotationParser.NormalizeAlgorithmUnsafe(input);
        Assert.Equal(expected, result);
    }

    [Fact]
    public void ParseAlgorithm_WithMixedValidAndInvalidMoves_ShouldThrowException()
    {
        var algorithm = "R U X R' U'";  // X is invalid
        
        Assert.ThrowsAny<Exception>(() => NotationParser.ParseAlgorithmUnsafe(algorithm));
    }

    [Theory]
    [InlineData("R U R' U'", false)]
    [InlineData("Rw U Rw'", true)]
    [InlineData("M E S", true)]
    [InlineData("R M U'", true)]
    [InlineData("F R U R' U' F'", false)]
    public void Advanced_ContainsWideOrSliceMoves_ShouldDetectCorrectly(string algorithm, bool expected)
    {
        var result = NotationParser.Advanced.ContainsWideOrSliceMoves(algorithm);
        Assert.Equal(expected, result);
    }

    [Theory]
    [InlineData("R U R' U'", false)]
    [InlineData("x R U R' U'", true)]
    [InlineData("R U y R' U'", true)]
    [InlineData("z' R U R'", true)]
    public void Advanced_ContainsRotations_ShouldDetectCorrectly(string algorithm, bool expected)
    {
        var result = NotationParser.Advanced.ContainsRotations(algorithm);
        Assert.Equal(expected, result);
    }
}