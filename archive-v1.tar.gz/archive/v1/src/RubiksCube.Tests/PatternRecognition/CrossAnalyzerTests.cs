using RubiksCube.Core.PatternRecognition;
using RubiksCube.Core.Models;
using RubiksCube.Core.Notation;
using Xunit;

namespace RubiksCube.Tests.PatternRecognition;

public class CrossAnalyzerTests
{
    private readonly CrossAnalyzer _analyzer = new();

    private static void ApplyAlgorithm(Cube cube, string algorithm)
    {
        if (string.IsNullOrEmpty(algorithm)) return;
        
        var movesResult = NotationParser.ParseAlgorithm(algorithm);
        if (movesResult.IsFailure)
            throw new ArgumentException($"Invalid algorithm: {algorithm}", nameof(algorithm));
        
        foreach (var move in movesResult.Value)
        {
            cube.ApplyMove(move);
        }
    }

    [Fact]
    public void AnalyzeCross_SolvedCube_ShouldReturnCompleteCross()
    {
        // Arrange
        var solvedCube = new Cube();

        // Act
        var result = _analyzer.AnalyzeCross(solvedCube);

        // Assert
        Assert.True(result.IsComplete);
        Assert.Equal(4, result.CompletedEdges);
        Assert.Equal(4, result.EdgeResults.Count);
        Assert.All(result.EdgeResults, edge => Assert.True(edge.IsComplete));
        Assert.Contains("complete", result.Description.ToLower());
    }

    [Fact]
    public void AnalyzeCross_ScrambledCube_ShouldReturnIncompleteCross()
    {
        // Arrange
        var scrambledCube = new Cube();
        // Use F2 which definitely moves the front cross edge to the top
        ApplyAlgorithm(scrambledCube, "F2");

        // Act
        var result = _analyzer.AnalyzeCross(scrambledCube);

        // Assert
        Assert.False(result.IsComplete);
        Assert.True(result.CompletedEdges < 4);
        Assert.Equal(4, result.EdgeResults.Count);
        Assert.Contains("edges complete", result.Description.ToLower());
    }

    [Fact]
    public void AnalyzeCrossEdge_SolvedCube_AllEdgesShouldBeComplete()
    {
        // Arrange
        var solvedCube = new Cube();
        var sideFaces = new[] { CubeFace.Front, CubeFace.Right, CubeFace.Back, CubeFace.Left };
        var edgeNames = new[] { "Front", "Right", "Back", "Left" };

        // Act & Assert
        for (int i = 0; i < sideFaces.Length; i++)
        {
            var result = _analyzer.AnalyzeCrossEdge(solvedCube, sideFaces[i], edgeNames[i]);
            
            Assert.True(result.IsComplete, $"{edgeNames[i]} edge should be complete");
            Assert.Equal("Complete", result.Status);
            Assert.Equal(edgeNames[i], result.EdgeName);
            Assert.Equal(sideFaces[i], result.SideFace);
        }
    }

    [Fact]
    public void AnalyzeCrossEdge_SingleMoveFromSolved_ShouldDetectIncompleteEdge()
    {
        // Arrange
        var cube = new Cube();
        ApplyAlgorithm(cube, "F"); // F move affects front cross edge

        // Act
        var frontEdge = _analyzer.AnalyzeCrossEdge(cube, CubeFace.Front, "Front");

        // Assert
        // Front edge should be affected by F move
        Assert.False(frontEdge.IsComplete, 
            "Front edge should be incomplete after F move");
    }

    [Fact]
    public void AnalyzeCross_EdgeResults_ShouldContainCorrectInformation()
    {
        // Arrange
        var cube = new Cube();
        ApplyAlgorithm(cube, "F"); // Single F move

        // Act
        var result = _analyzer.AnalyzeCross(cube);

        // Assert
        Assert.Equal(4, result.EdgeResults.Count);
        
        foreach (var edge in result.EdgeResults)
        {
            Assert.NotNull(edge.EdgeName);
            Assert.True(Enum.IsDefined(edge.SideFace));
            Assert.NotNull(edge.Status);
            Assert.True(Enum.IsDefined(edge.BottomColor));
            Assert.True(Enum.IsDefined(edge.SideColor));
            Assert.True(Enum.IsDefined(edge.ExpectedBottomColor));
            Assert.True(Enum.IsDefined(edge.ExpectedSideColor));
        }
    }

    [Fact]
    public void AnalyzeCross_PartialCross_ShouldReportCorrectCompletionCount()
    {
        // Arrange
        var cube = new Cube();
        // Apply moves that preserve some cross edges but break others
        ApplyAlgorithm(cube, "F2"); // This should preserve back edge but affect front

        // Act
        var result = _analyzer.AnalyzeCross(cube);

        // Assert
        Assert.False(result.IsComplete);
        Assert.True(result.CompletedEdges >= 0 && result.CompletedEdges <= 4);
        Assert.Equal(4, result.EdgeResults.Count);
        
        var actualCompletedCount = result.EdgeResults.Count(e => e.IsComplete);
        Assert.Equal(result.CompletedEdges, actualCompletedCount);
    }

    // TODO: Implement and test FindMisplacedCrossEdges functionality
    // [Fact]
    // public void FindMisplacedCrossEdges_SolvedCube_ShouldReturnEmptyList()
    // {
    //     // Arrange
    //     var solvedCube = new Cube();

    //     // Act
    //     var result = _analyzer.FindMisplacedCrossEdges(solvedCube);

    //     // Assert
    //     Assert.True(result.IsSuccess);
    //     Assert.Empty(result.Value);
    // }

    // [Fact]
    // public void FindMisplacedCrossEdges_ScrambledCube_ShouldFindMisplacedEdges()
    // {
    //     // Arrange
    //     var scrambledCube = new Cube();
    //     ApplyAlgorithm(scrambledCube, "R U R' U'"); // Light scramble

    //     // Act
    //     var result = _analyzer.FindMisplacedCrossEdges(scrambledCube);

    //     // Assert
    //     Assert.True(result.IsSuccess);
    //     // Should find some misplaced edges (exact count depends on scramble)
    //     Assert.True(result.Value.Count >= 0);
        
    //     foreach (var misplacedEdge in result.Value)
    //     {
    //         Assert.NotEqual(misplacedEdge.CurrentLocation, misplacedEdge.TargetLocation);
    //         Assert.True(Enum.IsDefined(misplacedEdge.Color1));
    //         Assert.True(Enum.IsDefined(misplacedEdge.Color2));
    //     }
    // }

    [Theory]
    [InlineData("", 4)] // Solved cube should have 4 complete edges
    [InlineData("R", 2)] // R move should preserve left and back edges
    [InlineData("F", 2)] // F move should preserve right and left edges
    [InlineData("R U R' U'", 0)] // More complex scramble, likely 0 complete edges
    public void AnalyzeCross_VariousStates_ShouldReturnExpectedCompletionRange(string algorithm, int expectedMinComplete)
    {
        // Arrange
        var cube = new Cube();
        ApplyAlgorithm(cube, algorithm);

        // Act
        var result = _analyzer.AnalyzeCross(cube);

        // Assert
        if (algorithm == "")
        {
            // Solved cube should have exactly 4 complete edges
            Assert.Equal(4, result.CompletedEdges);
            Assert.True(result.IsComplete);
        }
        else
        {
            // For scrambled cubes, just verify the range makes sense
            Assert.True(result.CompletedEdges >= 0 && result.CompletedEdges <= 4);
            Assert.Equal(result.CompletedEdges == 4, result.IsComplete);
        }
    }

    [Fact]
    public void AnalyzeCross_Description_ShouldBeInformative()
    {
        // Arrange
        var cubes = new[]
        {
            (new Cube(), "solved"),
            (CreateCubeWithAlgorithm("R"), "single R move"),
            (CreateCubeWithAlgorithm("R U R' U'"), "scrambled")
        };

        // Act & Assert
        foreach (var (cube, description) in cubes)
        {
            var result = _analyzer.AnalyzeCross(cube);
            
            Assert.NotNull(result.Description);
            Assert.NotEmpty(result.Description);
            
            if (result.IsComplete)
            {
                Assert.Contains("complete", result.Description.ToLower());
            }
            else
            {
                Assert.Contains("edges complete", result.Description.ToLower());
                Assert.Contains($"{result.CompletedEdges}/4", result.Description);
            }
        }
    }

    [Fact]
    public void AnalyzeCrossEdge_EdgeStatusMessages_ShouldBeDescriptive()
    {
        // Arrange
        var testCases = new[]
        {
            (new Cube(), "Complete"),
            (CreateCubeWithAlgorithm("R"), "should have status"),
            (CreateCubeWithAlgorithm("F2"), "should have status")
        };

        // Act & Assert
        foreach (var (cube, expectedPattern) in testCases)
        {
            var frontEdge = _analyzer.AnalyzeCrossEdge(cube, CubeFace.Front, "Front");
            
            Assert.NotNull(frontEdge.Status);
            Assert.NotEmpty(frontEdge.Status);
            
            if (expectedPattern == "Complete")
            {
                Assert.Equal("Complete", frontEdge.Status);
            }
            else
            {
                // Status should be informative for incomplete edges
                Assert.True(frontEdge.Status.Length > 5, "Status should be descriptive");
            }
        }
    }

    [Fact]
    public void AnalyzeCross_ConsistentWithSimpleCfopAnalyzer_ForBasicStates()
    {
        // Arrange
        var simpleCfopAnalyzer = new SimpleCfopStateAnalyzer();
        var testCubes = new[]
        {
            new Cube(), // Solved
            CreateCubeWithAlgorithm("R U R' U'"), // Scrambled
        };

        // Act & Assert
        foreach (var cube in testCubes)
        {
            var crossResult = _analyzer.AnalyzeCross(cube);
            var cfopState = simpleCfopAnalyzer.AnalyzeState(cube);
            
            if (cfopState == CfopState.Solved)
            {
                Assert.True(crossResult.IsComplete, "Solved cube should have complete cross");
            }
            
            if (crossResult.IsComplete)
            {
                // If cross is complete, CFOP state should be at least Cross level
                Assert.True(cfopState >= CfopState.Cross, 
                    "Complete cross should indicate at least Cross state in CFOP");
            }
        }
    }

    private Cube CreateCubeWithAlgorithm(string algorithm)
    {
        var cube = new Cube();
        ApplyAlgorithm(cube, algorithm);
        return cube;
    }
}