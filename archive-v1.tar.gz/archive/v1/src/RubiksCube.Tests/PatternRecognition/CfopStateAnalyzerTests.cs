using RubiksCube.Core.PatternRecognition;
using RubiksCube.Core.Models;
using RubiksCube.Core.Notation;
using Xunit;

namespace RubiksCube.Tests.PatternRecognition;

public class CfopStateAnalyzerTests
{
    private readonly SimpleCfopStateAnalyzer _analyzer = new();

    private static void ApplyAlgorithm(Cube cube, string algorithm)
    {
        if (string.IsNullOrEmpty(algorithm)) return;
        
        var movesResult = NotationParser.ParseAlgorithm(algorithm);
        if (movesResult.IsFailure)
            throw new ArgumentException($"Invalid algorithm: {algorithm}", nameof(algorithm));
        
        foreach (var move in movesResult.Value)
        {
            cube.ApplyMove(move);
        }
    }

    [Fact]
    public void AnalyzeState_SolvedCube_ShouldReturnSolved()
    {
        // Arrange
        var solvedCube = new Cube();

        // Act
        var state = _analyzer.AnalyzeState(solvedCube);

        // Assert
        Assert.Equal(CfopState.Solved, state);
    }

    [Fact]
    public void AnalyzeState_ScrambledCube_ShouldReturnScrambled()
    {
        // Arrange
        var scrambledCube = new Cube();
        ApplyAlgorithm(scrambledCube, "R U R' U'");

        // Act
        var state = _analyzer.AnalyzeState(scrambledCube);

        // Assert
        Assert.Equal(CfopState.Scrambled, state);
    }

    [Fact]
    public void AnalyzeStep_CrossStep_SolvedCube_ShouldReturnCompleted()
    {
        // Arrange
        var solvedCube = new Cube();

        // Act
        var result = _analyzer.AnalyzeStep(solvedCube, CfopStep.Cross);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.True(result.Value.IsComplete);
        Assert.Equal(CfopStep.Cross, result.Value.Step);
    }

    [Fact]
    public void AnalyzeStep_F2lStep_CrossNotComplete_ShouldReturnNotStarted()
    {
        // Arrange
        var scrambledCube = new Cube();
        ApplyAlgorithm(scrambledCube, "R U R' U'");

        // Act
        var result = _analyzer.AnalyzeStep(scrambledCube, CfopStep.F2L);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.False(result.Value.IsComplete);
        Assert.Equal("Not started", result.Value.Progress);
        Assert.Contains("Cross must be completed first", result.Value.Description);
    }

    [Fact]
    public void AnalyzeStep_OllStep_F2lNotComplete_ShouldReturnNotStarted()
    {
        // Arrange
        var scrambledCube = new Cube();
        ApplyAlgorithm(scrambledCube, "R U R' U'");

        // Act
        var result = _analyzer.AnalyzeStep(scrambledCube, CfopStep.OLL);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.False(result.Value.IsComplete);
        Assert.Equal("Not started", result.Value.Progress);
        Assert.Contains("F2L must be completed first", result.Value.Description);
    }

    [Fact]
    public void AnalyzeStep_PllStep_OllNotComplete_ShouldReturnNotStarted()
    {
        // Arrange
        var scrambledCube = new Cube();
        ApplyAlgorithm(scrambledCube, "R U R' U'");

        // Act
        var result = _analyzer.AnalyzeStep(scrambledCube, CfopStep.PLL);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.False(result.Value.IsComplete);
        Assert.Equal("Not started", result.Value.Progress);
        Assert.Contains("OLL must be completed first", result.Value.Description);
    }

    [Fact]
    public void AnalyzeStep_InvalidStep_ShouldReturnFailure()
    {
        // Arrange
        var cube = new Cube();
        var invalidStep = (CfopStep)999;

        // Act
        var result = _analyzer.AnalyzeStep(cube, invalidStep);

        // Assert
        Assert.True(result.IsFailure);
        Assert.Contains("Unknown CFOP step", result.Error);
    }

    [Fact]
    public void GetProgress_SolvedCube_ShouldReturn100Percent()
    {
        // Arrange
        var solvedCube = new Cube();

        // Act
        var progress = _analyzer.GetProgress(solvedCube);

        // Assert
        Assert.Equal(CfopState.Solved, progress.CurrentState);
        Assert.Equal(100, progress.CompletionPercentage);
        Assert.Null(progress.NextStep);
        Assert.Contains("completely solved", progress.Summary);
    }

    [Fact]
    public void GetProgress_ScrambledCube_ShouldReturnLowPercentage()
    {
        // Arrange
        var scrambledCube = new Cube();
        ApplyAlgorithm(scrambledCube, "R U R' U' R' F R2 U' R'");

        // Act
        var progress = _analyzer.GetProgress(scrambledCube);

        // Assert
        Assert.Equal(CfopState.Scrambled, progress.CurrentState);
        Assert.True(progress.CompletionPercentage < 25);
        Assert.Equal(CfopStep.Cross, progress.NextStep);
        Assert.Contains("scrambled", progress.Summary.ToLower());
    }

    [Fact]
    public void GetProgress_ShouldIncludeAllStepResults()
    {
        // Arrange
        var cube = new Cube();

        // Act
        var progress = _analyzer.GetProgress(cube);

        // Assert
        Assert.Equal(4, progress.StepProgress.Count);
        Assert.Contains(CfopStep.Cross, progress.StepProgress.Keys);
        Assert.Contains(CfopStep.F2L, progress.StepProgress.Keys);
        Assert.Contains(CfopStep.OLL, progress.StepProgress.Keys);
        Assert.Contains(CfopStep.PLL, progress.StepProgress.Keys);
    }

    [Fact]
    public void GetProgress_CompletedSteps_ShouldBeMarkedAsCompleted()
    {
        // Arrange
        var solvedCube = new Cube();

        // Act
        var progress = _analyzer.GetProgress(solvedCube);

        // Assert
        Assert.True(progress.IsStepComplete(CfopStep.Cross));
        Assert.True(progress.IsStepComplete(CfopStep.F2L));
        Assert.True(progress.IsStepComplete(CfopStep.OLL));
        Assert.True(progress.IsStepComplete(CfopStep.PLL));
    }

    [Fact]
    public void GetProgress_IncompleteSteps_ShouldNotBeMarkedAsCompleted()
    {
        // Arrange
        var scrambledCube = new Cube();
        ApplyAlgorithm(scrambledCube, "R U R' U'");

        // Act
        var progress = _analyzer.GetProgress(scrambledCube);

        // Assert
        Assert.False(progress.IsStepComplete(CfopStep.Cross));
        Assert.False(progress.IsStepComplete(CfopStep.F2L));
        Assert.False(progress.IsStepComplete(CfopStep.OLL));
        Assert.False(progress.IsStepComplete(CfopStep.PLL));
    }

    [Theory]
    [InlineData("R U R' U'", CfopState.Scrambled)]
    [InlineData("", CfopState.Solved)]
    public void AnalyzeState_VariousScrambles_ShouldReturnExpectedState(string moves, CfopState expectedState)
    {
        // Arrange
        var cube = new Cube();
        if (!string.IsNullOrEmpty(moves))
        {
            ApplyAlgorithm(cube, moves);
        }

        // Act
        var actualState = _analyzer.AnalyzeState(cube);

        // Assert
        Assert.Equal(expectedState, actualState);
    }

    [Fact]
    public void AnalyzeStep_CrossStep_PartialCross_ShouldReturnProgress()
    {
        // Arrange - Create a cube with partial cross (this is a simplified test)
        var cube = new Cube();
        // Apply moves that break some but not all cross edges
        ApplyAlgorithm(cube, "R U R'");

        // Act
        var result = _analyzer.AnalyzeStep(cube, CfopStep.Cross);

        // Assert
        Assert.True(result.IsSuccess);
        // The exact result depends on the specific cube state after moves
        Assert.NotNull(result.Value.Description);
    }

    [Fact]
    public void GetProgress_ToString_ShouldIncludeStateAndPercentage()
    {
        // Arrange
        var cube = new Cube();
        var progress = _analyzer.GetProgress(cube);

        // Act
        var progressString = progress.ToString();

        // Assert
        Assert.Contains("Solved", progressString);
        Assert.Contains("100%", progressString);
    }

    [Fact]
    public void AnalyzeStep_AllSteps_SolvedCube_ShouldAllBeCompleted()
    {
        // Arrange
        var solvedCube = new Cube();

        // Act & Assert
        foreach (CfopStep step in Enum.GetValues<CfopStep>())
        {
            var result = _analyzer.AnalyzeStep(solvedCube, step);
            Assert.True(result.IsSuccess, $"Step {step} should succeed");
            Assert.True(result.Value.IsComplete, $"Step {step} should be completed");
        }
    }

    [Fact]
    public void GetProgress_StateProgression_ShouldShowIncreasingCompletion()
    {
        // Arrange
        var cubes = new[]
        {
            (CreateScrambledCube(), "scrambled"),
            (new Cube(), "solved")
        };

        var previousPercentage = -1;

        // Act & Assert
        foreach (var (cube, description) in cubes)
        {
            var progress = _analyzer.GetProgress(cube);
            Assert.True(progress.CompletionPercentage >= previousPercentage, 
                $"Progress should increase or stay same: {description} cube");
            previousPercentage = progress.CompletionPercentage;
        }
    }

    private Cube CreateScrambledCube()
    {
        var cube = new Cube();
        ApplyAlgorithm(cube, "R U R' U' R' F R2 U' R' U' R U R' F'");
        return cube;
    }
}