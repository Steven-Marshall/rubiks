using RubiksCube.Core.PatternRecognition;
using Xunit;

namespace RubiksCube.Tests.PatternRecognition;

public class PatternMatchTests
{
    [Fact]
    public void PatternMatch_Constructor_ShouldSetProperties()
    {
        // Arrange
        var pattern = "test-pattern";
        var confidence = 0.85;
        var description = "Test description";

        // Act
        var match = new PatternMatch<string>(pattern, confidence, description);

        // Assert
        Assert.Equal(pattern, match.Pattern);
        Assert.Equal(confidence, match.Confidence);
        Assert.Equal(description, match.Description);
        Assert.NotNull(match.Metadata);
        Assert.Empty(match.Metadata);
    }

    [Fact]
    public void PatternMatch_Perfect_ShouldCreatePerfectMatch()
    {
        // Arrange
        var pattern = "perfect-pattern";
        var description = "Perfect match";

        // Act
        var match = PatternMatch<string>.Perfect(pattern, description);

        // Assert
        Assert.Equal(pattern, match.Pattern);
        Assert.Equal(1.0, match.Confidence);
        Assert.Equal(description, match.Description);
    }

    [Fact]
    public void PatternMatch_Partial_ShouldCreatePartialMatch()
    {
        // Arrange
        var pattern = "partial-pattern";
        var confidence = 0.6;
        var description = "Partial match";

        // Act
        var match = PatternMatch<string>.Partial(pattern, confidence, description);

        // Assert
        Assert.Equal(pattern, match.Pattern);
        Assert.Equal(confidence, match.Confidence);
        Assert.Equal(description, match.Description);
    }

    [Fact]
    public void PatternMatch_ToString_ShouldIncludePatternAndConfidence()
    {
        // Arrange
        var pattern = "test-pattern";
        var confidence = 0.75;
        var match = new PatternMatch<string>(pattern, confidence);

        // Act
        var result = match.ToString();

        // Assert
        Assert.Contains(pattern, result);
        Assert.Contains("0.75", result);
        Assert.Contains("confidence", result);
    }

    [Fact]
    public void PatternMatch_Metadata_ShouldBeModifiable()
    {
        // Arrange
        var match = PatternMatch<string>.Perfect("test");

        // Act
        match.Metadata["key1"] = "value1";
        match.Metadata["key2"] = 42;

        // Assert
        Assert.Equal("value1", match.Metadata["key1"]);
        Assert.Equal(42, match.Metadata["key2"]);
        Assert.Equal(2, match.Metadata.Count);
    }
}