using RubiksCube.Core.PatternRecognition;
using Xunit;

namespace RubiksCube.Tests.PatternRecognition;

public class CfopProgressTests
{
    [Fact]
    public void CfopProgress_Constructor_ShouldSetProperties()
    {
        // Arrange
        var currentState = CfopState.Cross;
        var stepProgress = new Dictionary<CfopStep, StepAnalysisResult>
        {
            { CfopStep.Cross, StepAnalysisResult.InProgress(CfopStep.Cross, "2/4", "Two edges") }
        };
        var completionPercentage = 25;
        var nextStep = CfopStep.Cross;
        var summary = "Cross in progress";

        // Act
        var progress = new CfopProgress(currentState, stepProgress, completionPercentage, nextStep, summary);

        // Assert
        Assert.Equal(currentState, progress.CurrentState);
        Assert.Equal(stepProgress, progress.StepProgress);
        Assert.Equal(completionPercentage, progress.CompletionPercentage);
        Assert.Equal(nextStep, progress.NextStep);
        Assert.Equal(summary, progress.Summary);
    }

    [Fact]
    public void CfopProgress_GetStepResult_ShouldReturnCorrectResult()
    {
        // Arrange
        var crossResult = StepAnalysisResult.Completed(CfopStep.Cross);
        var f2lResult = StepAnalysisResult.InProgress(CfopStep.F2L, "1/4", "One pair");
        
        var stepProgress = new Dictionary<CfopStep, StepAnalysisResult>
        {
            { CfopStep.Cross, crossResult },
            { CfopStep.F2L, f2lResult }
        };
        
        var progress = new CfopProgress(CfopState.F2L, stepProgress, 50, CfopStep.F2L, "F2L in progress");

        // Act & Assert
        Assert.Equal(crossResult, progress.GetStepResult(CfopStep.Cross));
        Assert.Equal(f2lResult, progress.GetStepResult(CfopStep.F2L));
        Assert.Null(progress.GetStepResult(CfopStep.OLL));
    }

    [Fact]
    public void CfopProgress_IsStepComplete_ShouldReturnCorrectValue()
    {
        // Arrange
        var stepProgress = new Dictionary<CfopStep, StepAnalysisResult>
        {
            { CfopStep.Cross, StepAnalysisResult.Completed(CfopStep.Cross) },
            { CfopStep.F2L, StepAnalysisResult.InProgress(CfopStep.F2L, "2/4", "Two pairs") }
        };
        
        var progress = new CfopProgress(CfopState.F2L, stepProgress, 60, CfopStep.F2L, "F2L in progress");

        // Act & Assert
        Assert.True(progress.IsStepComplete(CfopStep.Cross));
        Assert.False(progress.IsStepComplete(CfopStep.F2L));
        Assert.False(progress.IsStepComplete(CfopStep.OLL));
    }

    [Fact]
    public void CfopProgress_ToString_ShouldIncludeStateAndPercentage()
    {
        // Arrange
        var progress = new CfopProgress(
            CfopState.Cross, 
            new Dictionary<CfopStep, StepAnalysisResult>(), 
            25, 
            CfopStep.Cross, 
            "Working on cross"
        );

        // Act
        var toString = progress.ToString();

        // Assert
        Assert.Contains("Cross", toString);
        Assert.Contains("25%", toString);
        Assert.Contains("Working on cross", toString);
    }

    [Fact]
    public void CfopProgress_WithNoNextStep_ShouldHandleNull()
    {
        // Arrange
        var progress = new CfopProgress(
            CfopState.Solved, 
            new Dictionary<CfopStep, StepAnalysisResult>(), 
            100, 
            null, // No next step when solved
            "Cube is solved"
        );

        // Act & Assert
        Assert.Equal(CfopState.Solved, progress.CurrentState);
        Assert.Null(progress.NextStep);
        Assert.Equal(100, progress.CompletionPercentage);
    }
}