using RubiksCube.Core.PatternRecognition;
using RubiksCube.Core.Models;
using RubiksCube.Core.Notation;
using Xunit;

namespace RubiksCube.Tests.PatternRecognition;

public class CrossSolverTests
{
    private readonly CrossSolver _solver = new();
    private readonly CrossAnalyzer _analyzer = new();

    private static void ApplyAlgorithm(Cube cube, string algorithm)
    {
        if (string.IsNullOrEmpty(algorithm)) return;
        
        var movesResult = NotationParser.ParseAlgorithm(algorithm);
        if (movesResult.IsFailure)
            throw new ArgumentException($"Invalid algorithm: {algorithm}", nameof(algorithm));
        
        foreach (var move in movesResult.Value)
        {
            cube.ApplyMove(move);
        }
    }

    [Fact]
    public void Solve_SolvedCube_ShouldReturnEmptyAlgorithm()
    {
        // Arrange
        var solvedCube = new Cube();

        // Act
        var result = _solver.Solve(solvedCube);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.Empty(result.Value.Moves);
        
        // Verify cross is still complete
        var crossAnalysis = _analyzer.AnalyzeCross(solvedCube);
        Assert.True(crossAnalysis.IsComplete);
    }

    [Fact]
    public void Solve_SingleEdgeDisrupted_ShouldRestoreCross()
    {
        // Arrange
        var cube = new Cube();
        ApplyAlgorithm(cube, "F"); // Disrupts front cross edge

        // Verify cross is broken
        var initialAnalysis = _analyzer.AnalyzeCross(cube);
        Assert.False(initialAnalysis.IsComplete);

        // Act
        var result = _solver.Solve(cube);

        // Assert
        Assert.True(result.IsSuccess, $"Solver failed with error: {(result.IsFailure ? result.Error : "Unknown")}");
        Assert.NotEmpty(result.Value.Moves);
        
        // Apply solution and verify cross is fixed
        ApplyAlgorithm(cube, result.Value.ToString());
        var finalAnalysis = _analyzer.AnalyzeCross(cube);
        Assert.True(finalAnalysis.IsComplete);
    }

    [Fact]
    public void Solve_MultipleEdgesDisrupted_ShouldRestoreCross()
    {
        // Arrange
        var cube = new Cube();
        ApplyAlgorithm(cube, "F R U' R' F'"); // Disrupts multiple cross edges

        // Verify cross is broken
        var initialAnalysis = _analyzer.AnalyzeCross(cube);
        Assert.False(initialAnalysis.IsComplete);

        // Act
        var result = _solver.Solve(cube);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.NotEmpty(result.Value.Moves);
        
        // Apply solution and verify cross is fixed
        ApplyAlgorithm(cube, result.Value.ToString());
        var finalAnalysis = _analyzer.AnalyzeCross(cube);
        Assert.True(finalAnalysis.IsComplete);
    }

    [Fact]
    public void Solve_ScrambledCube_ShouldSolveCrossWithinMoveLimit()
    {
        // Arrange
        var cube = new Cube();
        ApplyAlgorithm(cube, "R U R' U' R' F R2 U' R' U' R U R' F'"); // Standard scramble

        // Act
        var result = _solver.Solve(cube);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.True(result.Value.Moves.Count <= 8, 
            $"Cross solution should be 8 moves or less, got {result.Value.Moves.Count}");
        
        // Apply solution and verify cross is complete
        ApplyAlgorithm(cube, result.Value.ToString());
        var finalAnalysis = _analyzer.AnalyzeCross(cube);
        Assert.True(finalAnalysis.IsComplete);
        Assert.Equal(4, finalAnalysis.CompletedEdges);
    }

    [Theory]
    [InlineData("F")]
    [InlineData("R")]
    [InlineData("U")]
    [InlineData("F R")]
    [InlineData("R U R'")]
    [InlineData("F U F' U'")]
    public void Solve_VariousDisruptions_ShouldAlwaysSolveCross(string disruptionMoves)
    {
        // Arrange
        var cube = new Cube();
        ApplyAlgorithm(cube, disruptionMoves);

        // Act
        var result = _solver.Solve(cube);

        // Assert
        Assert.True(result.IsSuccess, $"Failed to solve cross after moves: {disruptionMoves}");
        
        // Apply solution and verify
        ApplyAlgorithm(cube, result.Value.ToString());
        var analysis = _analyzer.AnalyzeCross(cube);
        Assert.True(analysis.IsComplete, 
            $"Cross not complete after solving disruption: {disruptionMoves}");
    }

    [Fact]
    public void Solve_WithDifferentSolvingLevels_ShouldReturnValidSolutions()
    {
        // Arrange
        var cube = new Cube();
        ApplyAlgorithm(cube, "F R U");

        // Act
        var beginnerResult = _solver.Solve(cube, SolvingLevel.Beginner);
        var efficientResult = _solver.Solve(cube, SolvingLevel.Efficient);
        var optimalResult = _solver.Solve(cube, SolvingLevel.Optimal);

        // Assert
        Assert.True(beginnerResult.IsSuccess);
        Assert.True(efficientResult.IsSuccess);
        Assert.True(optimalResult.IsSuccess);

        // Optimal should be shortest or equal to others
        Assert.True(optimalResult.Value.Moves.Count <= efficientResult.Value.Moves.Count);
        Assert.True(optimalResult.Value.Moves.Count <= beginnerResult.Value.Moves.Count);

        // All should solve the cross
        foreach (var result in new[] { beginnerResult, efficientResult, optimalResult })
        {
            var testCube = new Cube();
            ApplyAlgorithm(testCube, "F R U");
            ApplyAlgorithm(testCube, result.Value.ToString());
            
            var analysis = _analyzer.AnalyzeCross(testCube);
            Assert.True(analysis.IsComplete);
        }
    }

    [Fact]
    public void Solve_OptimalLevel_ShouldNotExceedEightMoves()
    {
        // Test multiple scrambles to ensure optimal solver respects 8-move limit
        var scrambles = new[]
        {
            "R U R' U'",
            "F R U' R' F'",
            "R U2 R' U' R U' R'",
            "F U F' R U R'",
            "L U L' F U F'"
        };

        foreach (var scramble in scrambles)
        {
            // Arrange
            var cube = new Cube();
            ApplyAlgorithm(cube, scramble);

            // Act
            var result = _solver.Solve(cube, SolvingLevel.Optimal);

            // Assert
            Assert.True(result.IsSuccess, $"Failed to solve scramble: {scramble}");
            Assert.True(result.Value.Moves.Count <= 8, 
                $"Optimal solution exceeded 8 moves for scramble '{scramble}': got {result.Value.Moves.Count}");
            
            // Verify solution works
            ApplyAlgorithm(cube, result.Value.ToString());
            var analysis = _analyzer.AnalyzeCross(cube);
            Assert.True(analysis.IsComplete, $"Cross not solved for scramble: {scramble}");
        }
    }

    [Fact]
    public void Solve_PartialCross_ShouldCompleteRemainingEdges()
    {
        // Arrange - create a cube with partial cross (some edges already correct)
        var cube = new Cube();
        ApplyAlgorithm(cube, "F"); // Only disrupts front edge, others should remain

        var initialAnalysis = _analyzer.AnalyzeCross(cube);
        var initialCompleteEdges = initialAnalysis.CompletedEdges;

        // Act
        var result = _solver.Solve(cube);

        // Assert
        Assert.True(result.IsSuccess);
        
        // Solution should be efficient since some edges are already correct
        Assert.True(result.Value.Moves.Count <= 6, 
            "Partial cross solution should be efficient");
        
        // Apply and verify
        ApplyAlgorithm(cube, result.Value.ToString());
        var finalAnalysis = _analyzer.AnalyzeCross(cube);
        Assert.True(finalAnalysis.IsComplete);
        Assert.True(finalAnalysis.CompletedEdges > initialCompleteEdges);
    }

    [Fact]
    public void Solve_InvalidCube_ShouldReturnFailure()
    {
        // Arrange - create an impossible cube state (this would require modifying cube internals)
        // For now, test with null cube
        Cube invalidCube = null;

        // Act & Assert
        Assert.Throws<ArgumentNullException>(() => _solver.Solve(invalidCube));
    }

    [Fact]
    public void Solve_Result_ShouldContainValidAlgorithm()
    {
        // Arrange
        var cube = new Cube();
        ApplyAlgorithm(cube, "R U R'");

        // Act
        var result = _solver.Solve(cube);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.NotNull(result.Value);
        Assert.NotNull(result.Value.Moves);
        Assert.All(result.Value.Moves, move => 
        {
            Assert.True(Enum.IsDefined(move.Face));
            Assert.True(Enum.IsDefined(move.Type));
        });
        
        // Algorithm should be valid Singmaster notation
        var algorithmString = result.Value.ToString();
        Assert.NotEmpty(algorithmString);
        
        // Should be parseable back
        var parseResult = NotationParser.ParseAlgorithm(algorithmString);
        Assert.True(parseResult.IsSuccess);
    }

    [Fact]
    public void Solve_ConsistentResults_ShouldProduceSameResultForSameInput()
    {
        // Arrange
        var cube1 = new Cube();
        var cube2 = new Cube();
        ApplyAlgorithm(cube1, "F R U");
        ApplyAlgorithm(cube2, "F R U");

        // Act
        var result1 = _solver.Solve(cube1);
        var result2 = _solver.Solve(cube2);

        // Assert
        Assert.True(result1.IsSuccess);
        Assert.True(result2.IsSuccess);
        
        // Results should be identical for same input
        Assert.Equal(result1.Value.ToString(), result2.Value.ToString());
    }

    [Fact]
    public void Solve_EfficiencyComparison_OptimalShouldBeBestOrEqual()
    {
        // Test that optimal solver produces solutions that are equal or better than efficient solver
        var testCases = new[] { "R U R'", "F U F'", "R U' R' F U F'" };

        foreach (var scramble in testCases)
        {
            // Arrange
            var cube1 = new Cube();
            var cube2 = new Cube();
            ApplyAlgorithm(cube1, scramble);
            ApplyAlgorithm(cube2, scramble);

            // Act
            var efficientResult = _solver.Solve(cube1, SolvingLevel.Efficient);
            var optimalResult = _solver.Solve(cube2, SolvingLevel.Optimal);

            // Assert
            Assert.True(efficientResult.IsSuccess);
            Assert.True(optimalResult.IsSuccess);
            
            // Optimal should be equal or better
            Assert.True(optimalResult.Value.Moves.Count <= efficientResult.Value.Moves.Count,
                $"Optimal solver should be equal or better than efficient for scramble: {scramble}");
        }
    }

    [Fact]
    public void Solve_PreservesNonCrossState_ShouldNotDisruptSolvedPieces()
    {
        // This test verifies that cross solving doesn't unnecessarily disrupt
        // other parts of the cube that are already solved
        
        // Arrange - start with solved cube and make minimal disruption
        var cube = new Cube();
        ApplyAlgorithm(cube, "F2"); // F2 only affects front cross edge but is symmetric

        // Act
        var result = _solver.Solve(cube);

        // Assert
        Assert.True(result.IsSuccess);
        
        // Apply solution
        ApplyAlgorithm(cube, result.Value.ToString());
        
        // Cross should be solved
        var crossAnalysis = _analyzer.AnalyzeCross(cube);
        Assert.True(crossAnalysis.IsComplete);
        
        // Verify we haven't unnecessarily scrambled the cube
        // (This is a heuristic - solution should be reasonably short for simple disruption)
        Assert.True(result.Value.Moves.Count <= 4, 
            "Simple F2 disruption should have short solution");
    }

    private Cube CreateCubeWithAlgorithm(string algorithm)
    {
        var cube = new Cube();
        ApplyAlgorithm(cube, algorithm);
        return cube;
    }
}