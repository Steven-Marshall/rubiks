using RubiksCube.Core.PatternRecognition;
using Xunit;

namespace RubiksCube.Tests.PatternRecognition;

public class StepAnalysisResultTests
{
    [Fact]
    public void StepAnalysisResult_Constructor_ShouldSetProperties()
    {
        // Arrange
        var step = CfopStep.Cross;
        var isComplete = true;
        var progress = "4/4";
        var description = "Cross complete";

        // Act
        var result = new StepAnalysisResult(step, isComplete, progress, description);

        // Assert
        Assert.Equal(step, result.Step);
        Assert.Equal(isComplete, result.IsComplete);
        Assert.Equal(progress, result.Progress);
        Assert.Equal(description, result.Description);
        Assert.NotNull(result.StepData);
        Assert.Empty(result.StepData);
    }

    [Fact]
    public void StepAnalysisResult_Completed_ShouldCreateCompletedResult()
    {
        // Arrange
        var step = CfopStep.F2L;
        var description = "All pairs solved";

        // Act
        var result = StepAnalysisResult.Completed(step, description);

        // Assert
        Assert.Equal(step, result.Step);
        Assert.True(result.IsComplete);
        Assert.Equal("Complete", result.Progress);
        Assert.Equal(description, result.Description);
    }

    [Fact]
    public void StepAnalysisResult_InProgress_ShouldCreateInProgressResult()
    {
        // Arrange
        var step = CfopStep.Cross;
        var progress = "2/4";
        var description = "Two edges placed";

        // Act
        var result = StepAnalysisResult.InProgress(step, progress, description);

        // Assert
        Assert.Equal(step, result.Step);
        Assert.False(result.IsComplete);
        Assert.Equal(progress, result.Progress);
        Assert.Equal(description, result.Description);
    }

    [Fact]
    public void StepAnalysisResult_ToString_ShouldIncludeStepAndProgress()
    {
        // Arrange
        var step = CfopStep.OLL;
        var progress = "In Progress";
        var result = new StepAnalysisResult(step, false, progress, "");

        // Act
        var toString = result.ToString();

        // Assert
        Assert.Contains("OLL", toString);
        Assert.Contains(progress, toString);
    }

    [Fact]
    public void StepAnalysisResult_StepData_ShouldBeModifiable()
    {
        // Arrange
        var result = StepAnalysisResult.InProgress(CfopStep.Cross, "1/4", "One edge");

        // Act
        result.StepData["edgesPlaced"] = 1;
        result.StepData["nextEdge"] = "FR";

        // Assert
        Assert.Equal(1, result.StepData["edgesPlaced"]);
        Assert.Equal("FR", result.StepData["nextEdge"]);
        Assert.Equal(2, result.StepData.Count);
    }
}