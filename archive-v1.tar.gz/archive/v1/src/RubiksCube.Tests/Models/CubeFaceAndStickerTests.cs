using RubiksCube.Core.Models;
using RubiksCube.Tests.TestHelpers;
using Xunit;

namespace RubiksCube.Tests.Models;

/// <summary>
/// Tests for basic face and sticker operations
/// </summary>
public class CubeFaceAndStickerTests
{
    [Fact]
    public void GetFace_ShouldReturnCorrectColors_ForSolvedCube()
    {
        // Arrange
        var cube = new Cube();

        // Act & Assert
        foreach (CubeFace face in Enum.GetValues<CubeFace>())
        {
            var faceColors = cube.GetFace(face);
            var expectedColor = TestHelpers.TestHelpers.GetSolvedFaceColor(face);
            
            Assert.Equal(9, faceColors.Length);
            Assert.All(faceColors, color => Assert.Equal(expectedColor, color));
        }
    }

    [Fact]
    public void SetFace_ShouldUpdateAllStickers_OnTargetFace()
    {
        // Arrange
        var cube = new Cube();
        var newColors = TestHelpers.TestHelpers.CreateSolvedFace(CubeColor.Red);

        // Act
        cube.SetFace(CubeFace.Front, newColors);

        // Assert
        var frontFace = cube.GetFace(CubeFace.Front);
        Assert.All(frontFace, color => Assert.Equal(CubeColor.Red, color));
        
        // Other faces should be unchanged
        var backFace = cube.GetFace(CubeFace.Back);
        Assert.All(backFace, color => Assert.Equal(TestHelpers.TestHelpers.StandardColors.Back, color));
    }

    [Fact]
    public void SetFace_ShouldThrowException_ForInvalidColorCount()
    {
        // Arrange
        var cube = new Cube();
        var invalidColors = new CubeColor[8]; // Should be 9

        // Act & Assert
        Assert.Throws<ArgumentException>(() => cube.SetFace(CubeFace.Front, invalidColors));
    }

    [Theory]
    [InlineData(0)]  // Top-left corner
    [InlineData(1)]  // Top edge
    [InlineData(2)]  // Top-right corner
    [InlineData(3)]  // Left edge
    [InlineData(4)]  // Center
    [InlineData(5)]  // Right edge
    [InlineData(6)]  // Bottom-left corner
    [InlineData(7)]  // Bottom edge
    [InlineData(8)]  // Bottom-right corner
    public void GetSticker_ShouldReturnCorrectColor_ForAllPositions(int position)
    {
        // Arrange
        var cube = new Cube();
        var face = CubeFace.Front;
        var expectedColor = TestHelpers.TestHelpers.StandardColors.Front;

        // Act
        var actualColor = cube.GetSticker(face, position);

        // Assert
        Assert.Equal(expectedColor, actualColor);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(4)]
    [InlineData(8)]
    public void SetSticker_ShouldUpdateSpecificPosition_WithoutAffectingOthers(int position)
    {
        // Arrange
        var cube = new Cube();
        var targetColor = CubeColor.Red;

        // Act
        cube.SetSticker(CubeFace.Front, position, targetColor);

        // Assert
        Assert.Equal(targetColor, cube.GetSticker(CubeFace.Front, position));
        
        // Check other positions on same face are unchanged
        for (int i = 0; i < 9; i++)
        {
            if (i != position)
            {
                Assert.Equal(TestHelpers.TestHelpers.StandardColors.Front, cube.GetSticker(CubeFace.Front, i));
            }
        }
        
        // Check other faces are unchanged
        foreach (CubeFace otherFace in Enum.GetValues<CubeFace>())
        {
            if (otherFace != CubeFace.Front)
            {
                var faceColors = cube.GetFace(otherFace);
                var expectedColor = TestHelpers.TestHelpers.GetSolvedFaceColor(otherFace);
                Assert.All(faceColors, color => Assert.Equal(expectedColor, color));
            }
        }
    }

    [Fact]
    public void GetSticker_ShouldThrowException_ForInvalidPosition()
    {
        // Arrange
        var cube = new Cube();

        // Act & Assert
        Assert.Throws<ArgumentOutOfRangeException>(() => cube.GetSticker(CubeFace.Front, -1));
        Assert.Throws<ArgumentOutOfRangeException>(() => cube.GetSticker(CubeFace.Front, 9));
        Assert.Throws<ArgumentOutOfRangeException>(() => cube.GetSticker(CubeFace.Front, 100));
    }

    [Fact]
    public void SetSticker_ShouldThrowException_ForInvalidPosition()
    {
        // Arrange
        var cube = new Cube();

        // Act & Assert
        Assert.Throws<ArgumentOutOfRangeException>(() => cube.SetSticker(CubeFace.Front, -1, CubeColor.Red));
        Assert.Throws<ArgumentOutOfRangeException>(() => cube.SetSticker(CubeFace.Front, 9, CubeColor.Red));
    }

    [Fact]
    public void FaceToColorMapping_ShouldMatchCorrectedColorScheme()
    {
        // Arrange
        var cube = new Cube();

        // Act & Assert - Verify the corrected color scheme
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Front, 4));
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Back, 4));
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Right, 4));  // CORRECTED
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Left, 4));      // CORRECTED
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Up, 4));
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Down, 4));
    }

    [Fact]
    public void GetColorForFace_ShouldReturnCorrectMappings()
    {
        // Act & Assert - Test the static mapping method
        Assert.Equal("Green", Cube.GetColorForFace(CubeFace.Front));
        Assert.Equal("Blue", Cube.GetColorForFace(CubeFace.Back));
        Assert.Equal("Orange", Cube.GetColorForFace(CubeFace.Right));  // CORRECTED
        Assert.Equal("Red", Cube.GetColorForFace(CubeFace.Left));      // CORRECTED
        Assert.Equal("Yellow", Cube.GetColorForFace(CubeFace.Up));
        Assert.Equal("White", Cube.GetColorForFace(CubeFace.Down));
    }

    [Fact]
    public void GetFaceForColor_ShouldReturnCorrectMappings()
    {
        // Act & Assert - Test the reverse mapping
        Assert.Equal(CubeFace.Front, Cube.GetFaceForColor("Green"));
        Assert.Equal(CubeFace.Back, Cube.GetFaceForColor("Blue"));
        Assert.Equal(CubeFace.Right, Cube.GetFaceForColor("Orange"));  // CORRECTED
        Assert.Equal(CubeFace.Left, Cube.GetFaceForColor("Red"));      // CORRECTED
        Assert.Equal(CubeFace.Up, Cube.GetFaceForColor("Yellow"));
        Assert.Equal(CubeFace.Down, Cube.GetFaceForColor("White"));
    }

    [Theory]
    [InlineData(CubeFace.Front)]
    [InlineData(CubeFace.Back)]
    [InlineData(CubeFace.Right)]
    [InlineData(CubeFace.Left)]
    [InlineData(CubeFace.Up)]
    [InlineData(CubeFace.Down)]
    public void ColorMappings_ShouldBeSymmetric_ForAllFaces(CubeFace face)
    {
        // Arrange
        var colorName = Cube.GetColorForFace(face);

        // Act
        var mappedBackToFace = Cube.GetFaceForColor(colorName);

        // Assert
        Assert.Equal(face, mappedBackToFace);
    }

    [Fact]
    public void StickerPositions_ShouldFollowCorrectLayout()
    {
        // Arrange
        var cube = new Cube();
        
        // Modify specific positions to create a pattern
        cube.SetSticker(CubeFace.Front, TestHelpers.TestHelpers.StickerPositions.TopLeft, CubeColor.Red);
        cube.SetSticker(CubeFace.Front, TestHelpers.TestHelpers.StickerPositions.TopRight, CubeColor.Blue);
        cube.SetSticker(CubeFace.Front, TestHelpers.TestHelpers.StickerPositions.BottomLeft, CubeColor.Orange);
        cube.SetSticker(CubeFace.Front, TestHelpers.TestHelpers.StickerPositions.BottomRight, CubeColor.Yellow);

        // Act & Assert
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Front, 0));      // Top-left
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Front, 2));     // Top-right
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Front, 6));   // Bottom-left
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Front, 8));   // Bottom-right
        
        // Center should be unchanged
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Front, 4));
    }

    [Fact]
    public void StickerArrays_ShouldHaveCorrectPositions()
    {
        // Arrange & Act
        var topRow = TestHelpers.TestHelpers.StickerPositions.TopRow;
        var middleRow = TestHelpers.TestHelpers.StickerPositions.MiddleRow;
        var bottomRow = TestHelpers.TestHelpers.StickerPositions.BottomRow;
        
        var leftColumn = TestHelpers.TestHelpers.StickerPositions.LeftColumn;
        var centerColumn = TestHelpers.TestHelpers.StickerPositions.CenterColumn;
        var rightColumn = TestHelpers.TestHelpers.StickerPositions.RightColumn;

        // Assert
        Assert.Equal(new[] { 0, 1, 2 }, topRow);
        Assert.Equal(new[] { 3, 4, 5 }, middleRow);
        Assert.Equal(new[] { 6, 7, 8 }, bottomRow);
        
        Assert.Equal(new[] { 0, 3, 6 }, leftColumn);
        Assert.Equal(new[] { 1, 4, 7 }, centerColumn);
        Assert.Equal(new[] { 2, 5, 8 }, rightColumn);
    }

    [Fact]
    public void CreateSolvedFace_HelperMethod_ShouldWorkCorrectly()
    {
        // Arrange & Act
        var redFace = TestHelpers.TestHelpers.CreateSolvedFace(CubeColor.Red);
        var blueFace = TestHelpers.TestHelpers.CreateSolvedFace(CubeColor.Blue);

        // Assert
        Assert.Equal(9, redFace.Length);
        Assert.All(redFace, color => Assert.Equal(CubeColor.Red, color));
        
        Assert.Equal(9, blueFace.Length);
        Assert.All(blueFace, color => Assert.Equal(CubeColor.Blue, color));
    }
}