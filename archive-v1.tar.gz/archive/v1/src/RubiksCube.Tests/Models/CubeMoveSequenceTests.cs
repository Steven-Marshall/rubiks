using RubiksCube.Core.Models;
using RubiksCube.Tests.TestHelpers;
using Xunit;
using Xunit.Abstractions;

namespace RubiksCube.Tests.Models;

/// <summary>
/// Tests for move sequences and combinations with corrected implementations
/// </summary>
public class CubeMoveSequenceTests
{
    private readonly ITestOutputHelper _output;

    public CubeMoveSequenceTests(ITestOutputHelper output)
    {
        _output = output;
    }

    [Theory]
    [InlineData("R U R' U'", "Right-hand trigger pattern")]
    [InlineData("L D L' D'", "Left-hand trigger with corrected L and D moves")]
    [InlineData("F U F' U'", "Front trigger with corrected F move")]
    [InlineData("R2 L2 U2 D2 F2 B2", "All double moves")]
    [InlineData("R U' R' F R F'", "Common F2L insertion")]
    public void MoveSequence_ShouldApplyCorrectly(string algorithmString, string description)
    {
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var algorithm = Algorithm.Parse(algorithmString);

        // Act
        var result = algorithm.ApplyTo(cube);

        // Assert
        Assert.True(result.IsSuccess, $"Algorithm '{algorithmString}' should apply successfully");
        
        var isValid = CubeStateValidator.IsValidCubeState(cube, out string error);
        Assert.True(isValid, $"Cube should be valid after '{algorithmString}': {error}");

        _output.WriteLine($"✓ {description}: {algorithmString}");
    }

    [Fact]
    public void SexyMove_RURPrimeUPrime_ShouldCycleThreeCorners()
    {
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var sexyMove = Algorithm.Parse("R U R' U'");

        // Act - Apply sexy move 6 times (should return to solved after 6 applications)
        for (int i = 0; i < 6; i++)
        {
            var result = sexyMove.ApplyTo(cube);
            Assert.True(result.IsSuccess, $"Sexy move application {i + 1} should succeed");
        }

        // Assert
        Assert.True(cube.IsSolved(), "Six applications of sexy move should return to solved state");
    }

    [Fact]
    public void AntiSexyMove_UPrimeRURPrime_ShouldCycleThreeCornersReverse()
    {
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var antiSexyMove = Algorithm.Parse("U' R U R'");

        // Act - Apply anti-sexy move 6 times
        for (int i = 0; i < 6; i++)
        {
            var result = antiSexyMove.ApplyTo(cube);
            Assert.True(result.IsSuccess, $"Anti-sexy move application {i + 1} should succeed");
        }

        // Assert
        Assert.True(cube.IsSolved(), "Six applications of anti-sexy move should return to solved state");
    }

    [Fact]
    public void TPerm_ShouldSwapThreeEdges()
    {
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var tPerm = Algorithm.Parse("R U R' F' R U R' U' R' F R2 U' R'");

        // Act
        var result = tPerm.ApplyTo(cube);

        // Assert
        Assert.True(result.IsSuccess, "T-Perm should apply successfully");
        
        var isValid = CubeStateValidator.IsValidCubeState(cube, out string error);
        Assert.True(isValid, $"Cube should be valid after T-Perm: {error}");

        // T-Perm should only affect last layer edges, not solve the cube
        Assert.False(cube.IsSolved(), "T-Perm should not leave cube in solved state");
    }

    [Fact]
    public void CommonOLLCase_ShouldApplyWithCorrectedMoves()
    {
        // Test OLL case with corrected L and F moves
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var ollAlgorithm = Algorithm.Parse("F R U' R' U' R U R' F'");

        // Act
        var result = ollAlgorithm.ApplyTo(cube);

        // Assert
        Assert.True(result.IsSuccess, "OLL algorithm should apply successfully");
        
        var isValid = CubeStateValidator.IsValidCubeState(cube, out string error);
        Assert.True(isValid, $"Cube should be valid after OLL: {error}");
    }

    [Fact]
    public void F2LCase_WithCorrectedMoves_ShouldApplyCorrectly()
    {
        // Test F2L case that uses corrected L and D moves
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var f2lAlgorithm = Algorithm.Parse("L' U' L D L' U L D'");

        // Act
        var result = f2lAlgorithm.ApplyTo(cube);

        // Assert
        Assert.True(result.IsSuccess, "F2L algorithm with L and D moves should apply successfully");
        
        var isValid = CubeStateValidator.IsValidCubeState(cube, out string error);
        Assert.True(isValid, $"Cube should be valid after F2L: {error}");
    }

    [Theory]
    [InlineData("R", "R'")]
    [InlineData("L", "L'")] // Test corrected L move
    [InlineData("U", "U'")]
    [InlineData("D", "D'")] // Test corrected D move
    [InlineData("F", "F'")] // Test corrected F move
    [InlineData("B", "B'")]
    public void MoveAndInverse_ShouldCancelOut(string move, string inverse)
    {
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var algorithm = Algorithm.Parse($"{move} {inverse}");

        // Act
        var result = algorithm.ApplyTo(cube);

        // Assert
        Assert.True(result.IsSuccess, $"Move sequence '{move} {inverse}' should apply successfully");
        Assert.True(cube.IsSolved(), $"Move {move} followed by {inverse} should leave cube solved");
    }

    [Fact]
    public void ComplexSequence_WithAllCorrectedMoves_ShouldApply()
    {
        // Test a complex sequence that uses all basic moves, including corrected L, D, F
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var complexSequence = Algorithm.Parse("R U R' U' L U L' U' F U F' U' D U D' U' B U B' U'");

        // Act
        var result = complexSequence.ApplyTo(cube);

        // Assert
        Assert.True(result.IsSuccess, "Complex sequence with all moves should apply successfully");
        
        var isValid = CubeStateValidator.IsValidCubeState(cube, out string error);
        Assert.True(isValid, $"Cube should be valid after complex sequence: {error}");
    }

    [Fact]
    public void SuperFlip_ShouldApplyWithCorrectedMoves()
    {
        // Test the famous superflip algorithm
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var superflip = Algorithm.Parse("R U R' F' R U R' U' R' F R2 U' R' U' R U R' F R U R' U' R' F' R U' R");

        // Act
        var result = superflip.ApplyTo(cube);

        // Assert
        Assert.True(result.IsSuccess, "Superflip algorithm should apply successfully");
        
        var isValid = CubeStateValidator.IsValidCubeState(cube, out string error);
        Assert.True(isValid, $"Cube should be valid after superflip: {error}");

        // Superflip should flip all edges while keeping everything else solved
        Assert.False(cube.IsSolved(), "Superflip should not leave cube in solved state");
    }

    [Theory]
    [InlineData("R2", 2)]
    [InlineData("L2", 2)] // Test corrected L move double
    [InlineData("U2", 2)]
    [InlineData("D2", 2)] // Test corrected D move double
    [InlineData("F2", 2)] // Test corrected F move double
    [InlineData("B2", 2)]
    public void DoubleMoves_ShouldEqualTwoSingleMoves(string doubleMove, int expectedMoveCount)
    {
        // Arrange
        var cube1 = TestHelpers.TestHelpers.CreateSolvedCube();
        var cube2 = TestHelpers.TestHelpers.CreateSolvedCube();
        
        var singleMove = doubleMove[0].ToString(); // Extract face letter
        var twoSingleMoves = Algorithm.Parse($"{singleMove} {singleMove}");
        var oneDDoubleMove = Algorithm.Parse(doubleMove);

        // Act
        var result1 = twoSingleMoves.ApplyTo(cube1);
        var result2 = oneDDoubleMove.ApplyTo(cube2);

        // Assert
        Assert.True(result1.IsSuccess && result2.IsSuccess, "Both algorithms should apply successfully");
        TestHelpers.TestHelpers.AssertCubesEqual(cube1, cube2, $"{doubleMove} should equal two {singleMove} moves");
        
        Assert.Equal(expectedMoveCount, twoSingleMoves.MoveCount);
        Assert.Equal(1, oneDDoubleMove.MoveCount); // Double move counts as 1 move
    }

    [Fact]
    public void MoveValidation_AllBasicMoves_ShouldPreserveCubeProperties()
    {
        // Test that all basic moves preserve fundamental cube properties
        var basicMoves = new[] { "R", "L", "U", "D", "F", "B", "R'", "L'", "U'", "D'", "F'", "B'" };

        foreach (var moveString in basicMoves)
        {
            // Arrange
            var cube = TestHelpers.TestHelpers.CreateSolvedCube();
            var move = Algorithm.Parse(moveString);

            // Act
            var result = move.ApplyTo(cube);

            // Assert
            Assert.True(result.IsSuccess, $"Move {moveString} should apply successfully");
            
            // Check that cube has exactly 9 of each color
            var colorCounts = new Dictionary<CubeColor, int>();
            foreach (CubeColor color in Enum.GetValues<CubeColor>())
            {
                colorCounts[color] = 0;
            }

            foreach (CubeFace face in Enum.GetValues<CubeFace>())
            {
                var faceColors = cube.GetFace(face);
                foreach (var color in faceColors)
                {
                    colorCounts[color]++;
                }
            }

            foreach (var kvp in colorCounts)
            {
                Assert.Equal(9, kvp.Value);
            }

            _output.WriteLine($"✓ Move {moveString} preserves color counts");
        }
    }

    [Fact]
    public void CorrectedMoves_LDF_ShouldHaveProperClockwiseRotation()
    {
        // Specific test to verify that L, D, F moves now rotate clockwise as intended
        // This is a critical test for the bug fixes

        // Test L move clockwise rotation
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var lMove = Algorithm.Parse("L");
        var result = lMove.ApplyTo(cube);
        Assert.True(result.IsSuccess, "L move should apply successfully");
        
        // After L move, the front-left edge should have moved to down-left position
        // This validates clockwise rotation of L face
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Front, 0)); // Front top-left gets Yellow from Up

        // Test D move clockwise rotation
        cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var dMove = Algorithm.Parse("D");
        result = dMove.ApplyTo(cube);
        Assert.True(result.IsSuccess, "D move should apply successfully");
        
        // After D move, front-bottom should get Orange from Right
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Front, 6)); // Front bottom-left gets Orange

        // Test F move clockwise rotation
        cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var fMove = Algorithm.Parse("F");
        result = fMove.ApplyTo(cube);
        Assert.True(result.IsSuccess, "F move should apply successfully");
        
        // After F move, up-bottom should get Orange from Right
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Up, 6)); // Up bottom-left gets Orange

        _output.WriteLine("✓ L, D, F moves confirmed to rotate clockwise (BUGS FIXED!)");
    }
}