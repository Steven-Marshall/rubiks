using RubiksCube.Core.Models;
using RubiksCube.Core.Notation;
using Xunit;

namespace RubiksCube.Tests.Models;

public class CubeMoveTests
{
    private static Cube GetSolvedCube() => new();

    private static void AssertStickersEqual(Cube cube, CubeFace face, params CubeColor[] expectedColors)
    {
        var actualColors = cube.GetFace(face);
        for (int i = 0; i < expectedColors.Length; i++)
        {
            Assert.True(expectedColors[i] == actualColors[i], 
                $"Face {face}, position {i}: expected {expectedColors[i]} but got {actualColors[i]}");
        }
    }

    #region U (Up/Top) Move Tests

    [Fact]
    public void U_Clockwise_ShouldRotateCorrectly()
    {
        // Arrange
        var cube = GetSolvedCube();
        var move = new Move(CubeFace.Up, MoveType.Clockwise);

        // Act
        cube.ApplyMove(move);

        // Assert
        // The Up face itself rotates clockwise
        AssertStickersEqual(cube, CubeFace.Up,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow);

        // The top row of adjacent faces cycle: Front -> Left -> Back -> Right -> Front
        // Front face: top row should now be what was on Right
        AssertStickersEqual(cube, CubeFace.Front,
            CubeColor.Red, CubeColor.Red, CubeColor.Red,      // Was Right's top row
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Green, CubeColor.Green, CubeColor.Green);

        // Right face: top row should now be what was on Back
        AssertStickersEqual(cube, CubeFace.Right,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,   // Was Back's top row
            CubeColor.Red, CubeColor.Red, CubeColor.Red,
            CubeColor.Red, CubeColor.Red, CubeColor.Red);

        // Back face: top row should now be what was on Left
        AssertStickersEqual(cube, CubeFace.Back,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange, // Was Left's top row
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue);

        // Left face: top row should now be what was on Front
        AssertStickersEqual(cube, CubeFace.Left,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,  // Was Front's top row
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange);

        // Down face should be unchanged
        AssertStickersEqual(cube, CubeFace.Down,
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.White, CubeColor.White, CubeColor.White);
    }

    [Fact]
    public void U_CounterClockwise_ShouldRotateCorrectly()
    {
        // Arrange
        var cube = GetSolvedCube();
        var move = new Move(CubeFace.Up, MoveType.CounterClockwise);

        // Act
        cube.ApplyMove(move);

        // Assert
        // The Up face itself rotates counter-clockwise
        AssertStickersEqual(cube, CubeFace.Up,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow);

        // The top row of adjacent faces cycle: Front -> Right -> Back -> Left -> Front
        // Front face: top row should now be what was on Left
        AssertStickersEqual(cube, CubeFace.Front,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,  // Was Left's top row
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Green, CubeColor.Green, CubeColor.Green);

        // Left face: top row should now be what was on Back
        AssertStickersEqual(cube, CubeFace.Left,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,     // Was Back's top row
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange);

        // Back face: top row should now be what was on Right
        AssertStickersEqual(cube, CubeFace.Back,
            CubeColor.Red, CubeColor.Red, CubeColor.Red,        // Was Right's top row
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue);

        // Right face: top row should now be what was on Front
        AssertStickersEqual(cube, CubeFace.Right,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,  // Was Front's top row
            CubeColor.Red, CubeColor.Red, CubeColor.Red,
            CubeColor.Red, CubeColor.Red, CubeColor.Red);

        // Down face should be unchanged
        AssertStickersEqual(cube, CubeFace.Down,
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.White, CubeColor.White, CubeColor.White);
    }

    [Fact]
    public void U2_Double_ShouldRotate180Degrees()
    {
        // Arrange
        var cube = GetSolvedCube();
        var move = new Move(CubeFace.Up, MoveType.Double);

        // Act
        cube.ApplyMove(move);

        // Assert
        // The Up face itself rotates 180 degrees
        AssertStickersEqual(cube, CubeFace.Up,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow);

        // After 180 degree rotation: Front <-> Back, Left <-> Right
        // Front face: top row should now be what was on Back
        AssertStickersEqual(cube, CubeFace.Front,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,     // Was Back's top row
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Green, CubeColor.Green, CubeColor.Green);

        // Back face: top row should now be what was on Front
        AssertStickersEqual(cube, CubeFace.Back,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,   // Was Front's top row
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue);

        // Left face: top row should now be what was on Right
        AssertStickersEqual(cube, CubeFace.Left,
            CubeColor.Red, CubeColor.Red, CubeColor.Red,        // Was Right's top row
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange);

        // Right face: top row should now be what was on Left
        AssertStickersEqual(cube, CubeFace.Right,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange, // Was Left's top row
            CubeColor.Red, CubeColor.Red, CubeColor.Red,
            CubeColor.Red, CubeColor.Red, CubeColor.Red);

        // Down face should be unchanged
        AssertStickersEqual(cube, CubeFace.Down,
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.White, CubeColor.White, CubeColor.White);
    }

    [Fact]
    public void U_FourRotations_ShouldReturnToOriginal()
    {
        // Arrange
        var cube = GetSolvedCube();
        var originalJson = cube.ToJson();
        var move = new Move(CubeFace.Up, MoveType.Clockwise);

        // Act
        for (int i = 0; i < 4; i++)
        {
            cube.ApplyMove(move);
        }

        // Assert
        Assert.Equal(originalJson, cube.ToJson());
    }

    [Fact]
    public void U_ThenUPrime_ShouldReturnToOriginal()
    {
        // Arrange
        var cube = GetSolvedCube();
        var originalJson = cube.ToJson();
        var moveU = new Move(CubeFace.Up, MoveType.Clockwise);
        var moveUPrime = new Move(CubeFace.Up, MoveType.CounterClockwise);

        // Act
        cube.ApplyMove(moveU);
        cube.ApplyMove(moveUPrime);

        // Assert
        Assert.Equal(originalJson, cube.ToJson());
    }

    #endregion

    #region F (Front) Move Tests

    [Fact]
    public void F_Clockwise_ShouldRotateCorrectly()
    {
        // Arrange
        var cube = GetSolvedCube();
        var move = new Move(CubeFace.Front, MoveType.Clockwise);

        // Act
        cube.ApplyMove(move);

        // Assert
        // The Front face itself rotates clockwise
        AssertStickersEqual(cube, CubeFace.Front,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Green, CubeColor.Green, CubeColor.Green);

        // The edges cycle: Up bottom row -> Right left column -> Down top row -> Left right column -> Up bottom row
        // Up face: bottom row should now be what was on Left's right column (reversed)
        AssertStickersEqual(cube, CubeFace.Up,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange); // Was Left's right column

        // Right face: left column should now be what was on Up's bottom row
        AssertStickersEqual(cube, CubeFace.Right,
            CubeColor.Yellow, CubeColor.Red, CubeColor.Red,      // Was Up's bottom row
            CubeColor.Yellow, CubeColor.Red, CubeColor.Red,
            CubeColor.Yellow, CubeColor.Red, CubeColor.Red);

        // Down face: top row should now be what was on Right's left column (reversed)
        AssertStickersEqual(cube, CubeFace.Down,
            CubeColor.Red, CubeColor.Red, CubeColor.Red,         // Was Right's left column
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.White, CubeColor.White, CubeColor.White);

        // Left face: right column should now be what was on Down's top row
        AssertStickersEqual(cube, CubeFace.Left,
            CubeColor.Orange, CubeColor.Orange, CubeColor.White,  // Was Down's top row
            CubeColor.Orange, CubeColor.Orange, CubeColor.White,
            CubeColor.Orange, CubeColor.Orange, CubeColor.White);

        // Back face should be unchanged
        AssertStickersEqual(cube, CubeFace.Back,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue);
    }

    [Fact]
    public void F_CounterClockwise_ShouldRotateCorrectly()
    {
        // Arrange
        var cube = GetSolvedCube();
        var move = new Move(CubeFace.Front, MoveType.CounterClockwise);

        // Act
        cube.ApplyMove(move);

        // Assert
        // The Front face itself rotates counter-clockwise
        AssertStickersEqual(cube, CubeFace.Front,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Green, CubeColor.Green, CubeColor.Green);

        // The edges cycle in reverse: Up bottom row -> Left right column -> Down top row -> Right left column -> Up bottom row
        // Up face: bottom row should now be what was on Right's left column
        AssertStickersEqual(cube, CubeFace.Up,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Red, CubeColor.Red, CubeColor.Red);        // Was Right's left column

        // Left face: right column should now be what was on Up's bottom row (reversed)
        AssertStickersEqual(cube, CubeFace.Left,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Yellow, // Was Up's bottom row (reversed)
            CubeColor.Orange, CubeColor.Orange, CubeColor.Yellow,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Yellow);

        // Down face: top row should now be what was on Left's right column
        AssertStickersEqual(cube, CubeFace.Down,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange, // Was Left's right column
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.White, CubeColor.White, CubeColor.White);

        // Right face: left column should now be what was on Down's top row (reversed)
        AssertStickersEqual(cube, CubeFace.Right,
            CubeColor.White, CubeColor.Red, CubeColor.Red,       // Was Down's top row (reversed)
            CubeColor.White, CubeColor.Red, CubeColor.Red,
            CubeColor.White, CubeColor.Red, CubeColor.Red);

        // Back face should be unchanged
        AssertStickersEqual(cube, CubeFace.Back,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue);
    }

    [Fact]
    public void F2_Double_ShouldRotate180Degrees()
    {
        // Arrange
        var cube = GetSolvedCube();
        var move = new Move(CubeFace.Front, MoveType.Double);

        // Act
        cube.ApplyMove(move);

        // Assert
        // The Front face itself rotates 180 degrees
        AssertStickersEqual(cube, CubeFace.Front,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Green, CubeColor.Green, CubeColor.Green);

        // After 180 degree rotation: Up <-> Down (rows), Left <-> Right (columns)
        // Up face: bottom row should now be what was on Down's top row (reversed)
        AssertStickersEqual(cube, CubeFace.Up,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.White, CubeColor.White, CubeColor.White);   // Was Down's top row (reversed)

        // Down face: top row should now be what was on Up's bottom row (reversed)
        AssertStickersEqual(cube, CubeFace.Down,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow, // Was Up's bottom row (reversed)
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.White, CubeColor.White, CubeColor.White);

        // Left face: right column should now be what was on Right's left column (reversed)
        AssertStickersEqual(cube, CubeFace.Left,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Red,    // Was Right's left column (reversed)
            CubeColor.Orange, CubeColor.Orange, CubeColor.Red,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Red);

        // Right face: left column should now be what was on Left's right column (reversed)
        AssertStickersEqual(cube, CubeFace.Right,
            CubeColor.Orange, CubeColor.Red, CubeColor.Red,      // Was Left's right column (reversed)
            CubeColor.Orange, CubeColor.Red, CubeColor.Red,
            CubeColor.Orange, CubeColor.Red, CubeColor.Red);

        // Back face should be unchanged
        AssertStickersEqual(cube, CubeFace.Back,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue);
    }

    [Fact]
    public void F_FourRotations_ShouldReturnToOriginal()
    {
        // Arrange
        var cube = GetSolvedCube();
        var originalJson = cube.ToJson();
        var move = new Move(CubeFace.Front, MoveType.Clockwise);

        // Act
        for (int i = 0; i < 4; i++)
        {
            cube.ApplyMove(move);
        }

        // Assert
        Assert.Equal(originalJson, cube.ToJson());
    }

    [Fact]
    public void F_ThenFPrime_ShouldReturnToOriginal()
    {
        // Arrange
        var cube = GetSolvedCube();
        var originalJson = cube.ToJson();
        var moveF = new Move(CubeFace.Front, MoveType.Clockwise);
        var moveFPrime = new Move(CubeFace.Front, MoveType.CounterClockwise);

        // Act
        cube.ApplyMove(moveF);
        cube.ApplyMove(moveFPrime);

        // Assert
        Assert.Equal(originalJson, cube.ToJson());
    }

    #endregion

    #region L (Left) Move Tests

    [Fact]
    public void L_Clockwise_ShouldRotateCorrectly()
    {
        // Arrange
        var cube = GetSolvedCube();
        var move = new Move(CubeFace.Left, MoveType.Clockwise);

        // Act
        cube.ApplyMove(move);

        // Assert
        // The Left face itself rotates clockwise
        AssertStickersEqual(cube, CubeFace.Left,
            CubeColor.Red, CubeColor.Red, CubeColor.Red,
            CubeColor.Red, CubeColor.Red, CubeColor.Red,
            CubeColor.Red, CubeColor.Red, CubeColor.Red);

        // The edges cycle: Front <- Up <- Back <- Down <- Front
        // Front face: left column should now be what was on Up's left column
        AssertStickersEqual(cube, CubeFace.Front,
            CubeColor.Yellow, CubeColor.Green, CubeColor.Green,    // Was Up's left column
            CubeColor.Yellow, CubeColor.Green, CubeColor.Green,
            CubeColor.Yellow, CubeColor.Green, CubeColor.Green);

        // Up face: left column should now be what was on Back's right column (reversed)
        AssertStickersEqual(cube, CubeFace.Up,
            CubeColor.Blue, CubeColor.Yellow, CubeColor.Yellow,  // Was Back's right column (reversed)
            CubeColor.Blue, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Blue, CubeColor.Yellow, CubeColor.Yellow);

        // Back face: right column should now be what was on Down's left column (reversed)
        AssertStickersEqual(cube, CubeFace.Back,
            CubeColor.Blue, CubeColor.Blue, CubeColor.White,     // Was Down's left column (reversed)
            CubeColor.Blue, CubeColor.Blue, CubeColor.White,
            CubeColor.Blue, CubeColor.Blue, CubeColor.White);

        // Down face: left column should now be what was on Front's left column
        AssertStickersEqual(cube, CubeFace.Down,
            CubeColor.Green, CubeColor.White, CubeColor.White,     // Was Front's left column
            CubeColor.Green, CubeColor.White, CubeColor.White,
            CubeColor.Green, CubeColor.White, CubeColor.White);

        // Right face should be unchanged
        AssertStickersEqual(cube, CubeFace.Right,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange);
    }

    [Fact]
    public void L_CounterClockwise_ShouldRotateCorrectly()
    {
        // Arrange
        var cube = GetSolvedCube();
        var move = new Move(CubeFace.Left, MoveType.CounterClockwise);

        // Act
        cube.ApplyMove(move);

        // Assert
        // The Left face itself rotates counter-clockwise
        AssertStickersEqual(cube, CubeFace.Left,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange);

        // The edges cycle in reverse: Front left column -> Down left column -> Back right column (reversed) -> Up left column -> Front
        // Front face: left column should now be what was on Up's left column
        AssertStickersEqual(cube, CubeFace.Front,
            CubeColor.Yellow, CubeColor.Green, CubeColor.Green,   // Was Up's left column
            CubeColor.Yellow, CubeColor.Green, CubeColor.Green,
            CubeColor.Yellow, CubeColor.Green, CubeColor.Green);

        // Down face: left column should now be what was on Front's left column
        AssertStickersEqual(cube, CubeFace.Down,
            CubeColor.Green, CubeColor.White, CubeColor.White,    // Was Front's left column
            CubeColor.Green, CubeColor.White, CubeColor.White,
            CubeColor.Green, CubeColor.White, CubeColor.White);

        // Back face: right column should now be what was on Down's left column (reversed)
        AssertStickersEqual(cube, CubeFace.Back,
            CubeColor.Blue, CubeColor.Blue, CubeColor.White,      // Was Down's left column (reversed)
            CubeColor.Blue, CubeColor.Blue, CubeColor.White,
            CubeColor.Blue, CubeColor.Blue, CubeColor.White);

        // Up face: left column should now be what was on Back's right column (reversed)
        AssertStickersEqual(cube, CubeFace.Up,
            CubeColor.Blue, CubeColor.Yellow, CubeColor.Yellow,   // Was Back's right column (reversed)
            CubeColor.Blue, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Blue, CubeColor.Yellow, CubeColor.Yellow);

        // Right face should be unchanged
        AssertStickersEqual(cube, CubeFace.Right,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange);
    }

    [Fact]
    public void L2_Double_ShouldRotate180Degrees()
    {
        // Arrange
        var cube = GetSolvedCube();
        var move = new Move(CubeFace.Left, MoveType.Double);

        // Act
        cube.ApplyMove(move);

        // Assert
        // The Left face itself rotates 180 degrees
        AssertStickersEqual(cube, CubeFace.Left,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange);

        // After 180 degree rotation: Front <-> Back (columns swapped), Up <-> Down (columns)
        // Front face: left column should now be what was on Back's right column (reversed)
        AssertStickersEqual(cube, CubeFace.Front,
            CubeColor.Blue, CubeColor.Green, CubeColor.Green,     // Was Back's right column (reversed)
            CubeColor.Blue, CubeColor.Green, CubeColor.Green,
            CubeColor.Blue, CubeColor.Green, CubeColor.Green);

        // Back face: right column should now be what was on Front's left column (reversed)
        AssertStickersEqual(cube, CubeFace.Back,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Green,      // Was Front's left column (reversed)
            CubeColor.Blue, CubeColor.Blue, CubeColor.Green,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Green);

        // Up face: left column should now be what was on Down's left column
        AssertStickersEqual(cube, CubeFace.Up,
            CubeColor.White, CubeColor.Yellow, CubeColor.Yellow,  // Was Down's left column
            CubeColor.White, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.White, CubeColor.Yellow, CubeColor.Yellow);

        // Down face: left column should now be what was on Up's left column
        AssertStickersEqual(cube, CubeFace.Down,
            CubeColor.Yellow, CubeColor.White, CubeColor.White,   // Was Up's left column
            CubeColor.Yellow, CubeColor.White, CubeColor.White,
            CubeColor.Yellow, CubeColor.White, CubeColor.White);

        // Right face should be unchanged
        AssertStickersEqual(cube, CubeFace.Right,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange);
    }

    #endregion

    #region D (Down) Move Tests

    [Fact]
    public void D_Clockwise_ShouldRotateCorrectly()
    {
        // Arrange
        var cube = GetSolvedCube();
        var move = new Move(CubeFace.Down, MoveType.Clockwise);

        // Act
        cube.ApplyMove(move);

        // Assert
        // The Down face itself rotates clockwise
        AssertStickersEqual(cube, CubeFace.Down,
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.White, CubeColor.White, CubeColor.White);

        // The bottom row of adjacent faces cycle: Front -> Right -> Back -> Left -> Front
        // Front face: bottom row should now be what was on Right (Orange)
        AssertStickersEqual(cube, CubeFace.Front,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange); // Was Right's bottom row

        // Left face: bottom row should now be what was on Front (Green)
        AssertStickersEqual(cube, CubeFace.Left,
            CubeColor.Red, CubeColor.Red, CubeColor.Red,
            CubeColor.Red, CubeColor.Red, CubeColor.Red,
            CubeColor.Green, CubeColor.Green, CubeColor.Green);      // Was Front's bottom row

        // Back face: bottom row should now be what was on Left (Red)
        AssertStickersEqual(cube, CubeFace.Back,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Red, CubeColor.Red, CubeColor.Red);         // Was Left's bottom row

        // Right face: bottom row should now be what was on Back (Blue)
        AssertStickersEqual(cube, CubeFace.Right,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue);   // Was Back's bottom row

        // Up face should be unchanged
        AssertStickersEqual(cube, CubeFace.Up,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow);
    }

    [Fact]
    public void D_CounterClockwise_ShouldRotateCorrectly()
    {
        // Arrange
        var cube = GetSolvedCube();
        var move = new Move(CubeFace.Down, MoveType.CounterClockwise);

        // Act
        cube.ApplyMove(move);

        // Assert
        // The Down face itself rotates counter-clockwise
        AssertStickersEqual(cube, CubeFace.Down,
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.White, CubeColor.White, CubeColor.White);

        // The bottom row of adjacent faces cycle in reverse: Front -> Left -> Back -> Right -> Front
        // Front face: bottom row should now be what was on Right
        AssertStickersEqual(cube, CubeFace.Front,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Red, CubeColor.Red, CubeColor.Red);         // Was Right's bottom row

        // Right face: bottom row should now be what was on Back
        AssertStickersEqual(cube, CubeFace.Right,
            CubeColor.Red, CubeColor.Red, CubeColor.Red,
            CubeColor.Red, CubeColor.Red, CubeColor.Red,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue);      // Was Back's bottom row

        // Back face: bottom row should now be what was on Left
        AssertStickersEqual(cube, CubeFace.Back,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange); // Was Left's bottom row

        // Left face: bottom row should now be what was on Front
        AssertStickersEqual(cube, CubeFace.Left,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Green, CubeColor.Green, CubeColor.Green);   // Was Front's bottom row

        // Up face should be unchanged
        AssertStickersEqual(cube, CubeFace.Up,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow);
    }

    [Fact]
    public void D2_Double_ShouldRotate180Degrees()
    {
        // Arrange
        var cube = GetSolvedCube();
        var move = new Move(CubeFace.Down, MoveType.Double);

        // Act
        cube.ApplyMove(move);

        // Assert
        // The Down face itself rotates 180 degrees
        AssertStickersEqual(cube, CubeFace.Down,
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.White, CubeColor.White, CubeColor.White);

        // After 180 degree rotation: Front <-> Back, Left <-> Right
        // Front face: bottom row should now be what was on Back
        AssertStickersEqual(cube, CubeFace.Front,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue);      // Was Back's bottom row

        // Back face: bottom row should now be what was on Front
        AssertStickersEqual(cube, CubeFace.Back,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Green, CubeColor.Green, CubeColor.Green);   // Was Front's bottom row

        // Left face: bottom row should now be what was on Right
        AssertStickersEqual(cube, CubeFace.Left,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Red, CubeColor.Red, CubeColor.Red);         // Was Right's bottom row

        // Right face: bottom row should now be what was on Left
        AssertStickersEqual(cube, CubeFace.Right,
            CubeColor.Red, CubeColor.Red, CubeColor.Red,
            CubeColor.Red, CubeColor.Red, CubeColor.Red,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange); // Was Left's bottom row

        // Up face should be unchanged
        AssertStickersEqual(cube, CubeFace.Up,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow);
    }

    #endregion

    #region B (Back) Move Tests

    [Fact]
    public void B_Clockwise_ShouldRotateCorrectly()
    {
        // Arrange
        var cube = GetSolvedCube();
        var move = new Move(CubeFace.Back, MoveType.Clockwise);

        // Act
        cube.ApplyMove(move);

        // Assert
        // The Back face itself rotates clockwise
        AssertStickersEqual(cube, CubeFace.Back,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue);

        // The edges cycle: Up top row -> Left left column -> Down bottom row -> Right right column -> Up top row
        // Up face: top row should now be what was on Right's right column
        AssertStickersEqual(cube, CubeFace.Up,
            CubeColor.Red, CubeColor.Red, CubeColor.Red,          // Was Right's right column
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow);

        // Left face: left column should now be what was on Up's top row (reversed)
        AssertStickersEqual(cube, CubeFace.Left,
            CubeColor.Yellow, CubeColor.Orange, CubeColor.Orange, // Was Up's top row (reversed)
            CubeColor.Yellow, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Yellow, CubeColor.Orange, CubeColor.Orange);

        // Down face: bottom row should now be what was on Left's left column
        AssertStickersEqual(cube, CubeFace.Down,
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange); // Was Left's left column

        // Right face: right column should now be what was on Down's bottom row (reversed)
        AssertStickersEqual(cube, CubeFace.Right,
            CubeColor.Red, CubeColor.Red, CubeColor.White,        // Was Down's bottom row (reversed)
            CubeColor.Red, CubeColor.Red, CubeColor.White,
            CubeColor.Red, CubeColor.Red, CubeColor.White);

        // Front face should be unchanged
        AssertStickersEqual(cube, CubeFace.Front,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Green, CubeColor.Green, CubeColor.Green);
    }

    [Fact]
    public void B_CounterClockwise_ShouldRotateCorrectly()
    {
        // Arrange
        var cube = GetSolvedCube();
        var move = new Move(CubeFace.Back, MoveType.CounterClockwise);

        // Act
        cube.ApplyMove(move);

        // Assert
        // The Back face itself rotates counter-clockwise
        AssertStickersEqual(cube, CubeFace.Back,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue);

        // The edges cycle in reverse: Up top row -> Right right column -> Down bottom row -> Left left column -> Up top row
        // Up face: top row should now be what was on Left's left column (reversed)
        AssertStickersEqual(cube, CubeFace.Up,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange, // Was Left's left column (reversed)
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow);

        // Right face: right column should now be what was on Up's top row
        AssertStickersEqual(cube, CubeFace.Right,
            CubeColor.Red, CubeColor.Red, CubeColor.Yellow,       // Was Up's top row
            CubeColor.Red, CubeColor.Red, CubeColor.Yellow,
            CubeColor.Red, CubeColor.Red, CubeColor.Yellow);

        // Down face: bottom row should now be what was on Right's right column (reversed)
        AssertStickersEqual(cube, CubeFace.Down,
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.Red, CubeColor.Red, CubeColor.Red);         // Was Right's right column (reversed)

        // Left face: left column should now be what was on Down's bottom row
        AssertStickersEqual(cube, CubeFace.Left,
            CubeColor.White, CubeColor.Orange, CubeColor.Orange,  // Was Down's bottom row
            CubeColor.White, CubeColor.Orange, CubeColor.Orange,
            CubeColor.White, CubeColor.Orange, CubeColor.Orange);

        // Front face should be unchanged
        AssertStickersEqual(cube, CubeFace.Front,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Green, CubeColor.Green, CubeColor.Green);
    }

    [Fact]
    public void B2_Double_ShouldRotate180Degrees()
    {
        // Arrange
        var cube = GetSolvedCube();
        var move = new Move(CubeFace.Back, MoveType.Double);

        // Act
        cube.ApplyMove(move);

        // Assert
        // The Back face itself rotates 180 degrees
        AssertStickersEqual(cube, CubeFace.Back,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Blue, CubeColor.Blue, CubeColor.Blue);

        // After 180 degree rotation: Up <-> Down (rows), Left <-> Right (columns)
        // Up face: top row should now be what was on Down's bottom row (reversed)
        AssertStickersEqual(cube, CubeFace.Up,
            CubeColor.White, CubeColor.White, CubeColor.White,    // Was Down's bottom row (reversed)
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow);

        // Down face: bottom row should now be what was on Up's top row (reversed)
        AssertStickersEqual(cube, CubeFace.Down,
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.White, CubeColor.White, CubeColor.White,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Yellow); // Was Up's top row (reversed)

        // Left face: left column should now be what was on Right's right column (reversed)
        AssertStickersEqual(cube, CubeFace.Left,
            CubeColor.Red, CubeColor.Orange, CubeColor.Orange,    // Was Right's right column (reversed)
            CubeColor.Red, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Red, CubeColor.Orange, CubeColor.Orange);

        // Right face: right column should now be what was on Left's left column (reversed)
        AssertStickersEqual(cube, CubeFace.Right,
            CubeColor.Red, CubeColor.Red, CubeColor.Orange,       // Was Left's left column (reversed)
            CubeColor.Red, CubeColor.Red, CubeColor.Orange,
            CubeColor.Red, CubeColor.Red, CubeColor.Orange);

        // Front face should be unchanged
        AssertStickersEqual(cube, CubeFace.Front,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Green, CubeColor.Green, CubeColor.Green,
            CubeColor.Green, CubeColor.Green, CubeColor.Green);
    }

    #endregion

    #region R (Right) Move Tests

    [Fact]
    public void R_Clockwise_ShouldRotateCorrectly()
    {
        // Arrange
        var cube = GetSolvedCube();
        var move = new Move(CubeFace.Right, MoveType.Clockwise);

        // Act
        cube.ApplyMove(move);

        // Assert
        // The Right face itself rotates clockwise
        AssertStickersEqual(cube, CubeFace.Right,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange);

        // The right column of adjacent faces cycle: Up -> Front -> Down -> Back -> Up
        // Front face: right column should now be what was on Down
        AssertStickersEqual(cube, CubeFace.Front,
            CubeColor.Green, CubeColor.Green, CubeColor.White,    // Right col from Down
            CubeColor.Green, CubeColor.Green, CubeColor.White,
            CubeColor.Green, CubeColor.Green, CubeColor.White);

        // Up face: right column should now be what was on Front
        AssertStickersEqual(cube, CubeFace.Up,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Green,  // Front's right col
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Green,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Green);

        // Back face: left column should now be what was on Up (right column, reversed)
        AssertStickersEqual(cube, CubeFace.Back,
            CubeColor.Yellow, CubeColor.Blue, CubeColor.Blue,     // Up's right col reversed
            CubeColor.Yellow, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Yellow, CubeColor.Blue, CubeColor.Blue);

        // Down face: right column should now be what was on Back (left column, reversed)
        AssertStickersEqual(cube, CubeFace.Down,
            CubeColor.White, CubeColor.White, CubeColor.Blue,     // Back's left col reversed
            CubeColor.White, CubeColor.White, CubeColor.Blue,
            CubeColor.White, CubeColor.White, CubeColor.Blue);

        // Left face should be unchanged
        AssertStickersEqual(cube, CubeFace.Left,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange);
    }

    [Fact]
    public void R_CounterClockwise_ShouldRotateCorrectly()
    {
        // Arrange
        var cube = GetSolvedCube();
        var move = new Move(CubeFace.Right, MoveType.CounterClockwise);

        // Act
        cube.ApplyMove(move);

        // Assert
        // The Right face itself rotates counter-clockwise
        AssertStickersEqual(cube, CubeFace.Right,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange);

        // The right column of adjacent faces cycle: Up -> Back -> Down -> Front -> Up (reverse of clockwise)
        // Front face: right column should now be what was on Up
        AssertStickersEqual(cube, CubeFace.Front,
            CubeColor.Green, CubeColor.Green, CubeColor.Yellow,   // Right col from Up
            CubeColor.Green, CubeColor.Green, CubeColor.Yellow,
            CubeColor.Green, CubeColor.Green, CubeColor.Yellow);

        // Down face: right column should now be what was on Front
        AssertStickersEqual(cube, CubeFace.Down,
            CubeColor.White, CubeColor.White, CubeColor.Green,    // Front's right col
            CubeColor.White, CubeColor.White, CubeColor.Green,
            CubeColor.White, CubeColor.White, CubeColor.Green);

        // Back face: left column should now be what was on Down (right column, reversed)
        AssertStickersEqual(cube, CubeFace.Back,
            CubeColor.White, CubeColor.Blue, CubeColor.Blue,      // Down's right col reversed
            CubeColor.White, CubeColor.Blue, CubeColor.Blue,
            CubeColor.White, CubeColor.Blue, CubeColor.Blue);

        // Up face: right column should now be what was on Back (left column, reversed)
        AssertStickersEqual(cube, CubeFace.Up,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Blue,   // Back's left col reversed
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Blue,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.Blue);

        // Left face should be unchanged
        AssertStickersEqual(cube, CubeFace.Left,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange);
    }

    [Fact]
    public void R2_Double_ShouldRotate180Degrees()
    {
        // Arrange
        var cube = GetSolvedCube();
        var move = new Move(CubeFace.Right, MoveType.Double);

        // Act
        cube.ApplyMove(move);

        // Assert
        // The Right face itself rotates 180 degrees
        AssertStickersEqual(cube, CubeFace.Right,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange);

        // For 180-degree rotation, opposite faces swap their right/left columns
        // Front face: right column should now be what was on Back (left column, reversed)
        AssertStickersEqual(cube, CubeFace.Front,
            CubeColor.Green, CubeColor.Green, CubeColor.Blue,     // Back's left col reversed
            CubeColor.Green, CubeColor.Green, CubeColor.Blue,
            CubeColor.Green, CubeColor.Green, CubeColor.Blue);

        // Back face: left column should now be what was on Front (right column, reversed)
        AssertStickersEqual(cube, CubeFace.Back,
            CubeColor.Green, CubeColor.Blue, CubeColor.Blue,      // Front's right col reversed
            CubeColor.Green, CubeColor.Blue, CubeColor.Blue,
            CubeColor.Green, CubeColor.Blue, CubeColor.Blue);

        // Up face: right column should now be what was on Down (right column)
        AssertStickersEqual(cube, CubeFace.Up,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.White,  // Down's right col
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.White,
            CubeColor.Yellow, CubeColor.Yellow, CubeColor.White);

        // Down face: right column should now be what was on Up (right column)
        AssertStickersEqual(cube, CubeFace.Down,
            CubeColor.White, CubeColor.White, CubeColor.Yellow,   // Up's right col
            CubeColor.White, CubeColor.White, CubeColor.Yellow,
            CubeColor.White, CubeColor.White, CubeColor.Yellow);

        // Left face should be unchanged
        AssertStickersEqual(cube, CubeFace.Left,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange,
            CubeColor.Orange, CubeColor.Orange, CubeColor.Orange);
    }

    [Fact]
    public void R_FourRotations_ShouldReturnToOriginal()
    {
        // Arrange
        var originalCube = GetSolvedCube();
        var testCube = GetSolvedCube();
        var move = new Move(CubeFace.Right, MoveType.Clockwise);

        // Act - Apply R move four times
        testCube.ApplyMove(move);
        testCube.ApplyMove(move);
        testCube.ApplyMove(move);
        testCube.ApplyMove(move);

        // Assert - Cube should be back to original state
        for (var face = CubeFace.Front; face <= CubeFace.Down; face++)
        {
            var originalFace = originalCube.GetFace(face);
            var testFace = testCube.GetFace(face);
            
            for (int i = 0; i < 9; i++)
            {
                Assert.Equal(originalFace[i], testFace[i]);
            }
        }
    }

    [Fact]
    public void R_ThenPrime_ShouldReturnToOriginal()
    {
        // Arrange
        var originalCube = GetSolvedCube();
        var testCube = GetSolvedCube();

        // Act - Apply R then R'
        testCube.ApplyMove(new Move(CubeFace.Right, MoveType.Clockwise));
        testCube.ApplyMove(new Move(CubeFace.Right, MoveType.CounterClockwise));

        // Assert - Cube should be back to original state
        for (var face = CubeFace.Front; face <= CubeFace.Down; face++)
        {
            var originalFace = originalCube.GetFace(face);
            var testFace = testCube.GetFace(face);
            
            for (int i = 0; i < 9; i++)
            {
                Assert.Equal(originalFace[i], testFace[i]);
            }
        }
    }

    #endregion
}