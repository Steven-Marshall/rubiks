using RubiksCube.Core.Models;

namespace RubiksCube.Tests.Models;

public class CubeTests
{
    [Fact]
    public void NewCube_ShouldBeSolved()
    {
        var cube = new Cube();
        Assert.True(cube.IsSolved());
    }

    [Fact]
    public void NewCube_ShouldHaveCorrectColorScheme()
    {
        var cube = new Cube();
        
        // CFOP Standard: White bottom, Green front
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Down, 4));   // Center
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Up, 4));    // Center
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Front, 4));  // Center
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Back, 4));    // Center
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Right, 4));  // Center
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Left, 4));     // Center
    }

    [Fact]
    public void GetFace_ShouldReturnAllSameColors()
    {
        var cube = new Cube();
        var frontFace = cube.GetFace(CubeFace.Front);
        
        Assert.Equal(9, frontFace.Length);
        Assert.All(frontFace, color => Assert.Equal(CubeColor.Green, color));
    }

    [Fact]
    public void SetFace_ShouldUpdateAllStickers()
    {
        var cube = new Cube();
        var newColors = Enumerable.Repeat(CubeColor.Red, 9).ToArray();
        
        cube.SetFace(CubeFace.Front, newColors);
        var frontFace = cube.GetFace(CubeFace.Front);
        
        Assert.All(frontFace, color => Assert.Equal(CubeColor.Red, color));
    }

    [Fact]
    public void Clone_ShouldCreateIndependentCopy()
    {
        var cube1 = new Cube();
        var cube2 = cube1.Clone();
        
        cube1.SetSticker(CubeFace.Front, 0, CubeColor.Red);
        
        Assert.Equal(CubeColor.Red, cube1.GetSticker(CubeFace.Front, 0));
        Assert.Equal(CubeColor.Green, cube2.GetSticker(CubeFace.Front, 0));
    }

    [Fact]
    public void JsonSerialization_ShouldRoundTrip()
    {
        var cube1 = new Cube();
        cube1.SetSticker(CubeFace.Front, 0, CubeColor.Red);
        
        var json = cube1.ToJson();
        var cube2 = Cube.FromJson(json);
        
        Assert.Equal(cube1.GetSticker(CubeFace.Front, 0), cube2.GetSticker(CubeFace.Front, 0));
        Assert.Equal(cube1.GetSticker(CubeFace.Front, 4), cube2.GetSticker(CubeFace.Front, 4));
    }

    [Theory]
    [InlineData(CubeFace.Right)]
    [InlineData(CubeFace.Up)]
    [InlineData(CubeFace.Front)]
    public void ApplyMove_ThenInverse_ShouldReturnToOriginal(CubeFace face)
    {
        var cube = new Cube();
        var originalJson = cube.ToJson();
        
        var move = new Move(face, MoveType.Clockwise);
        var inverseMove = move.GetInverse();
        
        cube.ApplyMoveUnsafe(move);
        cube.ApplyMove(inverseMove);
        
        var finalJson = cube.ToJson();
        Assert.Equal(originalJson, finalJson);
    }

    [Fact]
    public void ApplyMove_RightClockwise_ShouldAffectAdjacentFaces()
    {
        var cube = new Cube();
        var originalFrontRight = cube.GetSticker(CubeFace.Front, 2);
        
        cube.ApplyMoveUnsafe(new Move(CubeFace.Right, MoveType.Clockwise));
        
        // After R move, front right edge should be different
        var newFrontRight = cube.GetSticker(CubeFace.Front, 2);
        Assert.NotEqual(originalFrontRight, newFrontRight);
        
        // Should no longer be solved
        Assert.False(cube.IsSolved());
    }

    [Fact]
    public void ApplyMove_FourClockwiseRotations_ShouldReturnToOriginal()
    {
        var cube = new Cube();
        var originalJson = cube.ToJson();
        
        var move = new Move(CubeFace.Right, MoveType.Clockwise);
        for (int i = 0; i < 4; i++)
        {
            cube.ApplyMoveUnsafe(move);
        }
        
        var finalJson = cube.ToJson();
        Assert.Equal(originalJson, finalJson);
        Assert.True(cube.IsSolved());
    }

    [Fact]
    public void ApplyMove_Double_ShouldEqualTwoClockwise()
    {
        var cube1 = new Cube();
        var cube2 = new Cube();
        
        cube1.ApplyMove(new Move(CubeFace.Right, MoveType.Double));
        
        cube2.ApplyMove(new Move(CubeFace.Right, MoveType.Clockwise));
        cube2.ApplyMove(new Move(CubeFace.Right, MoveType.Clockwise));
        
        Assert.Equal(cube1.ToJson(), cube2.ToJson());
    }
}