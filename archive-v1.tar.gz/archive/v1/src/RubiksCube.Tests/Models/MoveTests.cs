using RubiksCube.Core.Models;

namespace RubiksCube.Tests.Models;

public class MoveTests
{
    [Theory]
    [InlineData("R", CubeFace.Right, MoveType.Clockwise)]
    [InlineData("U", CubeFace.Up, MoveType.Clockwise)]
    [InlineData("F", CubeFace.Front, MoveType.Clockwise)]
    [InlineData("L", CubeFace.Left, MoveType.Clockwise)]
    [InlineData("D", CubeFace.Down, MoveType.Clockwise)]
    [InlineData("B", CubeFace.Back, MoveType.Clockwise)]
    public void Parse_ClockwiseMoves_ShouldParseCorrectly(string moveString, CubeFace expectedFace, MoveType expectedType)
    {
        var move = Move.Parse(moveString);
        Assert.Equal(expectedFace, move.Face);
        Assert.Equal(expectedType, move.Type);
    }

    [Theory]
    [InlineData("R'", CubeFace.Right, MoveType.CounterClockwise)]
    [InlineData("U'", CubeFace.Up, MoveType.CounterClockwise)]
    [InlineData("F'", CubeFace.Front, MoveType.CounterClockwise)]
    public void Parse_CounterClockwiseMoves_ShouldParseCorrectly(string moveString, CubeFace expectedFace, MoveType expectedType)
    {
        var move = Move.Parse(moveString);
        Assert.Equal(expectedFace, move.Face);
        Assert.Equal(expectedType, move.Type);
    }

    [Theory]
    [InlineData("R2", CubeFace.Right, MoveType.Double)]
    [InlineData("U2", CubeFace.Up, MoveType.Double)]
    [InlineData("F2", CubeFace.Front, MoveType.Double)]
    public void Parse_DoubleMoves_ShouldParseCorrectly(string moveString, CubeFace expectedFace, MoveType expectedType)
    {
        var move = Move.Parse(moveString);
        Assert.Equal(expectedFace, move.Face);
        Assert.Equal(expectedType, move.Type);
    }

    [Theory]
    [InlineData("")]
    [InlineData(" ")]
    [InlineData("R3")]
    [InlineData("Rx")]
    public void Parse_InvalidMoves_ShouldThrowArgumentException(string invalidMove)
    {
        Assert.Throws<ArgumentException>(() => Move.Parse(invalidMove));
    }

    [Theory]
    [InlineData("X")]
    [InlineData("Z")]
    public void Parse_InvalidFace_ShouldThrowArgumentOutOfRangeException(string invalidMove)
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => Move.Parse(invalidMove));
    }

    [Theory]
    [InlineData("R", "R")]
    [InlineData("R'", "R'")]
    [InlineData("R2", "R2")]
    [InlineData("U", "U")]
    [InlineData("F'", "F'")]
    public void ToString_ShouldRoundTrip(string moveString, string expected)
    {
        var move = Move.Parse(moveString);
        Assert.Equal(expected, move.ToString());
    }

    [Theory]
    [InlineData(CubeFace.Right, MoveType.Clockwise, CubeFace.Right, MoveType.CounterClockwise)]
    [InlineData(CubeFace.Up, MoveType.CounterClockwise, CubeFace.Up, MoveType.Clockwise)]
    [InlineData(CubeFace.Front, MoveType.Double, CubeFace.Front, MoveType.Double)]
    public void GetInverse_ShouldReturnCorrectInverse(CubeFace face, MoveType type, CubeFace expectedFace, MoveType expectedType)
    {
        var move = new Move(face, type);
        var inverse = move.GetInverse();
        
        Assert.Equal(expectedFace, inverse.Face);
        Assert.Equal(expectedType, inverse.Type);
    }
}