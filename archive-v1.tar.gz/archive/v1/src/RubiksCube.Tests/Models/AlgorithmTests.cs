using RubiksCube.Core.Models;

namespace RubiksCube.Tests.Models;

public class AlgorithmTests
{
    [Fact]
    public void Constructor_WithValidSequence_ShouldParseCorrectly()
    {
        var algorithm = new Algorithm("R U R' U'");
        
        Assert.Equal("R U R' U'", algorithm.Sequence);
        Assert.Equal(4, algorithm.MoveCount);
        Assert.Equal("R", algorithm.Moves[0].ToString());
        Assert.Equal("U", algorithm.Moves[1].ToString());
        Assert.Equal("R'", algorithm.Moves[2].ToString());
        Assert.Equal("U'", algorithm.Moves[3].ToString());
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData("\t\n")]
    public void Constructor_WithEmptySequence_ShouldThrowException(string emptySequence)
    {
        Assert.Throws<ArgumentException>(() => new Algorithm(emptySequence));
    }

    [Fact]
    public void Constructor_WithMoveList_ShouldCreateSequence()
    {
        var moves = new List<Move>
        {
            new Move(CubeFace.Right, MoveType.Clockwise),
            new Move(CubeFace.Up, MoveType.CounterClockwise)
        };
        
        var algorithm = new Algorithm(moves);
        
        Assert.Equal("R U'", algorithm.Sequence);
        Assert.Equal(2, algorithm.MoveCount);
    }

    [Theory]
    [InlineData("R U R' U'", 4)]
    [InlineData("R U2 R' D'", 4)]
    [InlineData("F R U R' U' F'", 6)]
    [InlineData("R", 1)]
    public void MoveCount_ShouldReturnCorrectCount(string sequence, int expectedCount)
    {
        var algorithm = new Algorithm(sequence);
        Assert.Equal(expectedCount, algorithm.MoveCount);
    }

    [Fact]
    public void RemoveMetadata_ShouldIgnoreBracedComments()
    {
        var algorithm = new Algorithm("R U R' {Sune} U R U2 R' {done}");
        
        Assert.Equal("R U R' U R U2 R'", algorithm.Sequence);
        Assert.Equal(7, algorithm.MoveCount);
    }

    [Theory]
    [InlineData("R  U   R'    U'", "R U R' U'")]
    [InlineData("R\tU\nR'\rU'", "R U R' U'")]
    [InlineData("R,U,R',U'", "R U R' U'")]
    public void Constructor_ShouldNormalizeWhitespace(string input, string expected)
    {
        var algorithm = new Algorithm(input);
        Assert.Equal(expected, algorithm.Sequence);
    }

    [Fact]
    public void ApplyTo_ShouldExecuteAllMoves()
    {
        var cube = new Cube();
        var algorithm = new Algorithm("R U R' U'");
        var originalJson = cube.ToJson();
        
        algorithm.ApplyToUnsafe(cube);
        
        // Cube should be different after applying algorithm
        Assert.NotEqual(originalJson, cube.ToJson());
        Assert.False(cube.IsSolved());
    }

    [Fact]
    public void GetInverse_ShouldReverseAndInvertMoves()
    {
        var algorithm = new Algorithm("R U R' U'");
        var inverse = algorithm.GetInverse();
        
        Assert.Equal("U R U' R'", inverse.Sequence);
        Assert.Equal(4, inverse.MoveCount);
    }

    [Fact]
    public void ApplyAlgorithmThenInverse_ShouldReturnToOriginal()
    {
        var cube = new Cube();
        var algorithm = new Algorithm("R U R' U'");
        var inverse = algorithm.GetInverse();
        var originalJson = cube.ToJson();
        
        algorithm.ApplyToUnsafe(cube);
        inverse.ApplyToUnsafe(cube);
        
        Assert.Equal(originalJson, cube.ToJson());
        Assert.True(cube.IsSolved());
    }

    [Fact]
    public void Concatenate_ShouldCombineAlgorithms()
    {
        var alg1 = new Algorithm("R U R'");
        var alg2 = new Algorithm("U R U2 R'");
        
        var combined = alg1.Concatenate(alg2);
        
        Assert.Equal("R U R' U R U2 R'", combined.Sequence);
        Assert.Equal(7, combined.MoveCount);
    }

    [Fact]
    public void Parse_StaticMethod_ShouldWork()
    {
        var algorithm = Algorithm.Parse("F R U R' U' F'");
        
        Assert.Equal("F R U R' U' F'", algorithm.Sequence);
        Assert.Equal(6, algorithm.MoveCount);
    }

    [Fact]
    public void Equals_SameSequence_ShouldBeEqual()
    {
        var alg1 = new Algorithm("R U R' U'");
        var alg2 = new Algorithm("R U R' U'");
        var alg3 = new Algorithm("R U R'");
        
        Assert.Equal(alg1, alg2);
        Assert.NotEqual(alg1, alg3);
    }

    [Fact]
    public void JsonSerialization_ShouldRoundTrip()
    {
        var algorithm = new Algorithm("R U R' U R U2 R'");
        
        var json = algorithm.ToJson();
        var deserialized = Algorithm.FromJson(json);
        
        Assert.Equal(algorithm.Sequence, deserialized.Sequence);
        Assert.Equal(algorithm.MoveCount, deserialized.MoveCount);
    }

    [Theory]
    [InlineData("X U R")]  // Invalid face
    [InlineData("R3 U")]   // Invalid modifier  
    [InlineData("R Q")]    // Invalid move
    public void Constructor_WithInvalidMoves_ShouldThrowException(string invalidSequence)
    {
        Assert.ThrowsAny<Exception>(() => new Algorithm(invalidSequence));
    }

    [Fact]
    public void ToString_ShouldReturnSequence()
    {
        var algorithm = new Algorithm("R U R' U'");
        Assert.Equal("R U R' U'", algorithm.ToString());
    }
}