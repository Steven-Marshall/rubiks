using RubiksCube.Core.Models;
using Xunit;

namespace RubiksCube.Tests.Models;

public class CubeRotationIntegrationTests
{
    private static Cube GetSolvedCube() => new();

    #region ApplyRotation Tests

    [Fact]
    public void ApplyRotation_Y_ShouldUpdateOrientationOnly()
    {
        // Arrange
        var cube = GetSolvedCube();
        var originalFrontFace = cube.GetFace(CubeFace.Front);
        var rotation = new Rotation(RotationAxis.Y, RotationDirection.Clockwise);

        // Act
        var result = cube.ApplyRotation(rotation);

        // Assert
        Assert.True(result.IsSuccess);
        
        // Physical faces should be unchanged
        var newFrontFace = cube.GetFace(CubeFace.Front);
        Assert.Equal(originalFrontFace, newFrontFace);
        
        // But orientation should have changed
        var orientationInfo = cube.GetOrientationDebugInfo();
        Assert.Contains("Front position has: Red", orientationInfo); // Left face is now in front
    }

    [Fact]
    public void ApplyRotation_YPrime_ShouldProduceExpectedOrientation()
    {
        // Arrange
        var cube = GetSolvedCube();
        var rotation = new Rotation(RotationAxis.Y, RotationDirection.CounterClockwise);

        // Act
        var result = cube.ApplyRotation(rotation);

        // Assert
        Assert.True(result.IsSuccess);
        
        // Verify y' orientation: Orange face should be in front position (from Right)
        var orientationInfo = cube.GetOrientationDebugInfo();
        Assert.Contains("Front position has: Orange", orientationInfo);
        Assert.Contains("Right position has: Blue", orientationInfo);
        Assert.Contains("Back position has: Red", orientationInfo);
        Assert.Contains("Left position has: Green", orientationInfo);
    }

    [Fact]
    public void ApplyRotation_InvalidAxis_ShouldReturnFailure()
    {
        // Arrange
        var cube = GetSolvedCube();
        var rotation = new Rotation((RotationAxis)999, RotationDirection.Clockwise);

        // Act
        var result = cube.ApplyRotation(rotation);

        // Assert
        Assert.True(result.IsFailure);
        Assert.Contains("Unknown rotation axis", result.Error);
    }

    #endregion

    #region GetFaceFromCurrentOrientation Tests

    [Fact]
    public void GetFaceFromCurrentOrientation_AfterYPrime_ShouldReturnCorrectFaces()
    {
        // Arrange
        var cube = GetSolvedCube();
        var originalOrangeFace = cube.GetFace(CubeFace.Right);  // Orange face (originally right)
        var rotation = new Rotation(RotationAxis.Y, RotationDirection.CounterClockwise);

        // Act
        cube.ApplyRotation(rotation);
        var faceNowInFront = cube.GetFaceFromCurrentOrientation(CubeFace.Front);

        // Assert - Front position should now show the Orange face (from Right)
        Assert.Equal(originalOrangeFace, faceNowInFront);
    }

    [Fact]
    public void GetFaceFromCurrentOrientation_DefaultOrientation_ShouldReturnOriginalFaces()
    {
        // Arrange
        var cube = GetSolvedCube();

        // Act & Assert - Each position should return its default face
        Assert.Equal(cube.GetFace(CubeFace.Front), cube.GetFaceFromCurrentOrientation(CubeFace.Front));
        Assert.Equal(cube.GetFace(CubeFace.Right), cube.GetFaceFromCurrentOrientation(CubeFace.Right));
        Assert.Equal(cube.GetFace(CubeFace.Back), cube.GetFaceFromCurrentOrientation(CubeFace.Back));
        Assert.Equal(cube.GetFace(CubeFace.Left), cube.GetFaceFromCurrentOrientation(CubeFace.Left));
        Assert.Equal(cube.GetFace(CubeFace.Up), cube.GetFaceFromCurrentOrientation(CubeFace.Up));
        Assert.Equal(cube.GetFace(CubeFace.Down), cube.GetFaceFromCurrentOrientation(CubeFace.Down));
    }

    #endregion

    #region Move Application with Orientation Tests

    [Fact]
    public void Move_R_AfterYPrime_ShouldTurnBlueFace()
    {
        // Arrange
        var cube = GetSolvedCube();
        var originalUpFace = cube.GetFace(CubeFace.Up);    // Yellow face should change
        var rotation = new Rotation(RotationAxis.Y, RotationDirection.CounterClockwise);
        var move = new Move(CubeFace.Right, MoveType.Clockwise);

        // Act
        cube.ApplyRotation(rotation);  // y' puts Blue face in Right position
        cube.ApplyMove(move);          // R should now turn the Blue face

        // Assert - Adjacent faces should have changed due to R move on Blue face
        var upFaceAfterMove = cube.GetFace(CubeFace.Up);
        Assert.NotEqual(originalUpFace, upFaceAfterMove);
        
        // The Blue face (now in Right position) should still be all blue but rotated
        var rightPositionAfterMove = cube.GetFaceFromCurrentOrientation(CubeFace.Right);
        Assert.All(rightPositionAfterMove, color => Assert.Equal(CubeColor.Blue, color));
    }

    [Fact]
    public void Move_R_WithoutRotation_ShouldTurnRedFace()
    {
        // Arrange
        var cube = GetSolvedCube();
        var originalFrontFace = cube.GetFace(CubeFace.Front);  // Green face
        var move = new Move(CubeFace.Right, MoveType.Clockwise);

        // Act
        cube.ApplyMove(move);  // R should turn the Orange face (Right face)

        // Assert - The Orange face should still be all orange (face rotates in place)
        var orangeFaceAfterMove = cube.GetFace(CubeFace.Right);
        Assert.All(orangeFaceAfterMove, color => Assert.Equal(CubeColor.Orange, color));
        
        // But adjacent faces should have changed due to the R move
        var frontFaceAfterMove = cube.GetFace(CubeFace.Front);
        Assert.NotEqual(originalFrontFace, frontFaceAfterMove);
    }

    [Fact]
    public void Algorithm_YPrimeRUR_ShouldProduceDifferentResultThanRUR()
    {
        // Arrange
        var cube1 = GetSolvedCube();
        var cube2 = GetSolvedCube();
        
        var algorithmWithRotation = new Algorithm("y' R U R'");
        var algorithmWithoutRotation = new Algorithm("R U R'");

        // Act
        algorithmWithRotation.ApplyTo(cube1);
        algorithmWithoutRotation.ApplyTo(cube2);

        // Assert - Results should be different
        var cube1State = cube1.ToJson();
        var cube2State = cube2.ToJson();
        Assert.NotEqual(cube1State, cube2State);
    }

    #endregion

    #region JSON Serialization with Orientation Tests

    [Fact]
    public void ToJson_AfterRotation_ShouldIncludeOrientationData()
    {
        // Arrange
        var cube = GetSolvedCube();
        var rotation = new Rotation(RotationAxis.Y, RotationDirection.CounterClockwise);

        // Act
        cube.ApplyRotation(rotation);
        var json = cube.ToJson();

        // Assert
        Assert.Contains("\"orientation\"", json);
        Assert.Contains("\"front\": \"Orange\"", json);    // Orange face in front position
        Assert.Contains("\"right\": \"Blue\"", json);      // Blue face in right position
        Assert.Contains("\"back\": \"Red\"", json);       // Red face in back position
        Assert.Contains("\"left\": \"Green\"", json);     // Green face in left position
    }

    [Fact]
    public void FromJson_WithOrientationData_ShouldRestoreOrientation()
    {
        // Arrange
        var originalCube = GetSolvedCube();
        var rotation = new Rotation(RotationAxis.Y, RotationDirection.CounterClockwise);
        originalCube.ApplyRotation(rotation);
        var json = originalCube.ToJson();

        // Act
        var restoredCube = Cube.FromJson(json);

        // Assert
        var originalInfo = originalCube.GetOrientationDebugInfo();
        var restoredInfo = restoredCube.GetOrientationDebugInfo();
        Assert.Equal(originalInfo, restoredInfo);
    }

    [Fact]
    public void FromJson_WithoutOrientationData_ShouldUseDefaultOrientation()
    {
        // Arrange - Create JSON without orientation field (backward compatibility)
        var jsonWithoutOrientation = @"{
            ""faces"": {
                ""front"": [""G"",""G"",""G"",""G"",""G"",""G"",""G"",""G"",""G""],
                ""back"": [""B"",""B"",""B"",""B"",""B"",""B"",""B"",""B"",""B""],
                ""right"": [""R"",""R"",""R"",""R"",""R"",""R"",""R"",""R"",""R""],
                ""left"": [""O"",""O"",""O"",""O"",""O"",""O"",""O"",""O"",""O""],
                ""up"": [""Y"",""Y"",""Y"",""Y"",""Y"",""Y"",""Y"",""Y"",""Y""],
                ""down"": [""W"",""W"",""W"",""W"",""W"",""W"",""W"",""W"",""W""]
            }
        }";

        // Act
        var cube = Cube.FromJson(jsonWithoutOrientation);

        // Assert - Should have default orientation
        var orientationInfo = cube.GetOrientationDebugInfo();
        Assert.Contains("Front position has: Green", orientationInfo);
        Assert.Contains("Right position has: Orange", orientationInfo);
        Assert.Contains("Back position has: Blue", orientationInfo);
        Assert.Contains("Left position has: Red", orientationInfo);
    }

    #endregion

    #region Rotation Parsing and Algorithm Integration Tests

    [Fact]
    public void RotationParsing_ValidRotations_ShouldParseCorrectly()
    {
        // Arrange & Act & Assert
        var xRotation = Rotation.Parse("x");
        Assert.Equal(RotationAxis.X, xRotation.Axis);
        Assert.Equal(RotationDirection.Clockwise, xRotation.Direction);

        var yPrimeRotation = Rotation.Parse("y'");
        Assert.Equal(RotationAxis.Y, yPrimeRotation.Axis);
        Assert.Equal(RotationDirection.CounterClockwise, yPrimeRotation.Direction);

        var z2Rotation = Rotation.Parse("z2");
        Assert.Equal(RotationAxis.Z, z2Rotation.Axis);
        Assert.Equal(RotationDirection.Double, z2Rotation.Direction);
    }

    [Fact]
    public void RotationParsing_InvalidRotations_ShouldThrowException()
    {
        // Arrange & Act & Assert
        Assert.Throws<ArgumentException>(() => Rotation.Parse("X"));  // Uppercase not allowed
        Assert.Throws<ArgumentException>(() => Rotation.Parse("a"));  // Invalid axis
        Assert.Throws<ArgumentException>(() => Rotation.Parse("x3")); // Invalid modifier
        Assert.Throws<ArgumentException>(() => Rotation.Parse(""));   // Empty string
    }

    [Fact]
    public void RotationInverse_ShouldProduceOppositeDirection()
    {
        // Arrange
        var clockwise = new Rotation(RotationAxis.Y, RotationDirection.Clockwise);
        var counterClockwise = new Rotation(RotationAxis.Y, RotationDirection.CounterClockwise);
        var double180 = new Rotation(RotationAxis.Y, RotationDirection.Double);

        // Act & Assert
        Assert.Equal(RotationDirection.CounterClockwise, clockwise.GetInverse().Direction);
        Assert.Equal(RotationDirection.Clockwise, counterClockwise.GetInverse().Direction);
        Assert.Equal(RotationDirection.Double, double180.GetInverse().Direction);
    }

    [Fact]
    public void Algorithm_WithMixedMovesAndRotations_ShouldApplyInSequence()
    {
        // Arrange
        var cube = GetSolvedCube();
        var algorithm = new Algorithm("x y' R U R' z2");

        // Act
        var result = algorithm.ApplyTo(cube);

        // Assert
        Assert.True(result.IsSuccess);
        
        // Verify the algorithm was applied by checking orientation changed
        var orientationInfo = cube.GetOrientationDebugInfo();
        // After x y' z2, the orientation should be significantly different from default
        Assert.DoesNotContain("Front position has: Green", orientationInfo);
    }

    #endregion

    #region Color Mapping Tests

    [Fact]
    public void GetColorForFace_ShouldReturnCorrectColors()
    {
        // Act & Assert - Western/BOY color scheme
        Assert.Equal("Green", Cube.GetColorForFace(CubeFace.Front));
        Assert.Equal("Orange", Cube.GetColorForFace(CubeFace.Right));
        Assert.Equal("Blue", Cube.GetColorForFace(CubeFace.Back));
        Assert.Equal("Red", Cube.GetColorForFace(CubeFace.Left));
        Assert.Equal("Yellow", Cube.GetColorForFace(CubeFace.Up));
        Assert.Equal("White", Cube.GetColorForFace(CubeFace.Down));
    }

    [Fact]
    public void GetFaceForColor_ShouldReturnCorrectFaces()
    {
        // Act & Assert - Western/BOY color scheme
        Assert.Equal(CubeFace.Front, Cube.GetFaceForColor("Green"));
        Assert.Equal(CubeFace.Left, Cube.GetFaceForColor("Red"));
        Assert.Equal(CubeFace.Back, Cube.GetFaceForColor("Blue"));
        Assert.Equal(CubeFace.Right, Cube.GetFaceForColor("Orange"));
        Assert.Equal(CubeFace.Up, Cube.GetFaceForColor("Yellow"));
        Assert.Equal(CubeFace.Down, Cube.GetFaceForColor("White"));
    }

    [Fact]
    public void ColorMapping_ShouldBeSymmetric()
    {
        // Arrange
        var faces = new[] { CubeFace.Front, CubeFace.Right, CubeFace.Back, CubeFace.Left, CubeFace.Up, CubeFace.Down };

        // Act & Assert - Face → Color → Face should be identity
        foreach (var face in faces)
        {
            var color = Cube.GetColorForFace(face);
            var faceFromColor = Cube.GetFaceForColor(color);
            Assert.Equal(face, faceFromColor);
        }
    }

    #endregion
}