using RubiksCube.Core.Models;
using RubiksCube.Tests.TestHelpers;
using Xunit;
using Xunit.Abstractions;

namespace RubiksCube.Tests.Models;

/// <summary>
/// Tests for cube construction and basic state validation
/// </summary>
public class CubeConstructionTests
{
    private readonly ITestOutputHelper _output;

    public CubeConstructionTests(ITestOutputHelper output)
    {
        _output = output;
    }

    [Fact]
    public void DefaultConstructor_ShouldCreateSolvedCube()
    {
        // Arrange & Act
        var cube = new Cube();

        // Assert
        Assert.True(cube.IsSolved());
        Assert.True(CubeStateValidator.IsSolved(cube));
        
        var isValid = CubeStateValidator.IsValidCubeState(cube, out string error);
        Assert.True(isValid, $"Cube state should be valid: {error}");
    }

    [Fact]
    public void DefaultConstructor_ShouldHaveCorrectColorScheme()
    {
        // Arrange & Act
        var cube = new Cube();

        // Assert - Check center stickers define face colors
        Assert.Equal(TestHelpers.TestHelpers.StandardColors.Front, cube.GetSticker(CubeFace.Front, 4));
        Assert.Equal(TestHelpers.TestHelpers.StandardColors.Back, cube.GetSticker(CubeFace.Back, 4));
        Assert.Equal(TestHelpers.TestHelpers.StandardColors.Right, cube.GetSticker(CubeFace.Right, 4)); // Orange
        Assert.Equal(TestHelpers.TestHelpers.StandardColors.Left, cube.GetSticker(CubeFace.Left, 4));   // Red
        Assert.Equal(TestHelpers.TestHelpers.StandardColors.Up, cube.GetSticker(CubeFace.Up, 4));
        Assert.Equal(TestHelpers.TestHelpers.StandardColors.Down, cube.GetSticker(CubeFace.Down, 4));
    }

    [Fact]
    public void DefaultConstructor_ShouldHaveAllStickersMatchingCenterColor()
    {
        // Arrange & Act
        var cube = new Cube();

        // Assert - Every sticker on each face should match the center color
        foreach (CubeFace face in Enum.GetValues<CubeFace>())
        {
            var expectedColor = TestHelpers.TestHelpers.GetSolvedFaceColor(face);
            var faceColors = cube.GetFace(face);
            
            for (int i = 0; i < 9; i++)
            {
                Assert.Equal(expectedColor, faceColors[i]);
            }
        }
    }

    [Fact]
    public void DefaultConstructor_ShouldHaveCorrectColorCounts()
    {
        // Arrange & Act
        var cube = new Cube();

        // Assert - Each color should appear exactly 9 times
        var colorCounts = new Dictionary<CubeColor, int>();
        foreach (CubeColor color in Enum.GetValues<CubeColor>())
        {
            colorCounts[color] = 0;
        }

        foreach (CubeFace face in Enum.GetValues<CubeFace>())
        {
            var faceColors = cube.GetFace(face);
            foreach (var color in faceColors)
            {
                colorCounts[color]++;
            }
        }

        foreach (var kvp in colorCounts)
        {
            Assert.Equal(9, kvp.Value);
        }
    }

    [Fact]
    public void Clone_ShouldCreateIndependentCopy()
    {
        // Arrange
        var originalCube = new Cube();
        
        // Modify the original
        originalCube.SetSticker(CubeFace.Front, 0, CubeColor.Red);

        // Act
        var clonedCube = originalCube.Clone();

        // Assert
        // Clone should have the modification
        Assert.Equal(CubeColor.Red, clonedCube.GetSticker(CubeFace.Front, 0));
        
        // Further modifications to original should not affect clone
        originalCube.SetSticker(CubeFace.Front, 1, CubeColor.Blue);
        Assert.Equal(CubeColor.Green, clonedCube.GetSticker(CubeFace.Front, 1));
        
        // Clone should not be solved anymore (due to mixed colors)
        Assert.False(clonedCube.IsSolved());
    }

    [Fact]
    public void IsSolved_ShouldReturnFalse_WhenCubeIsScrambled()
    {
        // Arrange
        var cube = new Cube();
        
        // Act - Apply some moves to scramble
        cube.ApplyMove(new Move(CubeFace.Right, MoveType.Clockwise));
        cube.ApplyMove(new Move(CubeFace.Up, MoveType.Clockwise));

        // Assert
        Assert.False(cube.IsSolved());
        Assert.False(CubeStateValidator.IsSolved(cube));
        
        // Should still be a valid cube state
        var isValid = CubeStateValidator.IsValidCubeState(cube, out string error);
        Assert.True(isValid, $"Scrambled cube should still be valid: {error}");
    }

    [Fact]
    public void IsSolved_ShouldReturnTrue_AfterApplyingMoveAndItsInverse()
    {
        // Arrange
        var cube = new Cube();
        var move = new Move(CubeFace.Right, MoveType.Clockwise);
        var inverseMove = move.GetInverse();

        // Act
        cube.ApplyMove(move);
        cube.ApplyMove(inverseMove);

        // Assert
        Assert.True(cube.IsSolved());
        Assert.True(CubeStateValidator.IsSolved(cube));
    }

    [Fact]
    public void IsSolved_ShouldReturnTrue_AfterApplyingFourClockwiseMoves()
    {
        // Arrange
        var cube = new Cube();
        var move = new Move(CubeFace.Right, MoveType.Clockwise);

        // Act - Apply same move 4 times (should return to solved)
        for (int i = 0; i < 4; i++)
        {
            cube.ApplyMove(move);
        }

        // Assert
        Assert.True(cube.IsSolved());
    }

    [Theory]
    [InlineData(CubeFace.Right)]
    [InlineData(CubeFace.Left)]
    [InlineData(CubeFace.Up)]
    [InlineData(CubeFace.Down)]
    [InlineData(CubeFace.Front)]
    [InlineData(CubeFace.Back)]
    public void FourClockwiseMoves_ShouldReturnToSolvedState_ForAllFaces(CubeFace face)
    {
        // Arrange
        var cube = new Cube();
        var move = new Move(face, MoveType.Clockwise);

        // Act
        for (int i = 0; i < 4; i++)
        {
            cube.ApplyMove(move);
        }

        // Assert
        Assert.True(cube.IsSolved(), $"Four {face} moves should return cube to solved state");
    }

    [Fact]
    public void ValidateCubeIntegrity_ShouldPass_ForFreshCube()
    {
        // Arrange & Act
        var cube = new Cube();

        // Assert
        var isValidEdges = CubeStateValidator.ValidateEdgePieces(cube, out string edgeError);
        Assert.True(isValidEdges, $"Edge pieces should be valid: {edgeError}");

        var isValidState = CubeStateValidator.IsValidCubeState(cube, out string stateError);
        Assert.True(isValidState, $"Cube state should be valid: {stateError}");
    }
}