using RubiksCube.Core.Models;
using RubiksCube.Core.Display;
using RubiksCube.Core.Configuration;
using Xunit;
using Xunit.Abstractions;

namespace RubiksCube.Tests.Models;

public class TransformationDemoTests
{
    private readonly ITestOutputHelper _output;

    public TransformationDemoTests(ITestOutputHelper output)
    {
        _output = output;
    }

    [Fact]
    public void Demonstrate_CubeTransformations_ProperInverseSequence()
    {
        var cube = new Cube();
        var config = new DisplayConfig { Format = DisplayFormat.ASCII };

        _output.WriteLine("=== SOLVED CUBE ===");
        var result1 = DisplayService.DisplayCubeWithConfig(cube, config);
        Assert.True(result1.IsSuccess);
        _output.WriteLine(result1.Value);

        _output.WriteLine("\n=== AFTER U MOVE (Top layer clockwise) ===");
        cube.ApplyMove(new Move(CubeFace.Up, MoveType.Clockwise));
        var result2 = DisplayService.DisplayCubeWithConfig(cube, config);
        Assert.True(result2.IsSuccess);
        _output.WriteLine(result2.Value);

        _output.WriteLine("\n=== AFTER R MOVE (Right face clockwise) ===");
        cube.ApplyMove(new Move(CubeFace.Right, MoveType.Clockwise));
        var result3 = DisplayService.DisplayCubeWithConfig(cube, config);
        Assert.True(result3.IsSuccess);
        _output.WriteLine(result3.Value);

        _output.WriteLine("\n=== AFTER R' MOVE (Right face counter-clockwise - correct inverse) ===");
        cube.ApplyMove(new Move(CubeFace.Right, MoveType.CounterClockwise));
        var result4 = DisplayService.DisplayCubeWithConfig(cube, config);
        Assert.True(result4.IsSuccess);
        _output.WriteLine(result4.Value);

        _output.WriteLine("\n=== AFTER U' MOVE (Top layer counter-clockwise - correct inverse) ===");
        cube.ApplyMove(new Move(CubeFace.Up, MoveType.CounterClockwise));
        var result5 = DisplayService.DisplayCubeWithConfig(cube, config);
        Assert.True(result5.IsSuccess);
        _output.WriteLine(result5.Value);

        _output.WriteLine("\n=== Should be back to SOLVED (U R -> R' U' is correct inverse) ===");
        
        // Verify that we're back to solved state using correct inverse sequence
        // This demonstrates proper cube algebra: to undo "A B", do "B' A'" (reverse order)
        Assert.True(cube.IsSolved());
    }

    [Fact]
    public void Demonstrate_ComplexAlgorithm_SexyMove()
    {
        var cube = new Cube();
        var config = new DisplayConfig { Format = DisplayFormat.ASCII };

        _output.WriteLine("=== SOLVED CUBE ===");
        var result1 = DisplayService.DisplayCubeWithConfig(cube, config);
        _output.WriteLine(result1.Value);

        // Apply the "Sexy Move" algorithm: R U R' U'
        _output.WriteLine("\n=== AFTER R MOVE ===");
        cube.ApplyMove(new Move(CubeFace.Right, MoveType.Clockwise));
        var result2 = DisplayService.DisplayCubeWithConfig(cube, config);
        _output.WriteLine(result2.Value);

        _output.WriteLine("\n=== AFTER R U MOVES ===");
        cube.ApplyMove(new Move(CubeFace.Up, MoveType.Clockwise));
        var result3 = DisplayService.DisplayCubeWithConfig(cube, config);
        _output.WriteLine(result3.Value);

        _output.WriteLine("\n=== AFTER R U R' MOVES ===");
        cube.ApplyMove(new Move(CubeFace.Right, MoveType.CounterClockwise));
        var result4 = DisplayService.DisplayCubeWithConfig(cube, config);
        _output.WriteLine(result4.Value);

        _output.WriteLine("\n=== AFTER COMPLETE SEXY MOVE: R U R' U' ===");
        cube.ApplyMove(new Move(CubeFace.Up, MoveType.CounterClockwise));
        var result5 = DisplayService.DisplayCubeWithConfig(cube, config);
        _output.WriteLine(result5.Value);

        // The cube should NOT be solved after one sexy move
        Assert.False(cube.IsSolved());
        
        // But after 6 repetitions, it should return to solved
        for (int i = 0; i < 5; i++) // 5 more times = 6 total
        {
            cube.ApplyMove(new Move(CubeFace.Right, MoveType.Clockwise));
            cube.ApplyMove(new Move(CubeFace.Up, MoveType.Clockwise));
            cube.ApplyMove(new Move(CubeFace.Right, MoveType.CounterClockwise));
            cube.ApplyMove(new Move(CubeFace.Up, MoveType.CounterClockwise));
        }

        _output.WriteLine("\n=== AFTER 6 SEXY MOVES (should be solved) ===");
        var resultFinal = DisplayService.DisplayCubeWithConfig(cube, config);
        _output.WriteLine(resultFinal.Value);
        
        Assert.True(cube.IsSolved());
    }
}