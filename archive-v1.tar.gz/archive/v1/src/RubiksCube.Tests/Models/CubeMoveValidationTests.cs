using RubiksCube.Core.Models;
using RubiksCube.Tests.TestHelpers;
using Xunit;
using Xunit.Abstractions;

namespace RubiksCube.Tests.Models;

/// <summary>
/// Tests for basic cube move operations with corrected implementations
/// L, D, F moves now rotate clockwise (FIXED)
/// </summary>
public class CubeMoveValidationTests
{
    private readonly ITestOutputHelper _output;

    public CubeMoveValidationTests(ITestOutputHelper output)
    {
        _output = output;
    }

    [Theory]
    [InlineData(CubeFace.Right, MoveType.Clockwise)]
    [InlineData(CubeFace.Left, MoveType.Clockwise)]
    [InlineData(CubeFace.Up, MoveType.Clockwise)]
    [InlineData(CubeFace.Down, MoveType.Clockwise)]
    [InlineData(CubeFace.Front, MoveType.Clockwise)]
    [InlineData(CubeFace.Back, MoveType.Clockwise)]
    public void Move_Clockwise_ShouldUseCorrectExpectedChanges(CubeFace face, MoveType moveType)
    {
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var move = new Move(face, moveType);
        var expectedData = MoveTestDataGenerator.GetMoveChanges(face, moveType);

        // Act
        cube.ApplyMove(move);

        // Assert
        foreach (var change in expectedData.Changes)
        {
            var actualColor = cube.GetSticker(change.Key.face, change.Key.position);
            Assert.Equal(change.Value.to, actualColor);
        }

        // Verify cube is still valid after move
        var isValid = CubeStateValidator.IsValidCubeState(cube, out string error);
        Assert.True(isValid, $"{face} {moveType} should result in valid cube state: {error}");

        // Output move diagram for debugging
        _output.WriteLine($"\n=== {face} {moveType} Move Test ===");
        _output.WriteLine(VisualDiagrams.CreateMoveEffectDiagram(move));
    }

    [Theory]
    [InlineData(CubeFace.Right)]
    [InlineData(CubeFace.Left)]
    [InlineData(CubeFace.Up)]
    [InlineData(CubeFace.Down)]
    [InlineData(CubeFace.Front)]
    [InlineData(CubeFace.Back)]
    public void Move_FourClockwiseApplications_ShouldReturnToSolvedState(CubeFace face)
    {
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var move = new Move(face, MoveType.Clockwise);

        // Act - Apply same move 4 times
        for (int i = 0; i < 4; i++)
        {
            cube.ApplyMove(move);
        }

        // Assert
        Assert.True(cube.IsSolved(), $"Four {face} clockwise moves should return to solved state");
        Assert.True(CubeStateValidator.IsSolved(cube), $"Cube should pass validator after four {face} moves");
    }

    [Theory]
    [InlineData(CubeFace.Right)]
    [InlineData(CubeFace.Left)]
    [InlineData(CubeFace.Up)]
    [InlineData(CubeFace.Down)]
    [InlineData(CubeFace.Front)]
    [InlineData(CubeFace.Back)]
    public void Move_ClockwiseThenCounterClockwise_ShouldReturnToOriginal(CubeFace face)
    {
        // Arrange
        var originalCube = TestHelpers.TestHelpers.CreateSolvedCube();
        var testCube = originalCube.Clone();
        var clockwiseMove = new Move(face, MoveType.Clockwise);
        var counterClockwiseMove = new Move(face, MoveType.CounterClockwise);

        // Act
        testCube.ApplyMove(clockwiseMove);
        testCube.ApplyMove(counterClockwiseMove);

        // Assert
        TestHelpers.TestHelpers.AssertCubesEqual(originalCube, testCube, 
            $"{face} move followed by {face}' should return to original state");
    }

    [Theory]
    [InlineData(CubeFace.Right)]
    [InlineData(CubeFace.Left)]
    [InlineData(CubeFace.Up)]
    [InlineData(CubeFace.Down)]
    [InlineData(CubeFace.Front)]
    [InlineData(CubeFace.Back)]
    public void Move_Double_ShouldEqualTwoClockwiseMoves(CubeFace face)
    {
        // Arrange
        var cube1 = TestHelpers.TestHelpers.CreateSolvedCube();
        var cube2 = TestHelpers.TestHelpers.CreateSolvedCube();
        var clockwiseMove = new Move(face, MoveType.Clockwise);
        var doubleMove = new Move(face, MoveType.Double);

        // Act
        cube1.ApplyMove(clockwiseMove);
        cube1.ApplyMove(clockwiseMove);
        cube2.ApplyMove(doubleMove);

        // Assert
        TestHelpers.TestHelpers.AssertCubesEqual(cube1, cube2, 
            $"{face}2 should equal two {face} moves");
    }

    [Fact]
    public void R_Move_ShouldAffectAdjacentFacesCorrectly()
    {
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var rMove = new Move(CubeFace.Right, MoveType.Clockwise);

        // Act
        cube.ApplyMove(rMove);

        // Assert - Check specific expected changes for R move
        // Right column of Front face should become White (from Down)
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Front, 2)); // Top right
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Front, 5)); // Middle right
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Front, 8)); // Bottom right

        // Right column of Up face should become Green (from Front)
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Up, 2)); // Top right
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Up, 5)); // Middle right
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Up, 8)); // Bottom right

        // Right face itself should still be all Orange
        var rightFace = cube.GetFace(CubeFace.Right);
        Assert.All(rightFace, color => Assert.Equal(CubeColor.Orange, color));
    }

    [Fact]
    public void L_Move_ShouldRotateClockwise_FIXED()
    {
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var lMove = new Move(CubeFace.Left, MoveType.Clockwise);

        // Act
        cube.ApplyMove(lMove);

        // Assert - L move now rotates clockwise (FIXED!)
        // Left column of Front face should become Yellow (from Up)
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Front, 0)); // Top left
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Front, 3)); // Middle left
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Front, 6)); // Bottom left

        // Left column of Down face should become Green (from Front)
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Down, 0)); // Top left
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Down, 3)); // Middle left
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Down, 6)); // Bottom left

        // Left face itself should still be all Red
        var leftFace = cube.GetFace(CubeFace.Left);
        Assert.All(leftFace, color => Assert.Equal(CubeColor.Red, color));
    }

    [Fact]
    public void D_Move_ShouldRotateClockwise_FIXED()
    {
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var dMove = new Move(CubeFace.Down, MoveType.Clockwise);

        // Act
        cube.ApplyMove(dMove);

        // Assert - D move rotates clockwise: Front -> Left -> Back -> Right -> Front
        // Bottom row of Front face should become Red (from Left)
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Front, 6)); // Bottom left
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Front, 7)); // Bottom center
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Front, 8)); // Bottom right

        // Bottom row of Right face should become Green (from Front)
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Right, 6)); // Bottom left
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Right, 7)); // Bottom center
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Right, 8)); // Bottom right

        // Bottom row of Back face should become Orange (from Right)
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Back, 6)); // Bottom left
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Back, 7)); // Bottom center
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Back, 8)); // Bottom right

        // Bottom row of Left face should become Blue (from Back)
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Left, 6)); // Bottom left
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Left, 7)); // Bottom center
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Left, 8)); // Bottom right

        // Down face itself should still be all White
        var downFace = cube.GetFace(CubeFace.Down);
        Assert.All(downFace, color => Assert.Equal(CubeColor.White, color));
    }

    [Fact]
    public void F_Move_ShouldRotateClockwise_FIXED()
    {
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var fMove = new Move(CubeFace.Front, MoveType.Clockwise);

        // Act
        cube.ApplyMove(fMove);

        // Assert - F move rotates clockwise: Up -> Left -> Down -> Right -> Up
        // Bottom row of Up face should become Red (from Left)
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Up, 6)); // Bottom left
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Up, 7)); // Bottom center
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Up, 8)); // Bottom right

        // Left right column should become White (from Down)
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Left, 2)); // Top right
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Left, 5)); // Middle right
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Left, 8)); // Bottom right

        // Top row of Down face should become Orange (from Right)
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Down, 0)); // Top left
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Down, 1)); // Top center
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Down, 2)); // Top right

        // Right left column should become Yellow (from Up)
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Right, 0)); // Top left
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Right, 3)); // Middle left
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Right, 6)); // Bottom left

        // Front face itself should still be all Green
        var frontFace = cube.GetFace(CubeFace.Front);
        Assert.All(frontFace, color => Assert.Equal(CubeColor.Green, color));
    }

    [Fact]
    public void U_Move_ShouldRotateClockwiseCorrectly()
    {
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var uMove = new Move(CubeFace.Up, MoveType.Clockwise);

        // Act
        cube.ApplyMove(uMove);

        // Assert - U move rotates clockwise
        // Top row of Front face should become Orange (from Right)
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Front, 0)); // Top left
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Front, 1)); // Top center
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Front, 2)); // Top right

        // Top row of Right face should become Blue (from Back)
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Right, 0)); // Top left
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Right, 1)); // Top center
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Right, 2)); // Top right

        // Up face itself should still be all Yellow
        var upFace = cube.GetFace(CubeFace.Up);
        Assert.All(upFace, color => Assert.Equal(CubeColor.Yellow, color));
    }

    [Fact]
    public void B_Move_ShouldRotateClockwiseCorrectly()
    {
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var bMove = new Move(CubeFace.Back, MoveType.Clockwise);

        // Act
        cube.ApplyMove(bMove);

        // Assert - B move rotates clockwise
        // Top row of Up face should become Orange (from Right)
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Up, 0)); // Top left
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Up, 1)); // Top center
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Up, 2)); // Top right

        // Bottom row of Down face should become Red (from Up)
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Down, 6)); // Bottom left
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Down, 7)); // Bottom center
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Down, 8)); // Bottom right

        // Back face itself should still be all Blue
        var backFace = cube.GetFace(CubeFace.Back);
        Assert.All(backFace, color => Assert.Equal(CubeColor.Blue, color));
    }

    [Fact]
    public void MoveInverse_ShouldMatchExpectedDirection()
    {
        // Arrange & Act & Assert
        var rMove = new Move(CubeFace.Right, MoveType.Clockwise);
        var rPrimeMove = rMove.GetInverse();
        Assert.Equal(MoveType.CounterClockwise, rPrimeMove.Type);

        var lPrimeMove = new Move(CubeFace.Left, MoveType.CounterClockwise);
        var lMove = lPrimeMove.GetInverse();
        Assert.Equal(MoveType.Clockwise, lMove.Type);

        var doubleMove = new Move(CubeFace.Up, MoveType.Double);
        var doubleMoveInverse = doubleMove.GetInverse();
        Assert.Equal(MoveType.Double, doubleMoveInverse.Type); // Double is its own inverse
    }

    [Fact]
    public void CounterClockwiseMoves_ShouldBeCorrectInverse()
    {
        // Test that counter-clockwise moves work as expected inverses
        // Especially important for L', D', F' which had bugs in original implementation

        foreach (CubeFace face in Enum.GetValues<CubeFace>())
        {
            // Arrange
            var originalCube = TestHelpers.TestHelpers.CreateSolvedCube();
            var testCube = originalCube.Clone();
            var clockwiseMove = new Move(face, MoveType.Clockwise);
            var counterClockwiseMove = new Move(face, MoveType.CounterClockwise);

            // Act
            testCube.ApplyMove(clockwiseMove);
            testCube.ApplyMove(counterClockwiseMove);

            // Assert
            TestHelpers.TestHelpers.AssertCubesEqual(originalCube, testCube, 
                $"{face} then {face}' should return to original (testing corrected implementation)");
        }
    }

    [Fact]
    public void EdgeCycleValidation_AllMoves_ShouldPreserveEdgePieces()
    {
        // Validate that all moves preserve edge piece integrity
        var moves = new[]
        {
            new Move(CubeFace.Right, MoveType.Clockwise),
            new Move(CubeFace.Left, MoveType.Clockwise), // FIXED
            new Move(CubeFace.Up, MoveType.Clockwise),
            new Move(CubeFace.Down, MoveType.Clockwise), // FIXED
            new Move(CubeFace.Front, MoveType.Clockwise), // FIXED
            new Move(CubeFace.Back, MoveType.Clockwise)
        };

        foreach (var move in moves)
        {
            // Arrange
            var cube = TestHelpers.TestHelpers.CreateSolvedCube();

            // Act
            cube.ApplyMove(move);

            // Assert
            var isValidEdges = CubeStateValidator.ValidateEdgePieces(cube, out string edgeError);
            Assert.True(isValidEdges, $"{move} should preserve edge piece integrity: {edgeError}");

            var isValidState = CubeStateValidator.IsValidCubeState(cube, out string stateError);
            Assert.True(isValidState, $"{move} should result in valid cube state: {stateError}");
        }
    }

    [Fact]
    public void RPrime_Move_ShouldRotateCounterClockwise()
    {
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var rPrimeMove = new Move(CubeFace.Right, MoveType.CounterClockwise);

        // Act
        cube.ApplyMove(rPrimeMove);

        // Assert - R' move rotates counter-clockwise: Up -> Front -> Down -> Back -> Up
        // Right column of Up face should become Blue (from Back)
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Up, 2)); // Top right
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Up, 5)); // Middle right
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Up, 8)); // Bottom right

        // Right column of Front face should become Yellow (from Up)
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Front, 2)); // Top right
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Front, 5)); // Middle right
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Front, 8)); // Bottom right

        // Right column of Down face should become Green (from Front)
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Down, 2)); // Top right
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Down, 5)); // Middle right
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Down, 8)); // Bottom right

        // Right column of Back face should become White (from Down)
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Back, 0)); // Top left (back perspective)
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Back, 3)); // Middle left
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Back, 6)); // Bottom left

        // Right face itself should still be all Orange
        var rightFace = cube.GetFace(CubeFace.Right);
        Assert.All(rightFace, color => Assert.Equal(CubeColor.Orange, color));
    }

    [Fact]
    public void LPrime_Move_ShouldRotateCounterClockwise()
    {
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var lPrimeMove = new Move(CubeFace.Left, MoveType.CounterClockwise);

        // Act
        cube.ApplyMove(lPrimeMove);

        // Assert - L' move rotates counter-clockwise: Up -> Back -> Down -> Front -> Up
        // Left column of Up face should become Green (from Front)
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Up, 0)); // Top left
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Up, 3)); // Middle left
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Up, 6)); // Bottom left

        // Left column of Back face should become Yellow (from Up)
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Back, 2)); // Top right (back perspective)
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Back, 5)); // Middle right
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Back, 8)); // Bottom right

        // Left column of Down face should become Blue (from Back)
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Down, 0)); // Top left
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Down, 3)); // Middle left
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Down, 6)); // Bottom left

        // Left column of Front face should become White (from Down)
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Front, 0)); // Top left
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Front, 3)); // Middle left
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Front, 6)); // Bottom left

        // Left face itself should still be all Red
        var leftFace = cube.GetFace(CubeFace.Left);
        Assert.All(leftFace, color => Assert.Equal(CubeColor.Red, color));
    }

    [Fact]
    public void UPrime_Move_ShouldRotateCounterClockwise()
    {
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var uPrimeMove = new Move(CubeFace.Up, MoveType.CounterClockwise);

        // Act
        cube.ApplyMove(uPrimeMove);

        // Assert - U' move rotates counter-clockwise: Front -> Right -> Back -> Left -> Front
        // Top row of Front face should become Red (from Left)
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Front, 0)); // Top left
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Front, 1)); // Top center
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Front, 2)); // Top right

        // Top row of Right face should become Green (from Front)
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Right, 0)); // Top left
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Right, 1)); // Top center
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Right, 2)); // Top right

        // Top row of Back face should become Orange (from Right)
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Back, 0)); // Top left
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Back, 1)); // Top center
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Back, 2)); // Top right

        // Top row of Left face should become Blue (from Back)
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Left, 0)); // Top left
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Left, 1)); // Top center
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Left, 2)); // Top right

        // Up face itself should still be all Yellow
        var upFace = cube.GetFace(CubeFace.Up);
        Assert.All(upFace, color => Assert.Equal(CubeColor.Yellow, color));
    }

    [Fact]
    public void DPrime_Move_ShouldRotateCounterClockwise()
    {
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var dPrimeMove = new Move(CubeFace.Down, MoveType.CounterClockwise);

        // Act
        cube.ApplyMove(dPrimeMove);

        // Assert - D' move rotates counter-clockwise: Front -> Left -> Back -> Right -> Front
        // Bottom row of Front face should become Orange (from Right)
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Front, 6)); // Bottom left
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Front, 7)); // Bottom center
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Front, 8)); // Bottom right

        // Bottom row of Left face should become Green (from Front)
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Left, 6)); // Bottom left
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Left, 7)); // Bottom center
        Assert.Equal(CubeColor.Green, cube.GetSticker(CubeFace.Left, 8)); // Bottom right

        // Bottom row of Back face should become Red (from Left)
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Back, 6)); // Bottom left
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Back, 7)); // Bottom center
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Back, 8)); // Bottom right

        // Bottom row of Right face should become Blue (from Back)
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Right, 6)); // Bottom left
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Right, 7)); // Bottom center
        Assert.Equal(CubeColor.Blue, cube.GetSticker(CubeFace.Right, 8)); // Bottom right

        // Down face itself should still be all White
        var downFace = cube.GetFace(CubeFace.Down);
        Assert.All(downFace, color => Assert.Equal(CubeColor.White, color));
    }

    [Fact]
    public void FPrime_Move_ShouldRotateCounterClockwise()
    {
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var fPrimeMove = new Move(CubeFace.Front, MoveType.CounterClockwise);

        // Act
        cube.ApplyMove(fPrimeMove);

        // Assert - F' move rotates counter-clockwise: Up -> Right -> Down -> Left -> Up
        // Bottom row of Up face should become Orange (from Right)
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Up, 6)); // Bottom left
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Up, 7)); // Bottom center
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Up, 8)); // Bottom right

        // Left column of Right face should become White (from Down)
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Right, 0)); // Top left
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Right, 3)); // Middle left
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Right, 6)); // Bottom left

        // Top row of Down face should become Red (from Left)
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Down, 0)); // Top left
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Down, 1)); // Top center
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Down, 2)); // Top right

        // Right column of Left face should become Yellow (from Up)
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Left, 2)); // Top right
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Left, 5)); // Middle right
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Left, 8)); // Bottom right

        // Front face itself should still be all Green
        var frontFace = cube.GetFace(CubeFace.Front);
        Assert.All(frontFace, color => Assert.Equal(CubeColor.Green, color));
    }

    [Fact]
    public void BPrime_Move_ShouldRotateCounterClockwise()
    {
        // Arrange
        var cube = TestHelpers.TestHelpers.CreateSolvedCube();
        var bPrimeMove = new Move(CubeFace.Back, MoveType.CounterClockwise);

        // Act
        cube.ApplyMove(bPrimeMove);

        // Assert - B' move rotates counter-clockwise: Up -> Left -> Down -> Right -> Up
        // Top row of Up face should become Red (from Left)
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Up, 0)); // Top left
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Up, 1)); // Top center
        Assert.Equal(CubeColor.Red, cube.GetSticker(CubeFace.Up, 2)); // Top right

        // Left column of Left face should become White (from Down)
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Left, 0)); // Top left
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Left, 3)); // Middle left
        Assert.Equal(CubeColor.White, cube.GetSticker(CubeFace.Left, 6)); // Bottom left

        // Bottom row of Down face should become Orange (from Right)
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Down, 6)); // Bottom left
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Down, 7)); // Bottom center
        Assert.Equal(CubeColor.Orange, cube.GetSticker(CubeFace.Down, 8)); // Bottom right

        // Right column of Right face should become Yellow (from Up)
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Right, 2)); // Top right
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Right, 5)); // Middle right
        Assert.Equal(CubeColor.Yellow, cube.GetSticker(CubeFace.Right, 8)); // Bottom right

        // Back face itself should still be all Blue
        var backFace = cube.GetFace(CubeFace.Back);
        Assert.All(backFace, color => Assert.Equal(CubeColor.Blue, color));
    }
}