using RubiksCube.Core.Models;
using Xunit;

namespace RubiksCube.Tests.Models;

public class CubeOrientationTests
{
    private static CubeOrientation GetDefaultOrientation() => new();

    #region Basic Orientation Tests

    [Fact]
    public void DefaultOrientation_ShouldMapEachPositionToItself()
    {
        // Arrange
        var orientation = GetDefaultOrientation();

        // Act & Assert - Each position should map to itself initially
        Assert.Equal(CubeFace.Front, orientation.GetFaceAt(CubeFace.Front));
        Assert.Equal(CubeFace.Right, orientation.GetFaceAt(CubeFace.Right));
        Assert.Equal(CubeFace.Back, orientation.GetFaceAt(CubeFace.Back));
        Assert.Equal(CubeFace.Left, orientation.GetFaceAt(CubeFace.Left));
        Assert.Equal(CubeFace.Up, orientation.GetFaceAt(CubeFace.Up));
        Assert.Equal(CubeFace.Down, orientation.GetFaceAt(CubeFace.Down));
    }

    [Fact]
    public void Clone_ShouldCreateIdenticalOrientation()
    {
        // Arrange
        var original = GetDefaultOrientation();
        original.ApplyYRotation(RotationDirection.Clockwise);

        // Act
        var clone = original.Clone();

        // Assert - Clone should have same mappings as original
        Assert.Equal(original.GetFaceAt(CubeFace.Front), clone.GetFaceAt(CubeFace.Front));
        Assert.Equal(original.GetFaceAt(CubeFace.Right), clone.GetFaceAt(CubeFace.Right));
        Assert.Equal(original.GetFaceAt(CubeFace.Back), clone.GetFaceAt(CubeFace.Back));
        Assert.Equal(original.GetFaceAt(CubeFace.Left), clone.GetFaceAt(CubeFace.Left));
        Assert.Equal(original.GetFaceAt(CubeFace.Up), clone.GetFaceAt(CubeFace.Up));
        Assert.Equal(original.GetFaceAt(CubeFace.Down), clone.GetFaceAt(CubeFace.Down));
    }

    #endregion

    #region Y Rotation Tests

    [Fact]
    public void Y_Clockwise_ShouldRotateHorizontalFacesCorrectly()
    {
        // Arrange
        var orientation = GetDefaultOrientation();

        // Act
        orientation.ApplyYRotation(RotationDirection.Clockwise);

        // Assert - Y rotation: Front → Left → Back → Right → Front (follows U direction)
        Assert.Equal(CubeFace.Right, orientation.GetFaceAt(CubeFace.Front)); // Front gets Right
        Assert.Equal(CubeFace.Back, orientation.GetFaceAt(CubeFace.Right));  // Right gets Back  
        Assert.Equal(CubeFace.Left, orientation.GetFaceAt(CubeFace.Back));   // Back gets Left
        Assert.Equal(CubeFace.Front, orientation.GetFaceAt(CubeFace.Left));  // Left gets Front

        // Up and Down should be unchanged
        Assert.Equal(CubeFace.Up, orientation.GetFaceAt(CubeFace.Up));
        Assert.Equal(CubeFace.Down, orientation.GetFaceAt(CubeFace.Down));
    }

    [Fact]
    public void Y_CounterClockwise_ShouldRotateHorizontalFacesCorrectly()
    {
        // Arrange
        var orientation = GetDefaultOrientation();

        // Act
        orientation.ApplyYRotation(RotationDirection.CounterClockwise);

        // Assert - Y' rotation: Front → Right → Back → Left → Front (opposite of U)
        Assert.Equal(CubeFace.Left, orientation.GetFaceAt(CubeFace.Front));  // Front gets Left
        Assert.Equal(CubeFace.Front, orientation.GetFaceAt(CubeFace.Right)); // Right gets Front
        Assert.Equal(CubeFace.Right, orientation.GetFaceAt(CubeFace.Back));  // Back gets Right
        Assert.Equal(CubeFace.Back, orientation.GetFaceAt(CubeFace.Left));   // Left gets Back

        // Up and Down should be unchanged
        Assert.Equal(CubeFace.Up, orientation.GetFaceAt(CubeFace.Up));
        Assert.Equal(CubeFace.Down, orientation.GetFaceAt(CubeFace.Down));
    }

    [Fact]
    public void Y2_Double_ShouldSwapOppositeFaces()
    {
        // Arrange
        var orientation = GetDefaultOrientation();

        // Act
        orientation.ApplyYRotation(RotationDirection.Double);

        // Assert - Y2 rotation: Front ↔ Back, Left ↔ Right
        Assert.Equal(CubeFace.Back, orientation.GetFaceAt(CubeFace.Front));  // Front gets Back
        Assert.Equal(CubeFace.Left, orientation.GetFaceAt(CubeFace.Right));  // Right gets Left
        Assert.Equal(CubeFace.Front, orientation.GetFaceAt(CubeFace.Back));  // Back gets Front
        Assert.Equal(CubeFace.Right, orientation.GetFaceAt(CubeFace.Left));  // Left gets Right

        // Up and Down should be unchanged
        Assert.Equal(CubeFace.Up, orientation.GetFaceAt(CubeFace.Up));
        Assert.Equal(CubeFace.Down, orientation.GetFaceAt(CubeFace.Down));
    }

    [Fact]
    public void Y_FourRotations_ShouldReturnToOriginal()
    {
        // Arrange
        var orientation = GetDefaultOrientation();

        // Act - Apply Y rotation four times
        orientation.ApplyYRotation(RotationDirection.Clockwise);
        orientation.ApplyYRotation(RotationDirection.Clockwise);
        orientation.ApplyYRotation(RotationDirection.Clockwise);
        orientation.ApplyYRotation(RotationDirection.Clockwise);

        // Assert - Should be back to original state
        Assert.Equal(CubeFace.Front, orientation.GetFaceAt(CubeFace.Front));
        Assert.Equal(CubeFace.Right, orientation.GetFaceAt(CubeFace.Right));
        Assert.Equal(CubeFace.Back, orientation.GetFaceAt(CubeFace.Back));
        Assert.Equal(CubeFace.Left, orientation.GetFaceAt(CubeFace.Left));
        Assert.Equal(CubeFace.Up, orientation.GetFaceAt(CubeFace.Up));
        Assert.Equal(CubeFace.Down, orientation.GetFaceAt(CubeFace.Down));
    }

    [Fact]
    public void Y_ThenPrime_ShouldReturnToOriginal()
    {
        // Arrange
        var orientation = GetDefaultOrientation();

        // Act - Apply Y then Y'
        orientation.ApplyYRotation(RotationDirection.Clockwise);
        orientation.ApplyYRotation(RotationDirection.CounterClockwise);

        // Assert - Should be back to original state
        Assert.Equal(CubeFace.Front, orientation.GetFaceAt(CubeFace.Front));
        Assert.Equal(CubeFace.Right, orientation.GetFaceAt(CubeFace.Right));
        Assert.Equal(CubeFace.Back, orientation.GetFaceAt(CubeFace.Back));
        Assert.Equal(CubeFace.Left, orientation.GetFaceAt(CubeFace.Left));
        Assert.Equal(CubeFace.Up, orientation.GetFaceAt(CubeFace.Up));
        Assert.Equal(CubeFace.Down, orientation.GetFaceAt(CubeFace.Down));
    }

    #endregion

    #region X Rotation Tests

    [Fact]
    public void X_Clockwise_ShouldRotateVerticalFacesCorrectly()
    {
        // Arrange
        var orientation = GetDefaultOrientation();

        // Act
        orientation.ApplyXRotation(RotationDirection.Clockwise);

        // Assert - X rotation: Front → Up → Back → Down → Front
        Assert.Equal(CubeFace.Down, orientation.GetFaceAt(CubeFace.Front)); // Front gets Down
        Assert.Equal(CubeFace.Front, orientation.GetFaceAt(CubeFace.Up));   // Up gets Front
        Assert.Equal(CubeFace.Up, orientation.GetFaceAt(CubeFace.Back));    // Back gets Up
        Assert.Equal(CubeFace.Back, orientation.GetFaceAt(CubeFace.Down));  // Down gets Back

        // Left and Right should be unchanged
        Assert.Equal(CubeFace.Left, orientation.GetFaceAt(CubeFace.Left));
        Assert.Equal(CubeFace.Right, orientation.GetFaceAt(CubeFace.Right));
    }

    [Fact]
    public void X_CounterClockwise_ShouldRotateVerticalFacesCorrectly()
    {
        // Arrange
        var orientation = GetDefaultOrientation();

        // Act
        orientation.ApplyXRotation(RotationDirection.CounterClockwise);

        // Assert - X' rotation: Front → Down → Back → Up → Front
        Assert.Equal(CubeFace.Up, orientation.GetFaceAt(CubeFace.Front));   // Front gets Up
        Assert.Equal(CubeFace.Back, orientation.GetFaceAt(CubeFace.Up));    // Up gets Back
        Assert.Equal(CubeFace.Down, orientation.GetFaceAt(CubeFace.Back));  // Back gets Down
        Assert.Equal(CubeFace.Front, orientation.GetFaceAt(CubeFace.Down)); // Down gets Front

        // Left and Right should be unchanged
        Assert.Equal(CubeFace.Left, orientation.GetFaceAt(CubeFace.Left));
        Assert.Equal(CubeFace.Right, orientation.GetFaceAt(CubeFace.Right));
    }

    [Fact]
    public void X2_Double_ShouldSwapOppositeFaces()
    {
        // Arrange
        var orientation = GetDefaultOrientation();

        // Act
        orientation.ApplyXRotation(RotationDirection.Double);

        // Assert - X2 rotation: Front ↔ Back, Up ↔ Down
        Assert.Equal(CubeFace.Back, orientation.GetFaceAt(CubeFace.Front)); // Front gets Back
        Assert.Equal(CubeFace.Down, orientation.GetFaceAt(CubeFace.Up));    // Up gets Down
        Assert.Equal(CubeFace.Front, orientation.GetFaceAt(CubeFace.Back)); // Back gets Front
        Assert.Equal(CubeFace.Up, orientation.GetFaceAt(CubeFace.Down));    // Down gets Up

        // Left and Right should be unchanged
        Assert.Equal(CubeFace.Left, orientation.GetFaceAt(CubeFace.Left));
        Assert.Equal(CubeFace.Right, orientation.GetFaceAt(CubeFace.Right));
    }

    #endregion

    #region Z Rotation Tests

    [Fact]
    public void Z_Clockwise_ShouldRotateFrontalFacesCorrectly()
    {
        // Arrange
        var orientation = GetDefaultOrientation();

        // Act
        orientation.ApplyZRotation(RotationDirection.Clockwise);

        // Assert - Z rotation: U → L → D → R → U (clockwise when viewed from front, follows F direction)
        Assert.Equal(CubeFace.Left, orientation.GetFaceAt(CubeFace.Up));    // Up gets Left
        Assert.Equal(CubeFace.Up, orientation.GetFaceAt(CubeFace.Right));   // Right gets Up
        Assert.Equal(CubeFace.Right, orientation.GetFaceAt(CubeFace.Down)); // Down gets Right
        Assert.Equal(CubeFace.Down, orientation.GetFaceAt(CubeFace.Left));  // Left gets Down

        // Front and Back should be unchanged
        Assert.Equal(CubeFace.Front, orientation.GetFaceAt(CubeFace.Front));
        Assert.Equal(CubeFace.Back, orientation.GetFaceAt(CubeFace.Back));
    }

    [Fact]
    public void Z_CounterClockwise_ShouldRotateFrontalFacesCorrectly()
    {
        // Arrange
        var orientation = GetDefaultOrientation();

        // Act
        orientation.ApplyZRotation(RotationDirection.CounterClockwise);

        // Assert - Z' rotation: U → R → D → L → U (counter-clockwise when viewed from front)
        Assert.Equal(CubeFace.Right, orientation.GetFaceAt(CubeFace.Up));   // Up gets Right
        Assert.Equal(CubeFace.Down, orientation.GetFaceAt(CubeFace.Right)); // Right gets Down
        Assert.Equal(CubeFace.Left, orientation.GetFaceAt(CubeFace.Down));  // Down gets Left
        Assert.Equal(CubeFace.Up, orientation.GetFaceAt(CubeFace.Left));    // Left gets Up

        // Front and Back should be unchanged
        Assert.Equal(CubeFace.Front, orientation.GetFaceAt(CubeFace.Front));
        Assert.Equal(CubeFace.Back, orientation.GetFaceAt(CubeFace.Back));
    }

    [Fact]
    public void Z2_Double_ShouldSwapOppositeFaces()
    {
        // Arrange
        var orientation = GetDefaultOrientation();

        // Act
        orientation.ApplyZRotation(RotationDirection.Double);

        // Assert - Z2 rotation: Up ↔ Down, Left ↔ Right
        Assert.Equal(CubeFace.Down, orientation.GetFaceAt(CubeFace.Up));    // Up gets Down
        Assert.Equal(CubeFace.Left, orientation.GetFaceAt(CubeFace.Right)); // Right gets Left
        Assert.Equal(CubeFace.Up, orientation.GetFaceAt(CubeFace.Down));    // Down gets Up
        Assert.Equal(CubeFace.Right, orientation.GetFaceAt(CubeFace.Left)); // Left gets Right

        // Front and Back should be unchanged
        Assert.Equal(CubeFace.Front, orientation.GetFaceAt(CubeFace.Front));
        Assert.Equal(CubeFace.Back, orientation.GetFaceAt(CubeFace.Back));
    }

    #endregion

    #region Composition Tests

    [Fact]
    public void Y_ThenY_ShouldEqualY2()
    {
        // Arrange
        var orientation1 = GetDefaultOrientation();
        var orientation2 = GetDefaultOrientation();

        // Act
        orientation1.ApplyYRotation(RotationDirection.Clockwise);
        orientation1.ApplyYRotation(RotationDirection.Clockwise);

        orientation2.ApplyYRotation(RotationDirection.Double);

        // Assert - Two Y rotations should equal one Y2
        Assert.Equal(orientation2.GetFaceAt(CubeFace.Front), orientation1.GetFaceAt(CubeFace.Front));
        Assert.Equal(orientation2.GetFaceAt(CubeFace.Right), orientation1.GetFaceAt(CubeFace.Right));
        Assert.Equal(orientation2.GetFaceAt(CubeFace.Back), orientation1.GetFaceAt(CubeFace.Back));
        Assert.Equal(orientation2.GetFaceAt(CubeFace.Left), orientation1.GetFaceAt(CubeFace.Left));
        Assert.Equal(orientation2.GetFaceAt(CubeFace.Up), orientation1.GetFaceAt(CubeFace.Up));
        Assert.Equal(orientation2.GetFaceAt(CubeFace.Down), orientation1.GetFaceAt(CubeFace.Down));
    }

    [Fact]
    public void X_Y_Z_MultipleRotations_ShouldComposeCorrectly()
    {
        // Arrange
        var orientation = GetDefaultOrientation();

        // Act - Apply a sequence of rotations
        orientation.ApplyXRotation(RotationDirection.Clockwise);  // x
        orientation.ApplyYRotation(RotationDirection.CounterClockwise); // y'
        orientation.ApplyZRotation(RotationDirection.Double);     // z2

        // Assert - Verify the final state
        // This is a complex composition, so we'll verify each face maps to something valid
        var frontMapping = orientation.GetFaceAt(CubeFace.Front);
        var rightMapping = orientation.GetFaceAt(CubeFace.Right);
        var backMapping = orientation.GetFaceAt(CubeFace.Back);
        var leftMapping = orientation.GetFaceAt(CubeFace.Left);
        var upMapping = orientation.GetFaceAt(CubeFace.Up);
        var downMapping = orientation.GetFaceAt(CubeFace.Down);

        // All mappings should be valid faces
        Assert.True(Enum.IsDefined(typeof(CubeFace), frontMapping));
        Assert.True(Enum.IsDefined(typeof(CubeFace), rightMapping));
        Assert.True(Enum.IsDefined(typeof(CubeFace), backMapping));
        Assert.True(Enum.IsDefined(typeof(CubeFace), leftMapping));
        Assert.True(Enum.IsDefined(typeof(CubeFace), upMapping));
        Assert.True(Enum.IsDefined(typeof(CubeFace), downMapping));

        // Each face should map to exactly one position (bijection)
        var mappedFaces = new[] { frontMapping, rightMapping, backMapping, leftMapping, upMapping, downMapping };
        Assert.Equal(6, mappedFaces.Distinct().Count());
    }

    #endregion

    #region Color-Based Orientation Tests

    [Fact]
    public void SetOrientationFromColors_ShouldMapCorrectly()
    {
        // Arrange
        var orientation = GetDefaultOrientation();
        var colorMapping = new Dictionary<string, string>
        {
            { "front", "Red" },    // Red face in front position
            { "right", "Blue" },   // Blue face in right position  
            { "back", "Orange" },  // Orange face in back position
            { "left", "Green" },   // Green face in left position
            { "up", "Yellow" },    // Yellow face in up position
            { "down", "White" }    // White face in down position
        };

        // Act
        orientation.SetOrientationFromColors(colorMapping);

        // Assert - Verify mapping (Red=Left face, Blue=Back face, etc.)
        Assert.Equal(CubeFace.Left, orientation.GetFaceAt(CubeFace.Front));  // Front has Red (Left face)
        Assert.Equal(CubeFace.Back, orientation.GetFaceAt(CubeFace.Right));  // Right has Blue (Back face)
        Assert.Equal(CubeFace.Right, orientation.GetFaceAt(CubeFace.Back));  // Back has Orange (Right face)
        Assert.Equal(CubeFace.Front, orientation.GetFaceAt(CubeFace.Left));  // Left has Green (Front face)
        Assert.Equal(CubeFace.Up, orientation.GetFaceAt(CubeFace.Up));       // Up has Yellow (Up face)
        Assert.Equal(CubeFace.Down, orientation.GetFaceAt(CubeFace.Down));   // Down has White (Down face)
    }

    [Fact]
    public void SetOrientationFromColors_WithInvalidColor_ShouldIgnoreInvalidEntries()
    {
        // Arrange
        var orientation = GetDefaultOrientation();
        var colorMapping = new Dictionary<string, string>
        {
            { "front", "Red" },
            { "right", "InvalidColor" }, // Invalid color
            { "back", "Orange" },
            { "invalidPosition", "Blue" }, // Invalid position
            { "up", "Yellow" },
            { "down", "White" }
        };

        // Act
        orientation.SetOrientationFromColors(colorMapping);

        // Assert - Valid entries should be applied, invalid entries ignored
        Assert.Equal(CubeFace.Left, orientation.GetFaceAt(CubeFace.Front));  // Front has Red (Left face)
        Assert.Equal(CubeFace.Right, orientation.GetFaceAt(CubeFace.Right)); // Right unchanged (invalid color)
        Assert.Equal(CubeFace.Right, orientation.GetFaceAt(CubeFace.Back));  // Back has Orange (Right face)
        Assert.Equal(CubeFace.Left, orientation.GetFaceAt(CubeFace.Left));   // Left unchanged
        Assert.Equal(CubeFace.Up, orientation.GetFaceAt(CubeFace.Up));       // Up has Yellow
        Assert.Equal(CubeFace.Down, orientation.GetFaceAt(CubeFace.Down));   // Down has White
    }

    #endregion
}