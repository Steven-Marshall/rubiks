using RubiksCube.Core.Configuration;

namespace RubiksCube.Tests.Configuration;

public class ConfigurationManagerTests
{
    [Fact]
    public void GetConfigDirectory_ShouldReturnValidPath()
    {
        var configDir = ConfigurationManager.GetConfigDirectory();
        
        Assert.NotNull(configDir);
        Assert.NotEmpty(configDir);
        
        // Should contain appropriate directory name
        Assert.True(configDir.Contains("RubiksCube") || configDir.Contains("rubiks"));
    }

    [Fact]
    public void GetConfigFilePath_ShouldReturnValidPath()
    {
        var configPath = ConfigurationManager.GetConfigFilePath();
        
        Assert.NotNull(configPath);
        Assert.EndsWith("config.json", configPath);
    }

    [Fact]
    public void LoadDisplayConfig_WithoutExistingFile_ShouldReturnDefaultConfig()
    {
        // Clean up any existing config first
        ConfigurationManager.DeleteConfig();
        
        var result = ConfigurationManager.LoadDisplayConfig();
        
        Assert.True(result.IsSuccess);
        Assert.Equal(DisplayFormat.Unicode, result.Value.Format);
        Assert.Equal("🔳", result.Value.Squares.White);
    }

    [Fact]
    public void SaveAndLoadDisplayConfig_ShouldRoundTrip()
    {
        var originalConfig = new DisplayConfig
        {
            Format = DisplayFormat.ASCII,
            Squares = new UnicodeSquares
            {
                White = "⬜",
                Red = "🟥"
            }
        };

        // Save config
        var saveResult = ConfigurationManager.SaveDisplayConfig(originalConfig);
        Assert.True(saveResult.IsSuccess);

        // Load config
        var loadResult = ConfigurationManager.LoadDisplayConfig();
        Assert.True(loadResult.IsSuccess);

        var loadedConfig = loadResult.Value;
        Assert.Equal(originalConfig.Format, loadedConfig.Format);
        Assert.Equal(originalConfig.Squares.White, loadedConfig.Squares.White);
        Assert.Equal(originalConfig.Squares.Red, loadedConfig.Squares.Red);

        // Cleanup
        ConfigurationManager.DeleteConfig();
    }

    [Fact]
    public void SaveDisplayConfig_WithNullConfig_ShouldReturnFailure()
    {
        var result = ConfigurationManager.SaveDisplayConfig(null!);
        
        Assert.True(result.IsFailure);
        Assert.Contains("cannot be null", result.Error);
    }

    [Fact]
    public void DeleteConfig_WithExistingFile_ShouldSucceed()
    {
        // Create a config first
        var config = new DisplayConfig();
        ConfigurationManager.SaveDisplayConfig(config);
        
        // Verify it exists
        Assert.True(ConfigurationManager.ConfigExists());
        
        // Delete it
        var result = ConfigurationManager.DeleteConfig();
        Assert.True(result.IsSuccess);
        
        // Verify it's gone
        Assert.False(ConfigurationManager.ConfigExists());
    }

    [Fact]
    public void DeleteConfig_WithoutExistingFile_ShouldSucceed()
    {
        // Ensure no file exists
        ConfigurationManager.DeleteConfig();
        
        // Delete should still succeed
        var result = ConfigurationManager.DeleteConfig();
        Assert.True(result.IsSuccess);
    }

    [Fact]
    public void ConfigExists_WithExistingFile_ShouldReturnTrue()
    {
        // Create a config
        var config = new DisplayConfig();
        ConfigurationManager.SaveDisplayConfig(config);
        
        Assert.True(ConfigurationManager.ConfigExists());
        
        // Cleanup
        ConfigurationManager.DeleteConfig();
    }

    [Fact]
    public void ConfigExists_WithoutFile_ShouldReturnFalse()
    {
        // Ensure no file exists
        ConfigurationManager.DeleteConfig();
        
        Assert.False(ConfigurationManager.ConfigExists());
    }
}