﻿namespace RubiksCube.Tests;

public class BasicTests
{
    [Fact]
    public void ProjectSetup_ShouldCompile()
    {
        // Basic smoke test to ensure project compiles and references work
        Assert.True(true);
    }
}
