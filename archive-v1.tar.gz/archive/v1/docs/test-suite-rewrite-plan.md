# Test Suite Rewrite Plan

## Overview
Complete rewrite of the test suite to match the corrected Rubik's Cube implementation with proper Western color scheme (Red left, Orange right) and fixed move directions (L, D, F, z now rotate clockwise).

## Phase 1: Test Infrastructure & Helpers
### Step 1.1: Create Test Utilities
- Create `TestHelpers.cs` with reusable test utilities
- Implement `CubeStateValidator` to verify cube integrity after moves
- Create `MoveTestDataGenerator` to generate expected states programmatically
- Add clear helper methods for common assertions

### Step 1.2: Document Test Conventions
- Document color scheme: Yellow top, Green front → Red left, Orange right
- Document move directions: All moves clockwise when facing that face
- Create visual diagrams for expected move behaviors
- Define sticker position indexing (0-8 for each face)

## Phase 2: Core Model Tests
### Step 2.1: Cube Construction & State Tests
- Test default cube construction (solved state)
- Test color scheme is correct (Red left, Orange right)
- Test JSON serialization/deserialization preserves state
- Test cube cloning preserves state
- Test `IsSolved()` method

### Step 2.2: Basic Face & Sticker Tests  
- Test `GetFace()` returns correct colors
- Test `SetFace()` updates correctly
- Test `GetSticker()` / `SetSticker()` work for all positions
- Test face-to-color mappings
- Test boundary conditions and error cases

## Phase 3: Individual Move Tests
### Step 3.1: Single Move Tests (R, L, U, D, F, B)
- Generate expected states programmatically for each move
- Test clockwise rotation for each face
- Test that face colors rotate correctly (clockwise pattern)
- Test that adjacent edge stickers move correctly
- Verify non-affected stickers remain unchanged

### Step 3.2: Move Variants Tests (Prime & Double)
- Test prime moves (R', L', etc.) are counter-clockwise
- Test double moves (R2, L2, etc.) 
- Test that 4 clockwise moves return to original state
- Test that move + inverse returns to original state
- Test move combinations (R U R' U')

### Step 3.3: Move Sequence Tests
- Test algorithm parsing and execution
- Test complex algorithms maintain cube validity
- Test scramble algorithms create valid scrambled states
- Test that inverse algorithms work correctly

## Phase 4: Rotation Tests
### Step 4.1: Cube Rotation Tests (x, y, z)
- Test x rotation (follows R direction)
- Test y rotation (follows U direction)  
- Test z rotation (follows F direction) - now clockwise!
- Test rotation + inverse returns to original
- Test 4 rotations return to original

### Step 4.2: Orientation Tracking Tests
- Test `GetFaceFromCurrentOrientation()` after rotations
- Test JSON serialization preserves orientation
- Test complex rotation sequences
- Test orientation state remains consistent

## Phase 5: Algorithm & Notation Tests
### Step 5.1: Notation Parser Tests
- Test parsing of all move types (R, R', R2)
- Test parsing of rotations (x, y, z)
- Test parsing of wide moves (if implemented)
- Test invalid notation handling
- Test algorithm string normalization

### Step 5.2: Algorithm Execution Tests
- Test single move algorithms
- Test complex algorithm sequences
- Test algorithms with rotations
- Test algorithm inverse generation
- Test algorithm validation

## Phase 6: Display & Rendering Tests
### Step 6.1: Display Service Tests
- Test Unicode cube rendering
- Test ASCII cube rendering
- Test display after moves shows correct colors
- Test display after rotations shows correct orientation
- Test display configuration options

### Step 6.2: Visual Verification Tests
- Create snapshot tests for known cube states
- Test display of scrambled cubes
- Test display during solve sequences
- Verify color emoji mappings (🟥=Red, 🟧=Orange, etc.)

## Phase 7: Storage & Persistence Tests
### Step 7.1: Cube Storage Tests
- Test saving cubes to .cube files
- Test loading cubes preserves state
- Test loading cubes preserves orientation
- Test file naming and path handling
- Test error handling for missing/corrupt files

### Step 7.2: JSON Format Tests
- Test JSON schema compliance
- Test backward compatibility (if needed)
- Test orientation data in JSON
- Test face data accuracy in JSON

## Phase 8: Pattern Recognition Tests
### Step 8.1: State Analysis Tests
- Test solved state detection
- Test scrambled state detection
- Test cross completion detection (0/4 to 4/4)
- Test F2L pair detection
- Test last layer state detection

### Step 8.2: Cross Solver Tests
- Test solver on solved cube (should return empty algorithm)
- Test solver on single edge displaced
- Test solver on various scrambles
- Test solution verification (applying solution achieves cross)
- Test color neutrality options

## Phase 9: Integration Tests
### Step 9.1: CLI Command Tests
- Test create command
- Test apply command with various algorithms
- Test display command with different formats
- Test solve command for cross
- Test piping between commands

### Step 9.2: End-to-End Scenarios
- Test complete solve sequences
- Test scramble and solve cycles
- Test persistence across commands
- Test error handling and recovery

## Phase 10: Performance & Edge Case Tests
### Step 10.1: Performance Tests
- Test large algorithm execution speed
- Test solver performance on complex scrambles
- Test JSON serialization performance
- Memory usage tests

### Step 10.2: Edge Case Tests
- Test invalid cube states
- Test impossible moves
- Test malformed algorithms
- Test resource cleanup
- Test thread safety (if applicable)

## Implementation Strategy

1. **Start with Phase 1**: Build solid test infrastructure first
2. **Implement Phase 2-3**: Get core cube functionality tested
3. **Use generation where possible**: Programmatically generate expected states
4. **Visual debugging**: Include helpful output for failed tests
5. **Incremental approach**: Run tests continuously while implementing
6. **Document failures**: Keep notes on any discovered bugs

## Success Criteria

- All tests pass with corrected move implementations
- Test coverage > 90% for core functionality
- Tests are maintainable and well-documented
- Test failures provide clear diagnostic information
- Tests run quickly (< 30 seconds for full suite)

## Notes

- Priority on correctness over coverage initially
- Focus on moves that we changed (L, D, F, z)
- Ensure color scheme is consistently tested
- Consider property-based testing for complex scenarios
- Keep tests independent and isolated