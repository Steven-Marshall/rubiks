# Result<T> Pattern Implementation Guidelines

## Overview

We use the **hybrid approach** combining Result<T> pattern for domain logic with exceptions for programming errors.

## Library Used

**CSharpFunctionalExtensions** v3.6.0 - provides `Result` and `Result<T>` types with functional composition methods.

## When to Use Result<T>

### ✅ **Use Result<T> for:**
1. **User input validation** - parsing algorithms, move sequences
2. **Domain logic that can fail** - applying moves, cube state validation  
3. **Business rule violations** - invalid cube configurations, unsolvable states
4. **External data processing** - loading algorithm databases, file parsing

### ❌ **Keep Exceptions for:**
1. **Programming errors** - null arguments, array out of bounds
2. **System failures** - file not found, network errors
3. **Precondition violations** - "this should never happen" scenarios
4. **Framework/library constraints** - constructor requirements

## Current Implementation

### **Domain Logic (Result<T>)**
```csharp
// Algorithm parsing
Result<List<Move>> moves = NotationParser.ParseAlgorithm("R U X");
if (moves.IsFailure) 
    Console.WriteLine($"Invalid algorithm: {moves.Error}");

// Algorithm creation
Result<Algorithm> algorithm = Algorithm.Create("R U R' U'");

// Cube operations  
Result result = cube.ApplyMove(move);
Result result = algorithm.ApplyTo(cube);
```

### **Programming Errors (Exceptions)**
```csharp
// Constructor validation
public Algorithm(string sequence)
{
    if (string.IsNullOrWhiteSpace(sequence))
        throw new ArgumentException("Sequence cannot be null", nameof(sequence));
    // ...
}

// Array bounds, null references still throw exceptions
```

## Migration Strategy

### **Backward Compatibility**
All Result<T> methods have "unsafe" equivalents for legacy code:
```csharp
// New Result<T> API
Result<List<Move>> result = NotationParser.ParseAlgorithm(input);

// Legacy exception-throwing API  
List<Move> moves = NotationParser.ParseAlgorithmUnsafe(input);
```

### **Gradual Migration**
1. ✅ **Core domain logic** migrated to Result<T>
2. 🔄 **Tests** use unsafe methods for backward compatibility
3. 🔄 **CLI layer** will use Result<T> for user-facing errors
4. 🔄 **Future features** use Result<T> from the start

## Functional Composition

Result<T> supports functional composition:
```csharp
var result = NotationParser.ParseAlgorithm("R U R' U'")
    .Map(moves => moves.Count)
    .Map(count => $"Algorithm has {count} moves");

if (result.IsSuccess)
    Console.WriteLine(result.Value);
else
    Console.WriteLine($"Error: {result.Error}");
```

## Error Handling Patterns

### **Check and Handle**
```csharp
var result = Algorithm.Create(userInput);
if (result.IsFailure)
{
    logger.LogWarning("Invalid algorithm: {Error}", result.Error);
    return BadRequest(result.Error);
}

var algorithm = result.Value;
```

### **Functional Chain**
```csharp
return Algorithm.Create(userInput)
    .Bind(algorithm => algorithm.ApplyTo(cube))
    .Map(() => "Algorithm applied successfully")
    .Match(
        success => Ok(success),
        error => BadRequest(error)
    );
```

## Benefits Achieved

1. **Explicit error handling** - Callers must handle failure cases
2. **No exception overhead** - Better performance for expected failures
3. **Functional composition** - Chain operations cleanly
4. **Future-ready** - Prepared for web APIs, services
5. **Type safety** - Compile-time guarantees for error handling

## Testing Patterns

### **Success Cases**
```csharp
var result = NotationParser.ParseAlgorithm("R U R'");
Assert.True(result.IsSuccess);
Assert.Equal(3, result.Value.Count);
```

### **Failure Cases**
```csharp
var result = NotationParser.ParseAlgorithm("R U X");
Assert.True(result.IsFailure);
Assert.Contains("Invalid move token", result.Error);
```

This hybrid approach gives us the best of both worlds: clean error handling for domain logic while maintaining simplicity for programming errors.