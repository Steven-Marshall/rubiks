# Rubik's Cube Implementation Research

## Mathematical Approaches Found

### 1. Position Vector Approach (pglass/cube - Python)
```python
class Piece:
    position: (x, y, z)  # Integer coordinates {-1, 0, 1}
    colors: color_vector  # Color mapping along axes
    
def rotate(self, matrix):
    # Apply 90-degree rotation matrix to position
    # Swap color vector entries during rotation
```

**Pros:** Clean mathematical model, rotation matrices handle complexity
**Cons:** More abstract, requires matrix math understanding

### 2. Array-Based Approach (Most implementations)
- 6 faces × 9 stickers = 54-element representation
- Direct move implementations per face
- Explicit edge rotation logic

**Pros:** Intuitive, direct mapping to physical cube
**Cons:** Tedious to implement all 6 faces correctly

### 3. Group Theory Approach 
- Represent cube as permutation group elements
- Moves as group operations
- Mathematical elegance but high complexity

## Recommendation: Stick with Array-Based
For our hobby project scale, the array-based approach (what we started) is most appropriate:
- Intuitive and debuggable
- Direct mapping to physical cube
- Easier to extend for camera input
- Reference implementations available

## Standard Color Scheme (CORRECTED!)

**Western Color Scheme when White on Top:**
- **Top (Up)**: White  
- **Bottom (Down)**: Yellow
- **Front**: Blue  
- **Back**: Green
- **Left**: Orange
- **Right**: Red

**My implementation was WRONG** - I had Red on front, should be Blue on front!

## Invalid Cube States (CRITICAL for Camera Input)

### Three Types of Invalid States:
1. **Twisted Corner** - Corner orientation sum must be multiple of 3
2. **Flipped Edge** - Number of flipped edges must be even  
3. **Permutation Parity** - Overall permutation must be even

### Key Statistics:
- Only **1 in 12** random configurations are solvable
- 43,252,003,274,489,856,000 total positions
- 3,674,160,000,000,000 solvable positions

### Detection Strategy:
```csharp
public class CubeValidator
{
    public bool IsValidState(Cube cube)
    {
        return CheckCornerTwists(cube) && 
               CheckEdgeFlips(cube) && 
               CheckPermutationParity(cube);
    }
    
    private bool CheckCornerTwists(Cube cube)
    {
        // Sum of corner orientations must be divisible by 3
    }
    
    private bool CheckEdgeFlips(Cube cube) 
    {
        // Number of flipped edges must be even
    }
    
    private bool CheckPermutationParity(Cube cube)
    {
        // Overall permutation parity must be even  
    }
}
```

This validation will be **essential** for camera input to detect:
- Assembly errors
- Sticker mistakes  
- Physical manipulation (twisted corners)
- Invalid manual input

## Next Steps:
1. Fix color scheme in current implementation
2. Complete remaining face rotations (U, F, L, D, B)
3. Add invalid state detection framework
4. Implement cube validation for future camera feature