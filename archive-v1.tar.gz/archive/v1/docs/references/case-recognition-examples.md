# Case Recognition Approaches - Examples

## Option 1: Minimal (Algorithm Execution Focus)
```json
{
  "id": "OLL_21",
  "name": "Sune",
  "sequence": "R U R' U R U2 R'",
  "movecount": 7
}
```

**Pros:** Simple, focused on solving
**Cons:** User must learn recognition separately

## Option 2: Pattern Description (Text-Based)
```json
{
  "id": "OLL_21", 
  "name": "Sune",
  "sequence": "R U R' U R U2 R'",
  "movecount": 7,
  "recognition": "Cross pattern with oriented cross edges, headlights on back"
}
```

**Pros:** Helps learning, compact
**Cons:** Subjective descriptions, hard to standardize

## Option 3: Positional Notation (Technical)
```json
{
  "id": "OLL_21",
  "name": "Sune", 
  "sequence": "R U R' U R U2 R'",
  "movecount": 7,
  "pattern": {
    "edges": [1, 1, 1, 1],  // oriented: top face yellow
    "corners": [0, 1, 0, 2] // 0=bad, 1=good, 2=opposite
  }
}
```

**Pros:** Precise, programmable pattern matching
**Cons:** Complex, requires understanding notation

## Option 4: Visual ASCII (Compact Visual)
```json
{
  "id": "OLL_21",
  "name": "Sune",
  "sequence": "R U R' U R U2 R'", 
  "movecount": 7,
  "visual": [
    " Y Y Y ",
    "Y Y Y Y",
    " Y Y Y "
  ]
}
```

**Pros:** Visual, intuitive
**Cons:** Takes space, formatting issues

## Option 5: Hybrid (Start Minimal, Add Later)
```json
{
  "id": "OLL_21",
  "name": "Sune",
  "sequence": "R U R' U R U2 R'",
  "movecount": 7
  // recognition field can be added later without breaking anything
}
```

**Pros:** Start simple, extensible
**Cons:** Incomplete initially

## Real-World Examples from Popular Cases:

**OLL Sune (Most Popular):**
- Pattern: Cross with "headlights" (two matching stickers) on back
- Recognition: "Fish shape" or "bowtie with cross"

**PLL T-Perm:**
- Pattern: Two adjacent corners need swapping
- Recognition: "Headlights on front, bar on left or right"

**PLL A-Perm:**
- Pattern: Three corners cycling clockwise/counterclockwise  
- Recognition: "One solved corner, three need cycling"

## My Recommendation:
Start with **Option 5 (Hybrid)** - minimal structure now, add recognition descriptions later when we implement the pattern matching system. This avoids over-engineering while keeping options open.

Which approach appeals to you for the initial implementation?