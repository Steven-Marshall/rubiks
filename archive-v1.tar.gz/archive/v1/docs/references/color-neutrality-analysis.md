# Color Neutrality Impact Analysis

## The Challenge

Traditional algorithms assume **white cross on bottom**:
```json
{
  "id": "OLL_21",
  "name": "Sune", 
  "sequence": "R U R' U R U2 R'",
  "movecount": 7
}
```

But with color neutrality, we might solve **blue cross on bottom**, which changes everything!

## Approach Options

### Option 1: Store Multiple Rotated Versions (BAD)
```json
{
  "white_bottom": "R U R' U R U2 R'",
  "blue_bottom": "F U F' U F U2 F'", 
  "red_bottom": "L U L' U L U2 L'",
  // ... 6 versions per algorithm
}
```
**Problems:** 6x storage, maintenance nightmare, not extensible

### Option 2: Dynamic Mapping (GOOD)
```json
{
  "id": "OLL_21",
  "name": "Sune",
  "sequence": "R U R' U R U2 R'",  // Always relative to cross color
  "movecount": 7
}
```

**Runtime mapping:**
- Cross on bottom = White → Use as-is: `R U R' U R U2 R'`
- Cross on bottom = Blue → Map R→F, so: `F U F' U F U2 F'`
- Cross on bottom = Red → Map R→L, so: `L U L' U L U2 L'`

### Option 3: Relative Notation (ADVANCED)
```json
{
  "sequence": "Cross+ Top Cross+' Top Cross+ Top2 Cross+'"
  // Cross+ = face adjacent to cross (what we call "R" for white cross)
}
```

## Recommended Solution: Dynamic Mapping

**Why it works:**
1. **Algorithms stay canonical** - stored once in standard white-bottom form
2. **Runtime translation** - map moves based on actual cross color
3. **No duplication** - same algorithm works for all 6 orientations
4. **Future-proof** - works for any method (CFOP, Roux, etc.)

**Implementation:**
```csharp
// Mapping table for cross color to face mapping
var crossMappings = new Dictionary<CubeColor, Dictionary<char, char>>()
{
    [CubeColor.White] = new() { ['R'] = 'R', ['L'] = 'L', ['F'] = 'F', ['B'] = 'B' },
    [CubeColor.Blue] = new() { ['R'] = 'F', ['L'] = 'B', ['F'] = 'L', ['B'] = 'R' },
    [CubeColor.Red] = new() { ['R'] = 'L', ['L'] = 'R', ['F'] = 'F', ['B'] = 'B' },
    // etc...
};

// Transform algorithm based on cross color
string TransformAlgorithm(string algorithm, CubeColor crossColor)
{
    var mapping = crossMappings[crossColor];
    return algorithm.Select(c => mapping.ContainsKey(c) ? mapping[c] : c);
}
```

**Example in action:**
- Algorithm: `"R U R' U R U2 R'"` (Sune for white cross)
- Blue cross detected → Transform: `"F U F' U F U2 F'"` 
- Red cross detected → Transform: `"L U L' U L U2 L'"`

## Impact Assessment

✅ **No impact on algorithm storage** - hybrid approach still works
✅ **Clean separation** - algorithms vs. execution mapping  
✅ **Extensible** - works for any future method
✅ **Performance** - O(n) string transformation, very fast

**Conclusion:** Our hybrid algorithm storage approach is **completely compatible** with color neutrality. We just need a runtime mapping layer between algorithm lookup and execution.

Should I proceed with Session 2 using this approach?