# Rotation Implementation Notes

## Overview
This document captures the requirements and design considerations for implementing cube rotations (x, y, z) in the RubiksCube project. This feature is a prerequisite for proper algorithm storage and solving functionality.

## What Are Rotations?

Rotations are whole-cube reorientations around the three spatial axes:
- **x rotation**: Rotate entire cube around the R axis (like doing an R move with the whole cube)
- **y rotation**: Rotate entire cube around the U axis (like doing a U move with the whole cube)  
- **z rotation**: Rotate entire cube around the F axis (like doing an F move with the whole cube)

Modifiers work the same as face moves:
- **x'**, **y'**, **z'**: Counter-clockwise rotation
- **x2**, **y2**, **z2**: 180-degree rotation

## Why Rotations Are Essential

### 1. Algorithm Representation
Many standard CFOP algorithms include rotations:
- **T-perm (PLL)**: `y' R U R' U' R' F R2 U' R' U' R U R' F'`
- **Y-perm (PLL)**: `F R U' R' U' R U R' F' R U R' U' R' F R F'`
- **Many OLL cases**: Use rotations for better finger tricks

Without rotation support, we cannot accurately store or execute these algorithms.

### 2. Solver Implementation
For color-neutral cross solving:
- Need to analyze cube from 6 different orientations
- Rotations allow reorienting the cube programmatically
- Essential for evaluating different cross colors efficiently

### 3. User Expectations
- Users know algorithms with rotations included
- Forcing rotation-free notation would confuse users
- Standard algorithm databases all include rotations

## Implementation Approach

### Option 1: Extend Move Class (Not Recommended)
```csharp
public enum MoveType
{
    Clockwise = 1,
    CounterClockwise = -1,
    Double = 2,
    RotationX = 10,  // New
    RotationY = 11,  // New
    RotationZ = 12   // New
}
```
**Problem**: Mixes two different concepts (face moves vs rotations)

### Option 2: Create Rotation Class (Recommended)
```csharp
public enum RotationAxis
{
    X, // Around R axis
    Y, // Around U axis  
    Z  // Around F axis
}

public enum RotationDirection
{
    Clockwise = 1,
    CounterClockwise = -1,
    Double = 2
}

public record Rotation(RotationAxis Axis, RotationDirection Direction);
```

### Option 3: Create IMove Interface (Most Flexible)
```csharp
public interface IMove
{
    Result ApplyTo(Cube cube);
    string ToString();
}

public record FaceMove(CubeFace Face, MoveType Type) : IMove;
public record Rotation(RotationAxis Axis, RotationDirection Direction) : IMove;
```

## Rotation Logic

When applying a rotation, all face colors need to be remapped:

### X Rotation (around R axis)
- F → U → B → D → F (cycle)
- L and R rotate in place

### Y Rotation (around U axis)  
- F → L → B → R → F (cycle)
- U and D rotate in place

### Z Rotation (around F axis)
- U → R → D → L → U (cycle)
- F and B rotate in place

## Parser Updates

`NotationParser` needs to recognize rotation notation:
```csharp
private static bool IsRotationToken(string token)
{
    if (string.IsNullOrWhiteSpace(token)) return false;
    
    var firstChar = token[0];
    if (firstChar != 'x' && firstChar != 'y' && firstChar != 'z') return false;
    
    if (token.Length == 1) return true;
    if (token.Length == 2 && (token[1] == '\'' || token[1] == '2')) return true;
    
    return false;
}
```

## Testing Considerations

Need comprehensive tests for:
1. Each rotation direction (x, y, z, x', y', z', x2, y2, z2)
2. Rotation sequences (multiple rotations)
3. Mixed sequences (face moves + rotations)
4. Cube state validation after rotations
5. Algorithm parsing with rotations

## Impact on Existing Code

1. **Algorithm class**: Needs to handle mixed move types
2. **Cube class**: Needs rotation application methods
3. **NotationParser**: Needs rotation parsing
4. **Display**: Should work unchanged (operates on final state)
5. **Storage**: Should work unchanged (stores state, not moves)

## Future Considerations

### Wide Moves
Wide moves (r, l, u, d, f, b) can be decomposed into rotations:
- `r = R + x'`
- `l' = L' + x`
- etc.

### Slice Moves
Slice moves (M, E, S) can also use rotations:
- `M = l' + L`
- `E = d' + D`
- `S = f + F'`

## References
- [Advanced Rubik's Cube Notation](https://ruwix.com/the-rubiks-cube/notation/advanced/)
- [J Perm Notation Guide](https://jperm.net/3x3/moves)
- [Speedsolving Wiki - 3x3x3 Notation](https://www.speedsolving.com/wiki/index.php/3x3x3_notation)