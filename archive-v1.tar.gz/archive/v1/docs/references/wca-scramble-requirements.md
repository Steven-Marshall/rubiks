# WCA Scramble Generation Requirements

Source: World Cube Association Official Regulations

## Key Requirements for 3x3x3 Scrambles

### Generation Standards
- Must use "a current official version of an official WCA scramble program"
- Scrambles must "produce a random state from all states that require at least 2 moves to solve"
- Each possible state must have "equal probability"

### Notation Requirements
Uses standard Singmaster notation:
- **Face moves**: F, B, R, L, U, D (clockwise 90°)
- **Counterclockwise**: F', B', R', L', U', D' 
- **180° turns**: F2, B2, R2, L2, U2, D2

### Randomness Standards
- Must avoid states solvable in fewer than 2 moves
- Equal probability distribution across all valid states
- No filtering or selection of scrambles allowed
- No inspection before competition

### Practical Implementation
- Typical scramble length: 20-25 moves
- No redundant moves (e.g., R R' cancellation)
- No more than 2 consecutive moves on same face
- Applied within maximum 2-hour timeframe

### Technical Notes
- God's number for 3x3x3 is 20 (maximum moves needed to solve any state)
- Scrambles should distribute across full state space
- Random number generation must be cryptographically secure
- Must avoid human bias in scramble selection

This provides the foundation for implementing WCA-compliant scramble generation in our CLI tool.