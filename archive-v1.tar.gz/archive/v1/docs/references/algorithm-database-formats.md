# Rubik's Cube Algorithm Database Format Research

## Summary of Findings

After researching existing cubing algorithm databases, here are the key findings about data structures and formats:

### Major Algorithm Databases
1. **SpeedCubeDB** - Community-driven with 4,000+ algorithms
2. **CubingApp** - Wide range including CFOP, Square-1, Megaminx  
3. **AlgDB (by cubing.js team)** - Currently in development
4. **Dan's Cubing Cheat Sheet** - Popular reference site

### Common Data Structure Patterns

Most databases organize algorithms with these key elements:

```json
{
  "case_id": "OLL_01",
  "case_name": "Sune", 
  "category": "Cross|T|Square|C|W|Corners|P|I|Fish|L|Y|Z|Dot",
  "algorithms": [
    {
      "sequence": "R U R' U R U2 R'",
      "movecount": 7,
      "popularity": 95,
      "generation": "3GEN|4GEN", 
      "notation": "STM|ETM"
    }
  ],
  "visual_pattern": "description",
  "difficulty": "beginner|intermediate|advanced"
}
```

### CFOP Method Coverage

**OLL (Orient Last Layer):**
- 57 different cases
- Grouped into 14 categories (Cross, T, Square, etc.)
- Each case has 1-5 algorithm variations
- Creative naming conventions (e.g., "Sune", "Antisune", "Wario")

**PLL (Permute Last Layer):**
- 21 different cases
- Letter-based naming (Aa, Ab, T, H, etc.)
- Multiple algorithms per case with different characteristics

**F2L (First Two Layers):**
- 42 basic cases
- Situation-based rather than pattern-based
- More algorithmic flexibility

### Algorithm Notation Standards

All databases use **Singmaster notation:**
- Letters: R (Right), U (Up), F (Front), L (Left), D (Down), B (Back)
- Modifiers: ' (counterclockwise), 2 (180°)
- Wide moves: r, u, f (lowercase for wide turns)
- Grouping: Parentheses for move sequences

### Metadata Commonly Tracked

- **Movecount**: STM (Slice Turn Metric) vs ETM (Execution Turn Metric)
- **Generation**: 3GEN (R,U,F), 4GEN, etc.
- **Popularity/Votes**: Community preference
- **Execution Speed**: Fast/slow characteristics
- **Author**: Algorithm contributor
- **Tutorial Links**: YouTube/video references

### File Organization Patterns

Common approaches:
1. **Single JSON file per algorithm set** (oll.json, pll.json)
2. **Hierarchical directory structure** (cfop/oll/, cfop/pll/)
3. **Combined sets with categories** (all CFOP in one file)

### Recommendations for Our Project

Based on this research, I recommend:

1. **JSON format** - Most flexible and widely supported
2. **Separate files per algorithm set** - Better organization and loading
3. **Standard metadata fields** - Movecount, popularity, generation
4. **Visual pattern descriptions** - For case recognition
5. **Multiple algorithms per case** - Give users options
6. **Community naming conventions** - Use established case names

## Proposed JSON Schema

```json
{
  "method": "CFOP",
  "subset": "OLL",
  "cases": [
    {
      "id": "OLL_21",
      "name": "Sune",
      "category": "Cross",
      "description": "Cross pattern with oriented cross edges",
      "algorithms": [
        {
          "sequence": "R U R' U R U2 R'",
          "movecount": 7,
          "popularity": 95,
          "generation": "2GEN",
          "author": "Traditional",
          "notes": "Most popular beginner algorithm"
        },
        {
          "sequence": "F R U R' U' F'",
          "movecount": 6, 
          "popularity": 60,
          "generation": "3GEN",
          "notes": "Alternative fingertrick-friendly version"
        }
      ],
      "recognition": "Cross with headlights on back",
      "probability": "1/54"
    }
  ]
}
```

This structure balances completeness with simplicity, avoiding over-engineering while maintaining extensibility.