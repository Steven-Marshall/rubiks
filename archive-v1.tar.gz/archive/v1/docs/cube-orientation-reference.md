# Cube Orientation and Face System Reference

## Core Concepts

### Faces vs Positions
- **Face**: A physical face with a fixed center color (Green face, Red face, etc.)
- **Position**: A spatial location in 3D space (Front position, Right position, etc.)
- **Key insight**: Faces can move to different positions via rotations (x, y, z)

### Standard WCA Orientation (Starting State)
```
           🟨 Yellow (Up)
           🟨   🟨
           🟨   🟨

🟧 Orange  🟩 Green   🟥 Red     🟦 Blue
🟧  🟧     🟩   🟩    🟥  🟥     🟦  🟦  
🟧  🟧     🟩   🟩    🟥  🟥     🟦  🟦

           🔳 White (Down)
           🔳   🔳
           🔳   🔳
```

**Default mapping:**
- Front position → Green face
- Right position → Red face  
- Back position → Blue face
- Left position → Orange face
- Up position → Yellow face
- Down position → White face

## Rotation System

### How Rotations Work
- **Rotations (x, y, z)** change which face is in which position
- **Moves (R, U, F, etc.)** turn whatever face is currently in that position
- **Physical cube state** (stickers) never changes during rotations
- **Only orientation tracking** changes during rotations

### Y Rotation Example (y')
**Before y':**
```
Left=Orange, Front=Green, Right=Red, Back=Blue
```

**After y' (counterclockwise when viewed from above):**
```
Left=Green, Front=Red, Right=Blue, Back=Orange
```

**What happened:** Each face moved one position counterclockwise:
- Green face: Front → Left
- Red face: Right → Front  
- Blue face: Back → Right
- Orange face: Left → Back

### Rotation Directions
Following Ruwix standard: "x follows R direction, y follows U direction, z follows F direction"

- **y (clockwise)**: Front → Right → Back → Left → Front
- **y' (counterclockwise)**: Front → Left → Back → Right → Front
- **y2 (180°)**: Front ↔ Back, Left ↔ Right

## Data Storage

### Internal Representation
```csharp
// CubeOrientation class
private readonly Dictionary<CubeFace, CubeFace> _positionToFace;

// Maps: "Which face is currently at each position?"
// Example after y':
// Front position → Right face (Red)
// Right position → Back face (Blue)  
// Back position → Left face (Orange)
// Left position → Front face (Green)
```

### JSON Format
```json
{
  "faces": {
    "front": ["G","G","G","G","G","G","G","G","G"],
    "right": ["R","R","R","R","R","R","R","R","R"],
    // ... other faces (physical sticker data)
  },
  "orientation": {
    "front": "Red",     // Red face is in front position
    "right": "Blue",    // Blue face is in right position  
    "back": "Orange",   // Orange face is in back position
    "left": "Green",    // Green face is in left position
    "up": "Yellow",     // Yellow face is in up position
    "down": "White"     // White face is in down position
  }
}
```

## Color-to-Face Mapping
**Fixed relationships (center stickers never move physically):**
- Green face = Front face in default orientation
- Red face = Right face in default orientation
- Blue face = Back face in default orientation
- Orange face = Left face in default orientation
- Yellow face = Up face in default orientation  
- White face = Down face in default orientation

**Opposite face pairs (never change relative to each other):**
- White ↔ Yellow (Down ↔ Up)
- Red ↔ Orange (Right ↔ Left in default)
- Blue ↔ Green (Back ↔ Front in default)

## Move Application Logic

### How Moves Work With Orientation
1. Parse move (e.g., "R")
2. Look up current orientation: "What face is at Right position?"
3. Apply the turn to that physical face
4. Orientation stays the same during moves

### Example: R move after y'
```
After y': Right position contains Blue face
R move: Turn the Blue face clockwise
Result: Blue face rotates, affecting pieces around Blue face
```

## Display System

### Orientation-Aware Display
The display shows faces based on current orientation:
```csharp
// Get face that's currently in each position
var front = cube.GetFaceFromCurrentOrientation(CubeFace.Front);
var right = cube.GetFaceFromCurrentOrientation(CubeFace.Right);
// Display these faces in standard layout
```

### Why This Matters
- After y': Display shows Red face in front position (visually)
- But JSON still stores Red stickers in "right" array (physically)
- Display bridges the gap between physical storage and visual orientation

## Algorithm Processing

### Real-World Simulation
Algorithms like `y' R U R'` work exactly like physical cube handling:
1. `y'` - Rotate cube so red face is in front
2. `R` - Turn whatever face is now on the right (Blue face)
3. `U` - Turn whatever face is now on top (Yellow face, unchanged)
4. `R'` - Turn whatever face is now on the right (Blue face, reverse)

### Why Not Transform Algorithm?
We could convert `y' R` to just `B` internally, but we don't because:
- Loses human-readable algorithm format
- Breaks pattern recognition algorithms that expect specific sequences
- Doesn't match how humans think about cube solving

## Debug Tools

### Orientation Debugging
```bash
# Check what color is in each position
dotnet run debug-orientation

# Output: "Front position has: Red, Right position has: Blue, ..."
```

### Algorithm Debugging  
```bash
# Check how algorithm is parsed
dotnet run debug-algorithm "y' R U R'"

# Output: "Algorithm 'y' R U R'' contains 4 operations: [RotationOperation: y', MoveOperation: R, ...]"
```

## Common Pitfalls to Avoid

1. **Don't confuse face identity with position**
   - ❌ "Turn the Green face" (face identity)
   - ✅ "Turn whatever face is in Front position" (position-based)

2. **Don't expect visual change from rotations alone**
   - Rotations only change internal orientation
   - Visual change happens when moves are applied after rotation

3. **Remember JSON includes both physical and logical state**
   - `faces` = physical sticker positions (unchanged by rotations)  
   - `orientation` = logical orientation mapping (changed by rotations)

4. **Backward compatibility**
   - Old JSON files without `orientation` field default to standard orientation
   - New JSON files include orientation for full state preservation

## Testing Verification

### Quick Test Cases
```bash
# Test 1: Rotation changes orientation but not visual (solved cube)
create → y' → check orientation (should show Red in front)

# Test 2: Rotation affects subsequent moves
create → R → display (Red face turns)
create → y' R → display (Blue face turns)

# Test 3: Persistence through JSON
create → y' → save → load → check orientation (should preserve Red in front)
```

This system accurately simulates physical cube manipulation while maintaining clean separation between logical orientation and physical cube state.