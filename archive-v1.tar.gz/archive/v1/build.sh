#!/bin/bash
# Build script for RubiksCube solution

echo "🔨 Building RubiksCube solution..."
dotnet build --configuration Release

if [ $? -eq 0 ]; then
    echo "✅ Build completed successfully"
else
    echo "❌ Build failed"
    exit 1
fi

echo "🧪 Running tests..."
dotnet test --configuration Release --no-build

if [ $? -eq 0 ]; then
    echo "✅ All tests passed"
else
    echo "❌ Tests failed"
    exit 1
fi

echo "🎉 Build and test completed successfully!"